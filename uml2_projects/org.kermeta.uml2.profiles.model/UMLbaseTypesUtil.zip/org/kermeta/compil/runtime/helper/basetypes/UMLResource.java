/* $Id: Runtime2EMF.java,v 1.79 2008-09-24 13:51:09 dvojtise Exp $
 * Project   : Kermeta (First iteration)
 * File      : Runtime2EMF.java
 * License   : EPL
 * Copyright : IRISA / INRIA / Universite de Rennes 1
 * ----------------------------------------------------------------------------
 * Creation date : nov 2009
 * Authors       : dvojtise
 */
package org.kermeta.compil.runtime.helper.basetypes;

import kermeta.persistence.EMFRepository;
import kermeta.persistence.PersistenceFactory;
import kermeta.persistence.Resource;

public class UMLResource {
	/**
     * 
     * 
     */
	public static void addUMLRuntimeUnitFactory() {
		
	}
}
