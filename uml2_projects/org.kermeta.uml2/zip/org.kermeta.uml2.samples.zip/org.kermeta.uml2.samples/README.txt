org.kermeta.uml2.samples project README file

You can find the documentation about using those samples
in the on-line help of org.kermeta.uml2 plugin.