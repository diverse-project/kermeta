/**
 * <copyright>
 * </copyright>
 *
 * $Id: Div.java,v 1.1 2007-05-30 22:18:11 ffleurey Exp $
 */
package fr.irisa.triskell.kmLogo.ASM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Div</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.irisa.triskell.kmLogo.ASM.ASMPackage#getDiv()
 * @model
 * @generated
 */
public interface Div extends BinaryExp {
} // Div