/**
 * <copyright>
 * </copyright>
 *
 * $Id: Greater.java,v 1.1 2007-05-30 22:18:11 ffleurey Exp $
 */
package fr.irisa.triskell.kmLogo.ASM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Greater</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.irisa.triskell.kmLogo.ASM.ASMPackage#getGreater()
 * @model
 * @generated
 */
public interface Greater extends BinaryExp {
} // Greater