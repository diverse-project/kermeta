/**
 * <copyright>
 * </copyright>
 *
 * $Id: Lower.java,v 1.1 2007/05/30 22:18:11 ffleurey Exp $
 */
package fr.irisa.triskell.kmLogo.ASM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Lower</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.irisa.triskell.kmLogo.ASM.ASMPackage#getLower()
 * @model
 * @generated
 */
public interface Lower extends BinaryExp {
} // Lower