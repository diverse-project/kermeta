/**
 * <copyright>
 * </copyright>
 *
 * $Id: Primitive.java,v 1.2 2007/05/30 22:18:11 ffleurey Exp $
 */
package fr.irisa.triskell.kmLogo.ASM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Primitive</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.irisa.triskell.kmLogo.ASM.ASMPackage#getPrimitive()
 * @model abstract="true"
 * @generated
 */
public interface Primitive extends Instruction {
} // Primitive