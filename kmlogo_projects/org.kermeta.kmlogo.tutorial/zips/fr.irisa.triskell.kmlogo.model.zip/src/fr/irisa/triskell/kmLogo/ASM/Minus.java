/**
 * <copyright>
 * </copyright>
 *
 * $Id: Minus.java,v 1.1 2007/05/30 22:18:11 ffleurey Exp $
 */
package fr.irisa.triskell.kmLogo.ASM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Minus</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.irisa.triskell.kmLogo.ASM.ASMPackage#getMinus()
 * @model
 * @generated
 */
public interface Minus extends BinaryExp {
} // Minus