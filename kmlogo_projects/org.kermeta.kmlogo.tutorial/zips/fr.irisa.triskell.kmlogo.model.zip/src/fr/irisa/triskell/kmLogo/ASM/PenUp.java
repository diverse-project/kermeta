/**
 * <copyright>
 * </copyright>
 *
 * $Id: PenUp.java,v 1.1 2007/05/30 13:23:34 ffleurey Exp $
 */
package fr.irisa.triskell.kmLogo.ASM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pen Up</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.irisa.triskell.kmLogo.ASM.ASMPackage#getPenUp()
 * @model
 * @generated
 */
public interface PenUp extends Primitive {
} // PenUp