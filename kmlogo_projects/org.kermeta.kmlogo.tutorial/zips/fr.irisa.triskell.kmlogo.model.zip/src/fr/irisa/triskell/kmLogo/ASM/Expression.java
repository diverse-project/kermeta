/**
 * <copyright>
 * </copyright>
 *
 * $Id: Expression.java,v 1.2 2007-05-30 22:18:11 ffleurey Exp $
 */
package fr.irisa.triskell.kmLogo.ASM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.irisa.triskell.kmLogo.ASM.ASMPackage#getExpression()
 * @model abstract="true"
 * @generated
 */
public interface Expression extends Instruction {
} // Expression