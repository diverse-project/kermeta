/**
 * <copyright>
 * </copyright>
 *
 * $Id: PenDown.java,v 1.1 2007/05/30 13:23:34 ffleurey Exp $
 */
package fr.irisa.triskell.kmLogo.ASM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pen Down</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see fr.irisa.triskell.kmLogo.ASM.ASMPackage#getPenDown()
 * @model
 * @generated
 */
public interface PenDown extends Primitive {
} // PenDown