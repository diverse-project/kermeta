package icommand.nxt.comm;

public class FirmwareInfo {
	public byte status;
	public String protocolVersion;
	public String firmwareVersion;
}
