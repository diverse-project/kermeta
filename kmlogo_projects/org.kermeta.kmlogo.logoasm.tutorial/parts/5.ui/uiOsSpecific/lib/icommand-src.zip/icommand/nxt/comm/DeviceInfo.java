package icommand.nxt.comm;

public class DeviceInfo {
	public byte status;
	public String NXTname;
	public String bluetoothAddress;
	public int signalStrength;
	public int freeFlash;
}
