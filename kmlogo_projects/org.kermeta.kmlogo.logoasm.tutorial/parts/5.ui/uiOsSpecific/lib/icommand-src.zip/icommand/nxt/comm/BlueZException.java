package icommand.nxt.comm;

class BlueZException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1533948968757411349L;

	public BlueZException() {
		// TODO Auto-generated constructor stub
	}

	public BlueZException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
