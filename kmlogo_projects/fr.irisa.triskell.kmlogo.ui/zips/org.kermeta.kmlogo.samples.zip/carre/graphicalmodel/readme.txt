This logocsmdi file can be visualized if you've installed the graphical modelr for logo sample.

Then, from the logocsm file you can generate the asmlogo and finish the sample like usual. 