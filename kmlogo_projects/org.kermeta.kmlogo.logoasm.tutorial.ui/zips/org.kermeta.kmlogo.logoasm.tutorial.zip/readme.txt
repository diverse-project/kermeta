Logo Tutorial : Building kmLogo DSL using Kermeta

Files inside this project are RAW files provided as a starting point for this tutorial.

In order to implement them, please follow the step by step guide provided in Logo Tutorial available :
inside the eclipse "Help content" (Herlp content/Kermeta documentation/User documentation/Tutorials/Logo Tutorial example) 
or on the Kermeta web site (www.kermeta.org -> documentation -> tutorials)    