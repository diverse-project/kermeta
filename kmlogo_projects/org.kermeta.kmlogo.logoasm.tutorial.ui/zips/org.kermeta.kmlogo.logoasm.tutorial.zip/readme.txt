Logo Tutorial : Building kmLogo DSL using Kermeta

Files inside this project are RAW files provided as a starting point for this tutorial (so it normal that you may encounter some errors).

In order to implement them, please follow the step by step guide 
provided inside the Logo Tutorial available : 
* at the eclipse "Help content" 
(Help/Help contents/Kermeta documentation/User documentation/Tutorials/
Building DSL with kermeta tutorials/Logo Tutorial example)
 
* on the Kermeta web site 
(www.kermeta.org -> documentation -> tutorials)

License 	: 	EPL
Copyright 	:	IRISA / INRIA / Universite de Rennes 1 2010
Author 		: 	Haja RAMBELONTSALAMA
				hrambelo<hrambelo@irisa.fr>    