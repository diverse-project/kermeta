/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package org.kermeta.kmlogo.logoasm.model.kmLogo.ASM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Lower</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.kermeta.kmlogo.logoasm.model.kmLogo.ASM.ASMPackage#getLower()
 * @model
 * @generated
 */
public interface Lower extends BinaryExp {
} // Lower
