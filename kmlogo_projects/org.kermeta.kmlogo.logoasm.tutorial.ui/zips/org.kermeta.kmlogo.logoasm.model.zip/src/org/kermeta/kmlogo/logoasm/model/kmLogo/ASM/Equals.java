/*$Id : Equals.java v 1.3 May 8, 2010 9:38:32 AM hrambelo Exp $
* Project : org.kermeta.kmlogo.logoasm.model
* File : 	Equals.java
* License : EPL
* Copyright : IRISA / INRIA / Universite de Rennes 1 2010
* ----------------------------------------------------------------------------
* Creation date : May 8, 2010
* Authors : Haja RAMBELONTSALAMA
*/
package org.kermeta.kmlogo.logoasm.model.kmLogo.ASM;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Equals</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.kermeta.kmlogo.logoasm.model.kmLogo.ASM.ASMPackage#getEquals()
 * @model
 * @generated
 */
public interface Equals extends BinaryExp {
} // Equals
