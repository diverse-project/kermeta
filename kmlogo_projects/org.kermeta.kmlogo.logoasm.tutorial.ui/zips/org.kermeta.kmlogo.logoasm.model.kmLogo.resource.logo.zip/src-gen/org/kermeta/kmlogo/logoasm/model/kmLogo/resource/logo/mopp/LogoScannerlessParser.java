/**
 * <copyright>
 * </copyright>
 *
 * 
 */
package org.kermeta.kmlogo.logoasm.model.kmLogo.resource.logo.mopp;

/**
 * This empty class was generated to overwrite exiting classes.
 */
public class LogoScannerlessParser {
}
