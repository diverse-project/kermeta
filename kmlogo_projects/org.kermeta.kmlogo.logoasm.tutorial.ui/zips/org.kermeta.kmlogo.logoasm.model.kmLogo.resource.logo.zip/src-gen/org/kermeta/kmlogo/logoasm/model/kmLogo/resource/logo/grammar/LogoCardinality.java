/**
 * <copyright>
 * </copyright>
 *
 * 
 */
package org.kermeta.kmlogo.logoasm.model.kmLogo.resource.logo.grammar;

public enum LogoCardinality {
	
	ONE, PLUS, QUESTIONMARK, STAR;
	
}
