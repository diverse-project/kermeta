/**
 * <copyright>
 * </copyright>
 *
 * 
 */
package org.kermeta.kmlogo.logoasm.model.kmLogo.resource.logo;

public interface ILogoHoverTextProvider {
	
	public String getHoverText(org.eclipse.emf.ecore.EObject object);
}
