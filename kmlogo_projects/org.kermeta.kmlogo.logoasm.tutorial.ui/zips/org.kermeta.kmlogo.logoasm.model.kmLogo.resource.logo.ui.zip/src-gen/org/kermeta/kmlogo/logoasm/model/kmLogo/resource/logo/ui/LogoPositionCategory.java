/**
 * <copyright>
 * </copyright>
 *
 * 
 */
package org.kermeta.kmlogo.logoasm.model.kmLogo.resource.logo.ui;

/**
 * An enumeration of all position categories.
 */
public enum LogoPositionCategory {
	BRACKET, DEFINTION, PROXY;
}
