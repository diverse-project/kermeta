package kermeta.ki.malai.instrument
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
object RichFactory{
 def createScroller : kermeta.ki.malai.instrument.Scroller = { new kermeta.ki.malai.instrument.RichScroller }
 def createScrolling2Scroll : kermeta.ki.malai.instrument.Scrolling2Scroll = { new kermeta.ki.malai.instrument.RichScrolling2Scroll }
 def createUndoRedoManager : kermeta.ki.malai.instrument.UndoRedoManager = { new kermeta.ki.malai.instrument.RichUndoRedoManager }
 def createButtonPressed2Redo : kermeta.ki.malai.instrument.ButtonPressed2Redo = { new kermeta.ki.malai.instrument.RichButtonPressed2Redo }
 def createButtonPressed2Undo : kermeta.ki.malai.instrument.ButtonPressed2Undo = { new kermeta.ki.malai.instrument.RichButtonPressed2Undo }
 def createZoomer : kermeta.ki.malai.instrument.Zoomer = { new kermeta.ki.malai.instrument.RichZoomer }
 def createScroll2Zoom : kermeta.ki.malai.instrument.Scroll2Zoom = { new kermeta.ki.malai.instrument.RichScroll2Zoom }
}

