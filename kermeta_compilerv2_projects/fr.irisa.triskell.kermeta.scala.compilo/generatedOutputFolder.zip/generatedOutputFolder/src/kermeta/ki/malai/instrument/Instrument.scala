package kermeta.ki.malai.instrument
trait Instrument extends fr.irisa.triskell.kermeta.language.structure.Object{

    def addLink(link : _root_.kermeta.ki.malai.instrument.Link, picker : _root_.kermeta.ki.malai.picking.Picker, pickable : _root_.kermeta.ki.malai.picking.Pickable, eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager, execute : java.lang.Boolean) : Unit
    def initialise(actionRegistry : _root_.kermeta.ki.malai.action.ActionRegistry) : Unit
    def `setActivatedEMF_renameAs`(activated : java.lang.Boolean) : Unit
    def initialiseLinks(eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager) : Unit
    def interimFeedback() : Unit}

