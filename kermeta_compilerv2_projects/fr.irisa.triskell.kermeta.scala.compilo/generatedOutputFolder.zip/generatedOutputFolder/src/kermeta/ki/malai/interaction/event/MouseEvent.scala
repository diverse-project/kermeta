package kermeta.ki.malai.interaction.event
trait MouseEvent extends kermeta.ki.malai.interaction.event.InputEvent{

    def getButton() : java.lang.Integer
    def getClickCount() : java.lang.Integer
    def paramString() : _root_.java.lang.String
    def getY() : java.lang.Integer
    def getX() : java.lang.Integer}

