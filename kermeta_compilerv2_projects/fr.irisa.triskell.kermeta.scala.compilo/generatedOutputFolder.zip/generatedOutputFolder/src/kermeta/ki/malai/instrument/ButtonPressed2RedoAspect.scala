package kermeta.ki.malai.instrument
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait ButtonPressed2RedoAspect  extends kermeta.ki.malai.instrument.ButtonPressLinkAspect with kermeta.ki.malai.instrument.ButtonPressed2Redo{

    override def createAction():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var redo : _root_.kermeta.ki.malai.action.Redo = kermeta.ki.malai.action.RichFactory.createRedo;
(redo).ScalaundoCollector = ((Scalainstrument).asInstanceOf[_root_.kermeta.ki.malai.instrument.UndoRedoManager]).ScalaundoCollector;
(redo).initialise((Scalainstrument).ScalaactionRegistry)
Scalaaction = redo;}
 return result
}

    override def updateAction():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
}
 return result
}

    override def getActionClass():_root_.fr.irisa.triskell.kermeta.language.structure.Class = {
var result : _root_.fr.irisa.triskell.kermeta.language.structure.Class = null.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Class]; 


{
result = scalaUtil.Util.getMetaClass("_root_.kermeta.ki.malai.action.Redo");}
 return result
}

    override def isConditionRespected():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
var bp : _root_.kermeta.ki.malai.interaction.ButtonPressed = (Scalainteraction).asInstanceOf[_root_.kermeta.ki.malai.interaction.ButtonPressed];
var undoManager : _root_.kermeta.ki.malai.instrument.UndoRedoManager = (Scalainstrument).asInstanceOf[_root_.kermeta.ki.malai.instrument.UndoRedoManager];
result = (((kermeta.standard.RichFactory.isVoid((((undoManager).ScalaundoCollector).getLastRedo()))).not())).and((((bp).Scalabutton) == ((undoManager).ScalaredoButton)));}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.instrument.ButtonPressed2Redo"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

