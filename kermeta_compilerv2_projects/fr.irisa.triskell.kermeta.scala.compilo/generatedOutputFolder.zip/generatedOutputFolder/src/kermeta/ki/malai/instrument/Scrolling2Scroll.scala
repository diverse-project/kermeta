package kermeta.ki.malai.instrument
trait Scrolling2Scroll extends kermeta.ki.malai.instrument.Link{

    override def createAction() : Unit
    override def createInteraction() : _root_.kermeta.ki.malai.interaction.Interaction
    override def updateAction() : Unit
    override def getActionClass() : _root_.fr.irisa.triskell.kermeta.language.structure.Class
    override def isConditionRespected() : Boolean}

