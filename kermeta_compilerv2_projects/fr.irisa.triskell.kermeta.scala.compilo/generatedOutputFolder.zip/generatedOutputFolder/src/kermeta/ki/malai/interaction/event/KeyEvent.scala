package kermeta.ki.malai.interaction.event
trait KeyEvent extends kermeta.ki.malai.interaction.event.InputEvent{

    def getKeyChar() : _root_.java.lang.String
    def getKeyLocation() : java.lang.Integer
    def getKeyCode() : java.lang.Integer}

