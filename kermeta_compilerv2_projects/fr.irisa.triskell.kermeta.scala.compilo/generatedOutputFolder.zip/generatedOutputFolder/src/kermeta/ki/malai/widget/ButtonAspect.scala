package kermeta.ki.malai.widget
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait ButtonAspect  extends kermeta.ki.malai.widget.GraphicalComponentAspect with kermeta.ki.malai.widget.Button{

    def initialiseWithIcon(uri : _root_.java.lang.String, eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
org.kermeta.ki.malai.widget.Button.initialiseWithURI(this,uri,eventManager)}
 return result
}

    def initialiseWithText(text : _root_.java.lang.String, eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
org.kermeta.ki.malai.widget.Button.initialiseWithText(this,text,eventManager)}
 return result
}

    def getActionCommand():_root_.java.lang.String = {
var result : _root_.java.lang.String = null.asInstanceOf[_root_.java.lang.String]; 


{
try{
result = org.kermeta.ki.malai.widget.Button.getActionCommand(this).asInstanceOf[_root_.java.lang.String];
}catch { case e:ClassCastException => {}}
}
 return result
}

    override def initialise(eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
org.kermeta.ki.malai.widget.Button.initialise(this,eventManager)}
 return result
}

    def setSelected(selected : java.lang.Boolean):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
org.kermeta.ki.malai.widget.Button.setSelected(this,selected)}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.widget.Button"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

