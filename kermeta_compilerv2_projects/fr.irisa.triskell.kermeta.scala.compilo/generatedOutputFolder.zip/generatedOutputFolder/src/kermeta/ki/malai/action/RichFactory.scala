package kermeta.ki.malai.action
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
object RichFactory{
 def createUndo : kermeta.ki.malai.action.Undo = { new kermeta.ki.malai.action.RichUndo }
 def createZoom : kermeta.ki.malai.action.Zoom = { new kermeta.ki.malai.action.RichZoom }
 def createRedo : kermeta.ki.malai.action.Redo = { new kermeta.ki.malai.action.RichRedo }
 def createActionRegistry : kermeta.ki.malai.action.ActionRegistry = { new kermeta.ki.malai.action.RichActionRegistry }
 def createActivateDesactivateInstruments : kermeta.ki.malai.action.ActivateDesactivateInstruments = { new kermeta.ki.malai.action.RichActivateDesactivateInstruments }
 def createScroll : kermeta.ki.malai.action.Scroll = { new kermeta.ki.malai.action.RichScroll }
}

