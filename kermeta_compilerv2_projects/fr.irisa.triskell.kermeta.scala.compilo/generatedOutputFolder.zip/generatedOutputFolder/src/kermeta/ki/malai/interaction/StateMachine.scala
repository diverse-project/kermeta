package kermeta.ki.malai.interaction
trait StateMachine extends kermeta.ki.malai.interaction.EventHandler{

    override def onTextChanged(textCompName : _root_.java.lang.String, TextValue : _root_.java.lang.String) : Unit
    override def onRelease(button : java.lang.Integer, px : _root_.java.lang.Double, py : _root_.java.lang.Double, idHID : java.lang.Integer) : Unit
    def executeTransition(t : _root_.kermeta.ki.malai.interaction.Transition) : Unit
    override def onKeyRelease(key : java.lang.Integer, idHID : java.lang.Integer) : Unit
    override def onButtonPressed(button : _root_.kermeta.ki.malai.widget.Button) : Unit
    override def onKeyPressure(key : java.lang.Integer, idHID : java.lang.Integer) : Unit
    def isRunning() : java.lang.Boolean
    def initialise(eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager) : Unit
    def initStateMachine() : Unit
    override def onPressure(button : java.lang.Integer, px : _root_.java.lang.Double, py : _root_.java.lang.Double, idHID : java.lang.Integer) : Unit
    override def onWheel(px : _root_.java.lang.Double, py : _root_.java.lang.Double, isUp : java.lang.Boolean, increment : java.lang.Integer, idHID : java.lang.Integer) : Unit
    def `setActivatedEMF_renameAs`(activated : java.lang.Boolean) : Unit
    def reinit() : Unit
    def addState(state : _root_.kermeta.ki.malai.interaction.State) : Unit
    override def onMove(button : java.lang.Integer, px : _root_.java.lang.Double, py : _root_.java.lang.Double, pressed : java.lang.Boolean, idHID : java.lang.Integer) : Unit}

