package kermeta.ki.malai.interaction
trait PressureTransition extends kermeta.ki.malai.interaction.PointingDeviceTransition{
}

