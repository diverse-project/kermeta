package kermeta.ki.malai.action
trait Zoom extends kermeta.ki.malai.action.Action{

    override def canDo() : java.lang.Boolean
    override def hadEffect() : java.lang.Boolean
    override def isRegisterable() : java.lang.Boolean
    override def cancelledBy(action : _root_.fr.irisa.triskell.kermeta.language.structure.Class) : java.lang.Boolean
    def getZoomIncrement() : _root_.java.lang.Double
    override def doActionBody() : Unit}

