package kermeta.ki.malai.interaction
trait Interaction extends kermeta.ki.malai.interaction.StateMachine{

    def getPickableAt(px : _root_.java.lang.Double, py : _root_.java.lang.Double) : _root_.kermeta.ki.malai.picking.Pickable
    override def matches(obj : _root_.fr.irisa.triskell.kermeta.language.structure.Object) : java.lang.Boolean
    def notifyHandlersOnStop() : Unit
    override def initialise(eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager) : Unit
    def notifyHandlersOnAborting() : Unit
    def notifyHandlersOnUpdate() : Unit
    def notifyHandlersOnStart() : Unit}

