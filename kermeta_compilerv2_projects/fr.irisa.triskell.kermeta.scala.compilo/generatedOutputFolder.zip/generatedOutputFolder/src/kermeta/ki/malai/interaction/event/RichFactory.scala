package kermeta.ki.malai.interaction.event
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
object RichFactory{
 def createMouseWheelEvent : kermeta.ki.malai.interaction.event.MouseWheelEvent = { new kermeta.ki.malai.interaction.event.RichMouseWheelEvent }
 def createKeyEvent : kermeta.ki.malai.interaction.event.KeyEvent = { new kermeta.ki.malai.interaction.event.RichKeyEvent }
 def createEvent : kermeta.ki.malai.interaction.event.Event = { new kermeta.ki.malai.interaction.event.RichEvent }
 def createMouseEvent : kermeta.ki.malai.interaction.event.MouseEvent = { new kermeta.ki.malai.interaction.event.RichMouseEvent }
 def createEventManager : kermeta.ki.malai.interaction.event.EventManager = { new kermeta.ki.malai.interaction.event.RichEventManager }
 def createActionEvent : kermeta.ki.malai.interaction.event.ActionEvent = { new kermeta.ki.malai.interaction.event.RichActionEvent }
}

