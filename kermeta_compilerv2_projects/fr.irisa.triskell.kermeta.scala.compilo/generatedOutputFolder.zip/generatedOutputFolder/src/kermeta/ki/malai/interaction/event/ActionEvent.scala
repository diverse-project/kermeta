package kermeta.ki.malai.interaction.event
trait ActionEvent extends kermeta.ki.malai.interaction.event.AWTEvent{

    def getModifiers() : java.lang.Integer
    def paramString() : _root_.java.lang.String
    def getActionCommand() : _root_.java.lang.String}

