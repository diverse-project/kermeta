package kermeta.ki.malai.instrument
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait ZoomerAspect  extends kermeta.ki.malai.instrument.InstrumentAspect with kermeta.ki.malai.instrument.Zoomer{
var metamodel : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit= _
def KergetMetamodel() : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit={this.metamodel}
def KersetMetamodel(arg:_root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit)={ this.metamodel = arg}
def Scalametamodel : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit={this.KergetMetamodel()}.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit]
def Scalametamodel_=(value : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit)={this.KersetMetamodel(value)}
var zoomable : _root_.kermeta.ki.malai.picking.Picker= _
def KergetZoomable() : _root_.kermeta.ki.malai.picking.Picker={this.zoomable}
def KersetZoomable(arg:_root_.kermeta.ki.malai.picking.Picker)={ this.zoomable = arg}
def Scalazoomable : _root_.kermeta.ki.malai.picking.Picker={this.KergetZoomable()}.asInstanceOf[_root_.kermeta.ki.malai.picking.Picker]
def Scalazoomable_=(value : _root_.kermeta.ki.malai.picking.Picker)={this.KersetZoomable(value)}

    override def initialiseLinks(eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
addLink(kermeta.ki.malai.instrument.RichFactory.createScroll2Zoom, Scalazoomable, null, eventManager, true)}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.instrument.Zoomer"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

