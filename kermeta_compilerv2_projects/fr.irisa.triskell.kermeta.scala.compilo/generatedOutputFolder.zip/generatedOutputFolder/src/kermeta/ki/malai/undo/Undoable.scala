package kermeta.ki.malai.undo
trait Undoable extends fr.irisa.triskell.kermeta.language.structure.Object{

    def undo() : Unit
    def redo() : Unit
    def getUndoName() : _root_.java.lang.String}

