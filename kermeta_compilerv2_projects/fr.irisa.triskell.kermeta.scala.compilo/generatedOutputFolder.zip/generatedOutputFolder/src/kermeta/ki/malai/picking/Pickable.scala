package kermeta.ki.malai.picking
trait Pickable extends fr.irisa.triskell.kermeta.language.structure.Object{

    def contains(px : _root_.java.lang.Double, py : _root_.java.lang.Double) : java.lang.Boolean}

