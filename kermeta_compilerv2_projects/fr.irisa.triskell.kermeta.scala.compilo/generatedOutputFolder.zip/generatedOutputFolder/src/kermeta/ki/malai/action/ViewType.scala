package kermeta.ki.malai.action
 abstract class RichActionHandler extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.action.ActionHandler with kermeta.ki.malai.action.ActionHandlerAspect 
 class RichUndo extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.action.Undo with kermeta.ki.malai.action.UndoAspect 
 class RichZoom extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.action.Zoom with kermeta.ki.malai.action.ZoomAspect 
 class RichRedo extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.action.Redo with kermeta.ki.malai.action.RedoAspect 
 class RichActionRegistry extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.action.ActionRegistry with kermeta.ki.malai.action.ActionRegistryAspect 
 abstract class RichAction extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.action.Action with kermeta.ki.malai.action.ActionAspect 
 class RichActivateDesactivateInstruments extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.action.ActivateDesactivateInstruments with kermeta.ki.malai.action.ActivateDesactivateInstrumentsAspect 
 class RichScroll extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.action.Scroll with kermeta.ki.malai.action.ScrollAspect 

