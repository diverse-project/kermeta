package kermeta.ki.malai.dispatcher
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait ListDispatcherAspect  extends kermeta.ki.malai.dispatcher.AbstractDispatcherAspect with kermeta.ki.malai.dispatcher.ListDispatcher{
var processes : java.util.List[_root_.kermeta.ki.malai.dispatcher.Dispatchable] = new java.util.ArrayList[_root_.kermeta.ki.malai.dispatcher.Dispatchable]
def KergetProcesses() : java.util.List[_root_.kermeta.ki.malai.dispatcher.Dispatchable]={this.processes}
def KersetProcesses(arg:java.util.List[_root_.kermeta.ki.malai.dispatcher.Dispatchable])={ this.processes = arg}
def Scalaprocesses : java.util.List[_root_.kermeta.ki.malai.dispatcher.Dispatchable]={this.KergetProcesses()}.asInstanceOf[java.util.List[_root_.kermeta.ki.malai.dispatcher.Dispatchable]]
def Scalaprocesses_=(value : java.util.List[_root_.kermeta.ki.malai.dispatcher.Dispatchable])={this.KergetProcesses().clear
this.KergetProcesses().addAll(value)
}

    override def run():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{


{Scalarunning = true;
while (!((Scalarunning).not()))


{


try {
 waitForEvent()


 {var stop : _root_.java.lang.Boolean = false;
 while (!(stop))


 {
 stop = true;
 (Scalaprocesses).each({(c)=>

 {
 if ((c).isWaiting())

 {
 c.run()
 stop = false;}
 }
 })}
 } 
} catch {
 case ex:_root_.kermeta.exceptions.Exception => {Scalarunning = false;
 }
 }
}
}}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.dispatcher.ListDispatcher"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

