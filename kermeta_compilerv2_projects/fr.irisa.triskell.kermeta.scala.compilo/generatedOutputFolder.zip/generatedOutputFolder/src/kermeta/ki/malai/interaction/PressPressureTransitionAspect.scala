package kermeta.ki.malai.interaction
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait PressPressureTransitionAspect  extends kermeta.ki.malai.interaction.PressureTransitionAspect with kermeta.ki.malai.interaction.PressPressureTransition{
var press : _root_.kermeta.ki.malai.interaction.Press= _
def KergetPress() : _root_.kermeta.ki.malai.interaction.Press={this.press}
def KersetPress(arg:_root_.kermeta.ki.malai.interaction.Press)={ this.press = arg}
def Scalapress : _root_.kermeta.ki.malai.interaction.Press={this.KergetPress()}.asInstanceOf[_root_.kermeta.ki.malai.interaction.Press]
def Scalapress_=(value : _root_.kermeta.ki.malai.interaction.Press)={this.KersetPress(value)}

    override def action():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(Scalapress).Scalapx = (scalaUtil.Util.getMetaClass("_root_.java.lang.Double")).clone(Scalapx);
(Scalapress).Scalapy = (scalaUtil.Util.getMetaClass("_root_.java.lang.Double")).clone(Scalapy);
(Scalapress).Scalabutton = Scalabutton;
(Scalapress).Scalatarget = (Scalapress).getPickableAt((Scalapress).Scalapx, (Scalapress).Scalapy);}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.interaction.PressPressureTransition"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

