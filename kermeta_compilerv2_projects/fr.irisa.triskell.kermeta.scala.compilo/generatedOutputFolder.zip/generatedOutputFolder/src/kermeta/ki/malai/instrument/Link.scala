package kermeta.ki.malai.instrument
trait Link extends kermeta.ki.malai.interaction.InteractionHandler{

    def isRunnable() : java.lang.Boolean
    override def interactionStarts(inter : _root_.kermeta.ki.malai.interaction.Interaction) : Unit
    def isRunning() : java.lang.Boolean
    def updateAction() : Unit
    def initialise(instrument : _root_.kermeta.ki.malai.instrument.Instrument, eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager, execute : java.lang.Boolean) : Unit
    override def interactionStops(inter : _root_.kermeta.ki.malai.interaction.Interaction) : Unit
    override def interactionUpdates(inter : _root_.kermeta.ki.malai.interaction.Interaction) : Unit
    def setPickerToInteraction(picker : _root_.kermeta.ki.malai.picking.Picker) : Unit
    def getActionClass() : _root_.fr.irisa.triskell.kermeta.language.structure.Class
    def isConditionRespected() : java.lang.Boolean
    def createAction() : Unit
    def setPickableToInteraction(pickable : _root_.kermeta.ki.malai.picking.Pickable) : Unit
    def createInteraction() : _root_.kermeta.ki.malai.interaction.Interaction
    def setActivated(activated : java.lang.Boolean) : Unit
    override def interactionAborts(inter : _root_.kermeta.ki.malai.interaction.Interaction) : Unit
    def interimFeedback() : Unit}

