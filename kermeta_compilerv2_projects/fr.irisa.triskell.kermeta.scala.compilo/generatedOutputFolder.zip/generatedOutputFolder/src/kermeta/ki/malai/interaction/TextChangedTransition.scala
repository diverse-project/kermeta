package kermeta.ki.malai.interaction
trait TextChangedTransition extends kermeta.ki.malai.interaction.Transition{
}

