package kermeta.ki.malai.interaction
trait CtrlMultiPressPressureTransition extends kermeta.ki.malai.interaction.PressureTransition{

    override def action() : Unit}

