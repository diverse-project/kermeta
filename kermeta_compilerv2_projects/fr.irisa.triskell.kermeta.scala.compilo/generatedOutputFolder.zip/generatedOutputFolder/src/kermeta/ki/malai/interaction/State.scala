package kermeta.ki.malai.interaction
trait State extends fr.irisa.triskell.kermeta.language.structure.Object{

    def initialise(name : _root_.java.lang.String) : Unit
    def onOutgoing() : Unit
    override def toString() : _root_.java.lang.String
    def onIngoing() : Unit
    def addTransition(trans : _root_.kermeta.ki.malai.interaction.Transition) : Unit}

