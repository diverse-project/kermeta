package kermeta.ki.malai.interaction
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait ButtonPressedPressTransitionAspect  extends kermeta.ki.malai.interaction.ButtonPressedTransitionAspect with kermeta.ki.malai.interaction.ButtonPressedPressTransition{
var buttonPressed : _root_.kermeta.ki.malai.interaction.ButtonPressed= _
def KergetButtonPressed() : _root_.kermeta.ki.malai.interaction.ButtonPressed={this.buttonPressed}
def KersetButtonPressed(arg:_root_.kermeta.ki.malai.interaction.ButtonPressed)={ this.buttonPressed = arg}
def ScalabuttonPressed : _root_.kermeta.ki.malai.interaction.ButtonPressed={this.KergetButtonPressed()}.asInstanceOf[_root_.kermeta.ki.malai.interaction.ButtonPressed]
def ScalabuttonPressed_=(value : _root_.kermeta.ki.malai.interaction.ButtonPressed)={this.KersetButtonPressed(value)}

    override def action():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(ScalabuttonPressed).Scalabutton = Scalabutton;}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.interaction.ButtonPressedPressTransition"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

