package kermeta.ki.malai.undo
trait UndoHandler extends fr.irisa.triskell.kermeta.language.structure.Object{

    def updateUndo() : Unit}

