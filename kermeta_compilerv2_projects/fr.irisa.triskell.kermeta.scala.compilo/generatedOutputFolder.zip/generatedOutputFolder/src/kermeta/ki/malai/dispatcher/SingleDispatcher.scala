package kermeta.ki.malai.dispatcher
trait SingleDispatcher extends kermeta.ki.malai.dispatcher.AbstractDispatcher{

    override def run() : Unit}

