package kermeta.ki.malai.interaction
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait TransitionAspect  extends ScalaAspect.fr.irisa.triskell.kermeta.language.structure.ObjectAspect with kermeta.ki.malai.interaction.Transition{
var inputState : _root_.kermeta.ki.malai.interaction.State= _
def KergetInputState() : _root_.kermeta.ki.malai.interaction.State={this.inputState}
def KersetInputState(arg:_root_.kermeta.ki.malai.interaction.State)={ this.inputState = arg}
def ScalainputState : _root_.kermeta.ki.malai.interaction.State={this.KergetInputState()}.asInstanceOf[_root_.kermeta.ki.malai.interaction.State]
def ScalainputState_=(value : _root_.kermeta.ki.malai.interaction.State)={this.KersetInputState(value)}
var outputState : _root_.kermeta.ki.malai.interaction.State= _
def KergetOutputState() : _root_.kermeta.ki.malai.interaction.State={this.outputState}
def KersetOutputState(arg:_root_.kermeta.ki.malai.interaction.State)={ this.outputState = arg}
def ScalaoutputState : _root_.kermeta.ki.malai.interaction.State={this.KergetOutputState()}.asInstanceOf[_root_.kermeta.ki.malai.interaction.State]
def ScalaoutputState_=(value : _root_.kermeta.ki.malai.interaction.State)={this.KersetOutputState(value)}

    def action():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
}
 return result
}

    def initialise(inputState : _root_.kermeta.ki.malai.interaction.State, outputState : _root_.kermeta.ki.malai.interaction.State):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if ((kermeta.standard.RichFactory.isVoid((inputState))).or(kermeta.standard.RichFactory.isVoid((outputState))))

{
throw kermeta.exceptions.RichFactory.createException}

if (((inputState).isInstanceOf[_root_.kermeta.ki.malai.interaction.AbortingState]).or((inputState).isInstanceOf[_root_.kermeta.ki.malai.interaction.TerminalState]))

{
var ex : _root_.kermeta.exceptions.Exception = kermeta.exceptions.RichFactory.createException;
(ex).Scalamessage = "Input state cannot be an ending nor an aborting state.";
throw ex}

if ((outputState).isInstanceOf[_root_.kermeta.ki.malai.interaction.InitState])

{
var ex : _root_.kermeta.exceptions.Exception = kermeta.exceptions.RichFactory.createException;
(ex).Scalamessage = "Onput state cannot be an init state.";
throw ex}

(this).ScalainputState = inputState;
(this).ScalaoutputState = outputState;
(((this).ScalainputState).Scalatransitions).addUnique(this)}
 return result
}

    override def toString():_root_.java.lang.String = {
var result : _root_.java.lang.String = null.asInstanceOf[_root_.java.lang.String]; 


{
result = (((((super[ObjectAspect].toString()).plus("[")).plus((ScalainputState).Scalaname)).plus(">>")).plus((ScalaoutputState).Scalaname)).plus("]");}
 return result
}

    def isGuardRespected():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = true;}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.interaction.Transition"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

