package kermeta.ki.malai.interaction
trait InitState extends kermeta.ki.malai.interaction.State{

    override def initialise(name : _root_.java.lang.String) : Unit
    override def onOutgoing() : Unit}

