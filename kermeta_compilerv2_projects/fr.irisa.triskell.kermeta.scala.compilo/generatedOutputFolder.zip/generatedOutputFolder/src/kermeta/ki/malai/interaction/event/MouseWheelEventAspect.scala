package kermeta.ki.malai.interaction.event
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait MouseWheelEventAspect  extends kermeta.ki.malai.interaction.event.MouseEventAspect with kermeta.ki.malai.interaction.event.MouseWheelEvent{

    def getScrollAmount():java.lang.Integer = {
var result : java.lang.Integer = null.asInstanceOf[java.lang.Integer]; 


{
try{
result = org.kermeta.ki.malai.interaction.eventWrapper.MouseWheelEventWrapper.getScrollAmount(this).asInstanceOf[Int];
}catch { case e:ClassCastException => {}}
}
 return result
}

    def getUnitsToScroll():java.lang.Integer = {
var result : java.lang.Integer = null.asInstanceOf[java.lang.Integer]; 


{
try{
result = org.kermeta.ki.malai.interaction.eventWrapper.MouseWheelEventWrapper.getUnitsToScroll(this).asInstanceOf[Int];
}catch { case e:ClassCastException => {}}
}
 return result
}

    def getScrollType():java.lang.Integer = {
var result : java.lang.Integer = null.asInstanceOf[java.lang.Integer]; 


{
try{
result = org.kermeta.ki.malai.interaction.eventWrapper.MouseWheelEventWrapper.getScrollType(this).asInstanceOf[Int];
}catch { case e:ClassCastException => {}}
}
 return result
}

    def getWheelRotation():java.lang.Integer = {
var result : java.lang.Integer = null.asInstanceOf[java.lang.Integer]; 


{
try{
result = org.kermeta.ki.malai.interaction.eventWrapper.MouseWheelEventWrapper.getWheelRotation(this).asInstanceOf[Int];
}catch { case e:ClassCastException => {}}
}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.interaction.event.MouseWheelEvent"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

