package kermeta.ki.malai.interaction
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait WheelTransitionAspect  extends kermeta.ki.malai.interaction.PointingDeviceTransitionAspect with kermeta.ki.malai.interaction.WheelTransition{
var increment : Int= _
def KergetIncrement() : Int={this.increment}
def KersetIncrement(arg:Int)={ this.increment = arg}
def Scalaincrement : Int={this.KergetIncrement()}.asInstanceOf[Int]
def Scalaincrement_=(value : Int)={this.KersetIncrement(value)}
var isUp : _root_.java.lang.Boolean= _
def KergetIsUp() : _root_.java.lang.Boolean={this.isUp}
def KersetIsUp(arg:_root_.java.lang.Boolean)={ this.isUp = arg}
def ScalaisUp : _root_.java.lang.Boolean={this.KergetIsUp()}.asInstanceOf[_root_.java.lang.Boolean]
def ScalaisUp_=(value : _root_.java.lang.Boolean)={this.KersetIsUp(value)}

    override def initialise(inputState : _root_.kermeta.ki.malai.interaction.State, outputState : _root_.kermeta.ki.malai.interaction.State):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
super[PointingDeviceTransitionAspect].initialise(inputState,outputState)
ScalaisUp = null.asInstanceOf[_root_.java.lang.Boolean];
Scalaincrement = null.asInstanceOf[Int];}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.interaction.WheelTransition"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

