package kermeta.ki.malai.action
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait ActivateDesactivateInstrumentsAspect  extends kermeta.ki.malai.action.ActionAspect with kermeta.ki.malai.action.ActivateDesactivateInstruments{
var instrumentsActivate : java.util.List[_root_.kermeta.ki.malai.instrument.Instrument] = new java.util.ArrayList[_root_.kermeta.ki.malai.instrument.Instrument]
def KergetInstrumentsActivate() : java.util.List[_root_.kermeta.ki.malai.instrument.Instrument]={this.instrumentsActivate}
def KersetInstrumentsActivate(arg:java.util.List[_root_.kermeta.ki.malai.instrument.Instrument])={ this.instrumentsActivate = arg}
def ScalainstrumentsActivate : java.util.List[_root_.kermeta.ki.malai.instrument.Instrument]={this.KergetInstrumentsActivate()}.asInstanceOf[java.util.List[_root_.kermeta.ki.malai.instrument.Instrument]]
def ScalainstrumentsActivate_=(value : java.util.List[_root_.kermeta.ki.malai.instrument.Instrument])={this.KergetInstrumentsActivate().clear
this.KergetInstrumentsActivate().addAll(value)
}
var instrumentsDesactivate : java.util.List[_root_.kermeta.ki.malai.instrument.Instrument] = new java.util.ArrayList[_root_.kermeta.ki.malai.instrument.Instrument]
def KergetInstrumentsDesactivate() : java.util.List[_root_.kermeta.ki.malai.instrument.Instrument]={this.instrumentsDesactivate}
def KersetInstrumentsDesactivate(arg:java.util.List[_root_.kermeta.ki.malai.instrument.Instrument])={ this.instrumentsDesactivate = arg}
def ScalainstrumentsDesactivate : java.util.List[_root_.kermeta.ki.malai.instrument.Instrument]={this.KergetInstrumentsDesactivate()}.asInstanceOf[java.util.List[_root_.kermeta.ki.malai.instrument.Instrument]]
def ScalainstrumentsDesactivate_=(value : java.util.List[_root_.kermeta.ki.malai.instrument.Instrument])={this.KergetInstrumentsDesactivate().clear
this.KergetInstrumentsDesactivate().addAll(value)
}

    override def canDo():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = (((ScalainstrumentsActivate).empty()).not()).or((kermeta.standard.RichFactory.isVoid((ScalainstrumentsDesactivate))).not());}
 return result
}

    override def hadEffect():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = isDone();}
 return result
}

    override def isRegisterable():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = false;}
 return result
}

    override def cancelledBy(action : _root_.fr.irisa.triskell.kermeta.language.structure.Class):java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = false;}
 return result
}

    override def doActionBody():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(ScalainstrumentsActivate).each({(ins)=>

{
(ins).`setActivatedEMF_renameAs`(true)}
})
(ScalainstrumentsDesactivate).each({(ins)=>

{
(ins).`setActivatedEMF_renameAs`(false)}
})}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.action.ActivateDesactivateInstruments"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

