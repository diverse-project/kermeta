package kermeta.ki.malai.interaction
trait Transition extends fr.irisa.triskell.kermeta.language.structure.Object{

    def action() : Unit
    def initialise(inputState : _root_.kermeta.ki.malai.interaction.State, outputState : _root_.kermeta.ki.malai.interaction.State) : Unit
    override def toString() : _root_.java.lang.String
    def isGuardRespected() : java.lang.Boolean}

