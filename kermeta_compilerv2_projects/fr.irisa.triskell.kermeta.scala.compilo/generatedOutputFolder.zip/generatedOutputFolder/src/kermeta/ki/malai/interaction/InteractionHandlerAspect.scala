package kermeta.ki.malai.interaction
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait InteractionHandlerAspect  extends ScalaAspect.fr.irisa.triskell.kermeta.language.structure.ObjectAspect with kermeta.ki.malai.interaction.InteractionHandler{

    def interactionStarts(ai : _root_.kermeta.ki.malai.interaction.Interaction):Unit

    def interactionAborts(ai : _root_.kermeta.ki.malai.interaction.Interaction):Unit

    def interactionStops(ai : _root_.kermeta.ki.malai.interaction.Interaction):Unit

    def interactionUpdates(ai : _root_.kermeta.ki.malai.interaction.Interaction):Unit
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.interaction.InteractionHandler"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

