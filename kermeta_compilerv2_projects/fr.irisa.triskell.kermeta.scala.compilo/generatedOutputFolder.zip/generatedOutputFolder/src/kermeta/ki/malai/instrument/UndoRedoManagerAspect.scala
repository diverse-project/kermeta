package kermeta.ki.malai.instrument
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait UndoRedoManagerAspect  extends kermeta.ki.malai.instrument.InstrumentAspect with kermeta.ki.malai.undo.UndoHandlerAspect with kermeta.ki.malai.instrument.UndoRedoManager{
var undoCollector : _root_.kermeta.ki.malai.undo.UndoCollector= _
def KergetUndoCollector() : _root_.kermeta.ki.malai.undo.UndoCollector={this.undoCollector}
def KersetUndoCollector(arg:_root_.kermeta.ki.malai.undo.UndoCollector)={ this.undoCollector = arg}
def ScalaundoCollector : _root_.kermeta.ki.malai.undo.UndoCollector={this.KergetUndoCollector()}.asInstanceOf[_root_.kermeta.ki.malai.undo.UndoCollector]
def ScalaundoCollector_=(value : _root_.kermeta.ki.malai.undo.UndoCollector)={this.KersetUndoCollector(value)}
var undoButton : _root_.kermeta.ki.malai.widget.Button= _
def KergetUndoButton() : _root_.kermeta.ki.malai.widget.Button={this.undoButton}
def KersetUndoButton(arg:_root_.kermeta.ki.malai.widget.Button)={ this.undoButton = arg}
def ScalaundoButton : _root_.kermeta.ki.malai.widget.Button={this.KergetUndoButton()}.asInstanceOf[_root_.kermeta.ki.malai.widget.Button]
def ScalaundoButton_=(value : _root_.kermeta.ki.malai.widget.Button)={this.KersetUndoButton(value)}
var picker : _root_.kermeta.ki.malai.picking.Picker= _
def KergetPicker() : _root_.kermeta.ki.malai.picking.Picker={this.picker}
def KersetPicker(arg:_root_.kermeta.ki.malai.picking.Picker)={ this.picker = arg}
def Scalapicker : _root_.kermeta.ki.malai.picking.Picker={this.KergetPicker()}.asInstanceOf[_root_.kermeta.ki.malai.picking.Picker]
def Scalapicker_=(value : _root_.kermeta.ki.malai.picking.Picker)={this.KersetPicker(value)}
var redoButton : _root_.kermeta.ki.malai.widget.Button= _
def KergetRedoButton() : _root_.kermeta.ki.malai.widget.Button={this.redoButton}
def KersetRedoButton(arg:_root_.kermeta.ki.malai.widget.Button)={ this.redoButton = arg}
def ScalaredoButton : _root_.kermeta.ki.malai.widget.Button={this.KergetRedoButton()}.asInstanceOf[_root_.kermeta.ki.malai.widget.Button]
def ScalaredoButton_=(value : _root_.kermeta.ki.malai.widget.Button)={this.KersetRedoButton(value)}

    override def updateUndo():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if (Scalaactivated)

{
(ScalaundoButton).setEnable((kermeta.standard.RichFactory.isVoid(((ScalaundoCollector).getLastUndo()))).not())
(ScalaredoButton).setEnable((kermeta.standard.RichFactory.isVoid(((ScalaundoCollector).getLastRedo()))).not())}
}
 return result
}

    override def `setActivatedEMF_renameAs`(activated : java.lang.Boolean):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
super[InstrumentAspect].setActivated(activated)
if (activated)

{
updateUndo()}
else 


{
(ScalaundoButton).setEnable(false)
(ScalaredoButton).setEnable(false)}
}
 return result
}

    override def initialiseLinks(eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
addLink(kermeta.ki.malai.instrument.RichFactory.createButtonPressed2Redo, Scalapicker, null, eventManager, false)
addLink(kermeta.ki.malai.instrument.RichFactory.createButtonPressed2Undo, Scalapicker, null, eventManager, false)}
 return result
}

    def initialiseWidgets(eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
ScalaundoButton = kermeta.ki.malai.widget.RichFactory.createButton;
ScalaredoButton = kermeta.ki.malai.widget.RichFactory.createButton;
(ScalaundoButton).initialiseWithIcon("/org/kermeta/ki/malai/res/Undo.png", eventManager)
(ScalaredoButton).initialiseWithIcon("/org/kermeta/ki/malai/res/Redo.png", eventManager)}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.instrument.UndoRedoManager"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

