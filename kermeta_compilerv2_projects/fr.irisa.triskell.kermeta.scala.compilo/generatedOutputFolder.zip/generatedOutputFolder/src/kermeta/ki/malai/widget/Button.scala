package kermeta.ki.malai.widget
trait Button extends kermeta.ki.malai.widget.GraphicalComponent{

    def initialiseWithIcon(uri : _root_.java.lang.String, eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager) : Unit
    def initialiseWithText(text : _root_.java.lang.String, eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager) : Unit
    def getActionCommand() : _root_.java.lang.String
    override def initialise(eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager) : Unit
    def setSelected(selected : java.lang.Boolean) : Unit}

