package kermeta.ki.malai.interaction.event
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait EventManagerAspect  extends kermeta.ki.malai.dispatcher.DispatchableAspect with kermeta.ki.malai.interaction.event.EventManager{
var handlers : java.util.List[_root_.kermeta.ki.malai.interaction.EventHandler] = new java.util.ArrayList[_root_.kermeta.ki.malai.interaction.EventHandler]
def KergetHandlers() : java.util.List[_root_.kermeta.ki.malai.interaction.EventHandler]={this.handlers}
def KersetHandlers(arg:java.util.List[_root_.kermeta.ki.malai.interaction.EventHandler])={ this.handlers = arg}
def Scalahandlers : java.util.List[_root_.kermeta.ki.malai.interaction.EventHandler]={this.KergetHandlers()}.asInstanceOf[java.util.List[_root_.kermeta.ki.malai.interaction.EventHandler]]
def Scalahandlers_=(value : java.util.List[_root_.kermeta.ki.malai.interaction.EventHandler])={this.KergetHandlers().clear
this.KergetHandlers().addAll(value)
}

    def process(event : _root_.kermeta.ki.malai.interaction.event.Event):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var name : _root_.java.lang.String = (event).getName();
var info : _root_.kermeta.ki.malai.interaction.event.AWTEvent = (event).getInfo();
if ((info).isInstanceOf[_root_.kermeta.ki.malai.interaction.event.MouseEvent])

{
var me : _root_.kermeta.ki.malai.interaction.event.MouseEvent = (info).asInstanceOf[_root_.kermeta.ki.malai.interaction.event.MouseEvent];
var button : Int = (me).getButton();
var x : _root_.java.lang.Double = ((me).getX()).toReal();
var y : _root_.java.lang.Double = ((me).getY()).toReal();
if (((name) == ("MOUSE_MOVED")))

{
(Scalahandlers).each({(h)=>

{
(h).onMove(button, x, y, false, 0)}
})}
else 


{
if (((name) == ("MOUSE_DRAGGED")))

{
(Scalahandlers).each({(h)=>

{
(h).onMove(button, x, y, true, 0)}
})}
else 


{
if (((name) == ("MOUSE_PRESSED")))

{
var `object` : _root_.fr.irisa.triskell.kermeta.language.structure.Object = (info).getSourceObject();
(Scalahandlers).each({(h)=>

{
if ((h).matches(`object`))

{
(h).onPressure(button, x, y, 0)}
}
})}
else 


{
if (((name) == ("MOUSE_RELEASED")))

{
var `object` : _root_.fr.irisa.triskell.kermeta.language.structure.Object = (info).getSourceObject();
(Scalahandlers).each({(h)=>

{
if ((h).matches(`object`))

{
(h).onRelease(button, x, y, 0)}
}
})}

if (((name) == ("MOUSE_WHEEL_MOVED")))

{
var `object` : _root_.fr.irisa.triskell.kermeta.language.structure.Object = (info).getSourceObject();
var mwe : _root_.kermeta.ki.malai.interaction.event.MouseWheelEvent = (info).asInstanceOf[_root_.kermeta.ki.malai.interaction.event.MouseWheelEvent];
var isUp : _root_.java.lang.Boolean = ((mwe).getWheelRotation()).isLower(0);
var increment : Int = (mwe).getScrollAmount();
(Scalahandlers).each({(h)=>

{
if ((h).matches(`object`))

{
(h).onWheel(x, y, isUp, increment, 0)}
}
})}
}
}
}
}
else 


{
if ((info).isInstanceOf[_root_.kermeta.ki.malai.interaction.event.KeyEvent])

{
var keyCode : Int = ((info).asInstanceOf[_root_.kermeta.ki.malai.interaction.event.KeyEvent]).getKeyCode();
if (((name) == ("KEY_PRESSED")))

{
var `object` : _root_.fr.irisa.triskell.kermeta.language.structure.Object = (info).getSourceObject();
(Scalahandlers).each({(h)=>

{
if ((h).matches(`object`))

{
(h).onKeyPressure(keyCode, 0)}
}
})}
else 


{
if (((name) == ("KEY_RELEASED")))

{
var `object` : _root_.fr.irisa.triskell.kermeta.language.structure.Object = (info).getSourceObject();
(Scalahandlers).each({(h)=>

{
if ((h).matches(`object`))

{
(h).onKeyRelease(keyCode, 0)}
}
})}
}
}
else 


{
if (((name) == ("ACTION_PERFORMED")))

{
var src : _root_.fr.irisa.triskell.kermeta.language.structure.Object = ((info).asInstanceOf[_root_.kermeta.ki.malai.interaction.event.ActionEvent]).getSourceObject();
if ((src).isInstanceOf[_root_.kermeta.ki.malai.widget.Button])

{
(Scalahandlers).each({(h)=>

{
if ((h).matches(src))

{
(h).onButtonPressed((src).asInstanceOf[_root_.kermeta.ki.malai.widget.Button])}
}
})}
}
}
}
}
 return result
}

    def initialise(dispatcher : _root_.kermeta.ki.malai.dispatcher.AbstractDispatcher):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).Scaladispatcher = dispatcher;
try{
result = org.kermeta.ki.malai.interaction.eventWrapper.EventManagerWrapper.initialise(this,dispatcher);
}catch { case e:ClassCastException => {}}
}
 return result
}

    override def run():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var event : _root_.kermeta.ki.malai.interaction.event.Event = null.asInstanceOf[_root_.kermeta.ki.malai.interaction.event.Event];
try{
event = org.kermeta.ki.malai.interaction.eventWrapper.EventManagerWrapper.getTopEvent(this).asInstanceOf[_root_.kermeta.ki.malai.interaction.event.Event];
}catch { case e:ClassCastException => {}}

if (kermeta.standard.RichFactory.isVoid((event)))

{
(stdio).writeln("event is void")}
else 


{
var existStr : _root_.java.lang.String = null.asInstanceOf[_root_.java.lang.String];
try{
existStr = org.kermeta.ki.malai.interaction.eventWrapper.EventWrapper.getExitEventString(this).asInstanceOf[_root_.java.lang.String];
}catch { case e:ClassCastException => {}}

if ((((event).getName()) == (existStr)))

{
var ex : _root_.kermeta.exceptions.Exception = kermeta.exceptions.RichFactory.createException;
(ex).Scalamessage = existStr;
throw ex}
else 


{
process(event)}
}
}
 return result
}

    override def isWaiting():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
try{
result = org.kermeta.ki.malai.interaction.eventWrapper.EventManagerWrapper.isWaiting(this).asInstanceOf[_root_.java.lang.Boolean];
}catch { case e:ClassCastException => {}}
}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.interaction.event.EventManager"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

