package kermeta.ki.malai.action
trait ActionRegistry extends fr.irisa.triskell.kermeta.language.structure.Object{

    def cancelActions(action : _root_.kermeta.ki.malai.action.Action) : Unit
    def abortAction(action : _root_.kermeta.ki.malai.action.Action) : Unit
    def initialise(undoCollector : _root_.kermeta.ki.malai.undo.UndoCollector) : Unit
    def notifyHandlersOnAdd(action : _root_.kermeta.ki.malai.action.Action) : Unit
    def notifyHandlersOnAbort(action : _root_.kermeta.ki.malai.action.Action) : Unit
    def notifyHandlersOnCancel(action : _root_.kermeta.ki.malai.action.Action) : Unit
    def addAction(action : _root_.kermeta.ki.malai.action.Action) : Unit
    def removeAction(action : _root_.kermeta.ki.malai.action.Action) : Unit
    def getAction(action : _root_.fr.irisa.triskell.kermeta.language.structure.Class) : _root_.kermeta.ki.malai.action.Action}

