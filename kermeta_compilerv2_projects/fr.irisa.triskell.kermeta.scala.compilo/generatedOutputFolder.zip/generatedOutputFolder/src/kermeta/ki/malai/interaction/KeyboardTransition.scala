package kermeta.ki.malai.interaction
trait KeyboardTransition extends kermeta.ki.malai.interaction.Transition{

    override def initialise(inputState : _root_.kermeta.ki.malai.interaction.State, outputState : _root_.kermeta.ki.malai.interaction.State) : Unit}

