package kermeta.ki.malai.action
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait ActionRegistryAspect  extends ScalaAspect.fr.irisa.triskell.kermeta.language.structure.ObjectAspect with kermeta.ki.malai.action.ActionRegistry{
var undoCollector : _root_.kermeta.ki.malai.undo.UndoCollector= _
def KergetUndoCollector() : _root_.kermeta.ki.malai.undo.UndoCollector={this.undoCollector}
def KersetUndoCollector(arg:_root_.kermeta.ki.malai.undo.UndoCollector)={ this.undoCollector = arg}
def ScalaundoCollector : _root_.kermeta.ki.malai.undo.UndoCollector={this.KergetUndoCollector()}.asInstanceOf[_root_.kermeta.ki.malai.undo.UndoCollector]
def ScalaundoCollector_=(value : _root_.kermeta.ki.malai.undo.UndoCollector)={this.KersetUndoCollector(value)}
var actions : java.util.List[_root_.kermeta.ki.malai.action.Action] = new java.util.ArrayList[_root_.kermeta.ki.malai.action.Action]
def KergetActions() : java.util.List[_root_.kermeta.ki.malai.action.Action]={this.actions}
def KersetActions(arg:java.util.List[_root_.kermeta.ki.malai.action.Action])={ this.actions = arg}
def Scalaactions : java.util.List[_root_.kermeta.ki.malai.action.Action]={this.KergetActions()}.asInstanceOf[java.util.List[_root_.kermeta.ki.malai.action.Action]]
def Scalaactions_=(value : java.util.List[_root_.kermeta.ki.malai.action.Action])={this.KergetActions().clear
this.KergetActions().addAll(value)
}
var handlers : java.util.List[_root_.kermeta.ki.malai.action.ActionHandler] = new java.util.ArrayList[_root_.kermeta.ki.malai.action.ActionHandler]
def KergetHandlers() : java.util.List[_root_.kermeta.ki.malai.action.ActionHandler]={this.handlers}
def KersetHandlers(arg:java.util.List[_root_.kermeta.ki.malai.action.ActionHandler])={ this.handlers = arg}
def Scalahandlers : java.util.List[_root_.kermeta.ki.malai.action.ActionHandler]={this.KergetHandlers()}.asInstanceOf[java.util.List[_root_.kermeta.ki.malai.action.ActionHandler]]
def Scalahandlers_=(value : java.util.List[_root_.kermeta.ki.malai.action.ActionHandler])={this.KergetHandlers().clear
this.KergetHandlers().addAll(value)
}

    def cancelActions(action : _root_.kermeta.ki.malai.action.Action):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var clazz : _root_.fr.irisa.triskell.kermeta.language.structure.Class = (action).getMetaClass();


{var i : Int = 0;
while (!(((i).isGreaterOrEqual((Scalaactions).size())).or((Scalaactions).isEmpty())))


{
if (((Scalaactions).at(i)).cancelledBy(clazz))

{
notifyHandlersOnCancel((Scalaactions).removeAt(i))}
else 


{
i = (i).plus(1);}
}
}}
 return result
}

    def abortAction(action : _root_.kermeta.ki.malai.action.Action):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(action).abort()
(Scalaactions).remove(action)
notifyHandlersOnAbort(action)}
 return result
}

    def initialise(undoCollector : _root_.kermeta.ki.malai.undo.UndoCollector):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).ScalaundoCollector = undoCollector;}
 return result
}

    def notifyHandlersOnAdd(action : _root_.kermeta.ki.malai.action.Action):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(Scalahandlers).each({(handler)=>

{
(handler).onActionAdded(action)}
})}
 return result
}

    def notifyHandlersOnAbort(action : _root_.kermeta.ki.malai.action.Action):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(Scalahandlers).each({(handler)=>

{
(handler).onActionAborted(action)}
})}
 return result
}

    def notifyHandlersOnCancel(action : _root_.kermeta.ki.malai.action.Action):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(Scalahandlers).each({(handler)=>

{
(handler).onActionCancelled(action)}
})}
 return result
}

    def addAction(action : _root_.kermeta.ki.malai.action.Action):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
cancelActions(action)
(Scalaactions).addUnique(action)
notifyHandlersOnAdd(action)
if ((action).isInstanceOf[_root_.kermeta.ki.malai.undo.Undoable])

{
(ScalaundoCollector).add((action).asInstanceOf[_root_.kermeta.ki.malai.undo.Undoable])}
}
 return result
}

    def removeAction(action : _root_.kermeta.ki.malai.action.Action):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(Scalaactions).remove(action)
notifyHandlersOnCancel(action)}
 return result
}

    def getAction(action : _root_.fr.irisa.triskell.kermeta.language.structure.Class):_root_.kermeta.ki.malai.action.Action = {
var result : _root_.kermeta.ki.malai.action.Action = null.asInstanceOf[_root_.kermeta.ki.malai.action.Action]; 


{
result = (Scalaactions).detect({(action2)=>

{
(action2).isInstanceOf[action]}
});}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.action.ActionRegistry"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

