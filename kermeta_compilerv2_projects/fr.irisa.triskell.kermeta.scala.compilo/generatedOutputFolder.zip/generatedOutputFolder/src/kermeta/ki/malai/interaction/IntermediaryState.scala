package kermeta.ki.malai.interaction
trait IntermediaryState extends kermeta.ki.malai.interaction.State{

    override def onIngoing() : Unit}

