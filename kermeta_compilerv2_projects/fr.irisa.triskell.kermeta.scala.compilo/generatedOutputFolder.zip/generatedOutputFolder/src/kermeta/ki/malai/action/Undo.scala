package kermeta.ki.malai.action
trait Undo extends kermeta.ki.malai.action.Action{

    override def canDo() : java.lang.Boolean
    override def hadEffect() : java.lang.Boolean
    override def cancelledBy(action : _root_.fr.irisa.triskell.kermeta.language.structure.Class) : java.lang.Boolean
    override def isRegisterable() : java.lang.Boolean
    override def doActionBody() : Unit}

