package kermeta.ki.malai.interaction
trait KeyPressureTransition extends kermeta.ki.malai.interaction.KeyboardTransition{
}

