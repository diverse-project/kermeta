package kermeta.ki.malai.instrument
 abstract class RichInstrument extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.instrument.Instrument with kermeta.ki.malai.instrument.InstrumentAspect 
 abstract class RichLink extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.instrument.Link with kermeta.ki.malai.instrument.LinkAspect 
 class RichScroller extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.instrument.Scroller with kermeta.ki.malai.instrument.ScrollerAspect 
 class RichScrolling2Scroll extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.instrument.Scrolling2Scroll with kermeta.ki.malai.instrument.Scrolling2ScrollAspect 
 abstract class RichButtonPressLink extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.instrument.ButtonPressLink with kermeta.ki.malai.instrument.ButtonPressLinkAspect 
 class RichUndoRedoManager extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.instrument.UndoRedoManager with kermeta.ki.malai.instrument.UndoRedoManagerAspect 
 class RichButtonPressed2Redo extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.instrument.ButtonPressed2Redo with kermeta.ki.malai.instrument.ButtonPressed2RedoAspect 
 class RichButtonPressed2Undo extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.instrument.ButtonPressed2Undo with kermeta.ki.malai.instrument.ButtonPressed2UndoAspect 
 class RichZoomer extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.instrument.Zoomer with kermeta.ki.malai.instrument.ZoomerAspect 
 class RichScroll2Zoom extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.instrument.Scroll2Zoom with kermeta.ki.malai.instrument.Scroll2ZoomAspect 
 abstract class RichPressLink extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.instrument.PressLink with kermeta.ki.malai.instrument.PressLinkAspect 

