package kermeta.ki.malai.instrument
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait ButtonPressed2UndoAspect  extends kermeta.ki.malai.instrument.ButtonPressLinkAspect with kermeta.ki.malai.instrument.ButtonPressed2Undo{

    override def createAction():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var undo : _root_.kermeta.ki.malai.action.Undo = kermeta.ki.malai.action.RichFactory.createUndo;
(undo).ScalaundoCollector = ((Scalainstrument).asInstanceOf[_root_.kermeta.ki.malai.instrument.UndoRedoManager]).ScalaundoCollector;
(undo).initialise((Scalainstrument).ScalaactionRegistry)
Scalaaction = undo;}
 return result
}

    override def updateAction():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
}
 return result
}

    override def getActionClass():_root_.fr.irisa.triskell.kermeta.language.structure.Class = {
var result : _root_.fr.irisa.triskell.kermeta.language.structure.Class = null.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Class]; 


{
result = scalaUtil.Util.getMetaClass("_root_.kermeta.ki.malai.action.Undo");}
 return result
}

    override def isConditionRespected():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
var bp : _root_.kermeta.ki.malai.interaction.ButtonPressed = (Scalainteraction).asInstanceOf[_root_.kermeta.ki.malai.interaction.ButtonPressed];
var undoManager : _root_.kermeta.ki.malai.instrument.UndoRedoManager = (Scalainstrument).asInstanceOf[_root_.kermeta.ki.malai.instrument.UndoRedoManager];
result = (((kermeta.standard.RichFactory.isVoid((((undoManager).ScalaundoCollector).getLastUndo()))).not())).and((((bp).Scalabutton) == ((undoManager).ScalaundoButton)));}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.instrument.ButtonPressed2Undo"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

