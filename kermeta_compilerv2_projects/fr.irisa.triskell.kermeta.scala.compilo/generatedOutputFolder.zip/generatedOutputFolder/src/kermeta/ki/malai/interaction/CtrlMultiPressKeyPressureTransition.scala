package kermeta.ki.malai.interaction
trait CtrlMultiPressKeyPressureTransition extends kermeta.ki.malai.interaction.KeyPressureTransition{

    override def isGuardRespected() : java.lang.Boolean}

