package kermeta.ki.malai.interaction.event
trait Event extends fr.irisa.triskell.kermeta.language.structure.Object{

    def getName() : _root_.java.lang.String
    def getInfo() : _root_.kermeta.ki.malai.interaction.event.AWTEvent}

