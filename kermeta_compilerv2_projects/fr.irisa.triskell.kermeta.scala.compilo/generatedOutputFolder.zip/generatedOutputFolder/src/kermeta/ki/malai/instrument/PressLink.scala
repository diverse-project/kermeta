package kermeta.ki.malai.instrument
trait PressLink extends kermeta.ki.malai.instrument.Link{

    override def createInteraction() : _root_.kermeta.ki.malai.interaction.Interaction}

