package kermeta.ki.malai.undo
trait UndoCollector extends fr.irisa.triskell.kermeta.language.structure.Object{

    def getLastUndo() : _root_.kermeta.ki.malai.undo.Undoable
    def clear() : Unit
    def getLastRedo() : _root_.kermeta.ki.malai.undo.Undoable
    def getLastUndoMessage() : _root_.java.lang.String
    def undo() : Unit
    def notifyHandlers() : Unit
    def redo() : Unit
    def initialise() : Unit
    def getLastRedoMessage() : _root_.java.lang.String
    def add(elt : _root_.kermeta.ki.malai.undo.Undoable) : Unit}

