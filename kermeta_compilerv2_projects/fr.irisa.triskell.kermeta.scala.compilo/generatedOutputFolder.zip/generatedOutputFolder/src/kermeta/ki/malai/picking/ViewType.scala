package kermeta.ki.malai.picking
 abstract class RichPickable extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.picking.Pickable with kermeta.ki.malai.picking.PickableAspect 
 abstract class RichPicker extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.picking.Picker with kermeta.ki.malai.picking.PickerAspect 

