package kermeta.ki.malai.dispatcher
 abstract class RichAbstractDispatcher extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.dispatcher.AbstractDispatcher with kermeta.ki.malai.dispatcher.AbstractDispatcherAspect 
 abstract class RichDispatchable extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.dispatcher.Dispatchable with kermeta.ki.malai.dispatcher.DispatchableAspect 
 class RichSingleDispatcher extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.dispatcher.SingleDispatcher with kermeta.ki.malai.dispatcher.SingleDispatcherAspect 
 class RichListDispatcher extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.dispatcher.ListDispatcher with kermeta.ki.malai.dispatcher.ListDispatcherAspect 

