package kermeta.ki.malai.widget
trait GraphicalComponent extends kermeta.ki.malai.picking.Pickable{

    def getY() : java.lang.Integer
    def initialise(eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager) : Unit
    def setVisible(visible : java.lang.Boolean) : Unit
    def getX() : java.lang.Integer
    override def contains(px : _root_.java.lang.Double, py : _root_.java.lang.Double) : java.lang.Boolean
    def setEnable(enable : java.lang.Boolean) : Unit}

