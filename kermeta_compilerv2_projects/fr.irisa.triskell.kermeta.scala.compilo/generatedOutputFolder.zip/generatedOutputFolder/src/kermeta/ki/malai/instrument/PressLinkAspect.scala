package kermeta.ki.malai.instrument
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait PressLinkAspect  extends kermeta.ki.malai.instrument.LinkAspect with kermeta.ki.malai.instrument.PressLink{

    override def createInteraction():_root_.kermeta.ki.malai.interaction.Interaction = {
var result : _root_.kermeta.ki.malai.interaction.Interaction = null.asInstanceOf[_root_.kermeta.ki.malai.interaction.Interaction]; 


{
result = kermeta.ki.malai.interaction.RichFactory.createPress;}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.instrument.PressLink"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

