package kermeta.ki.malai.action
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait RedoAspect  extends kermeta.ki.malai.action.ActionAspect with kermeta.ki.malai.action.Redo{
var undoCollector : _root_.kermeta.ki.malai.undo.UndoCollector= _
def KergetUndoCollector() : _root_.kermeta.ki.malai.undo.UndoCollector={this.undoCollector}
def KersetUndoCollector(arg:_root_.kermeta.ki.malai.undo.UndoCollector)={ this.undoCollector = arg}
def ScalaundoCollector : _root_.kermeta.ki.malai.undo.UndoCollector={this.KergetUndoCollector()}.asInstanceOf[_root_.kermeta.ki.malai.undo.UndoCollector]
def ScalaundoCollector_=(value : _root_.kermeta.ki.malai.undo.UndoCollector)={this.KersetUndoCollector(value)}

    override def canDo():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = (kermeta.standard.RichFactory.isVoid(((ScalaundoCollector).getLastRedo()))).not();}
 return result
}

    override def hadEffect():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = isDone();}
 return result
}

    override def cancelledBy(action : _root_.fr.irisa.triskell.kermeta.language.structure.Class):java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = false;}
 return result
}

    override def isRegisterable():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = false;}
 return result
}

    override def doActionBody():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(ScalaundoCollector).redo()
Scaladone}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.action.Redo"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

