package kermeta.ki.malai.instrument
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait InstrumentAspect  extends ScalaAspect.fr.irisa.triskell.kermeta.language.structure.ObjectAspect with kermeta.ki.malai.instrument.Instrument{
var actionRegistry : _root_.kermeta.ki.malai.action.ActionRegistry= _
def KergetActionRegistry() : _root_.kermeta.ki.malai.action.ActionRegistry={this.actionRegistry}
def KersetActionRegistry(arg:_root_.kermeta.ki.malai.action.ActionRegistry)={ this.actionRegistry = arg}
def ScalaactionRegistry : _root_.kermeta.ki.malai.action.ActionRegistry={this.KergetActionRegistry()}.asInstanceOf[_root_.kermeta.ki.malai.action.ActionRegistry]
def ScalaactionRegistry_=(value : _root_.kermeta.ki.malai.action.ActionRegistry)={this.KersetActionRegistry(value)}
var activated : _root_.java.lang.Boolean= _
def KergetActivated() : _root_.java.lang.Boolean={this.activated}
def KersetActivated(arg:_root_.java.lang.Boolean)={ this.activated = arg}
def Scalaactivated : _root_.java.lang.Boolean={this.KergetActivated()}.asInstanceOf[_root_.java.lang.Boolean]
def Scalaactivated_=(value : _root_.java.lang.Boolean)={this.KersetActivated(value)}
var links : java.util.List[_root_.kermeta.ki.malai.instrument.Link] = new java.util.ArrayList[_root_.kermeta.ki.malai.instrument.Link]
def KergetLinks() : java.util.List[_root_.kermeta.ki.malai.instrument.Link]={this.links}
def KersetLinks(arg:java.util.List[_root_.kermeta.ki.malai.instrument.Link])={ this.links = arg}
def Scalalinks : java.util.List[_root_.kermeta.ki.malai.instrument.Link]={this.KergetLinks()}.asInstanceOf[java.util.List[_root_.kermeta.ki.malai.instrument.Link]]
def Scalalinks_=(value : java.util.List[_root_.kermeta.ki.malai.instrument.Link])={this.KergetLinks().clear
this.KergetLinks().addAll(value)
}

    def addLink(link : _root_.kermeta.ki.malai.instrument.Link, picker : _root_.kermeta.ki.malai.picking.Picker, pickable : _root_.kermeta.ki.malai.picking.Pickable, eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager, execute : java.lang.Boolean):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(link).initialise(this, eventManager, false)
(link).Scalaexecute = execute;
if (kermeta.standard.RichFactory.isVoid((pickable)))

{
(link).setPickerToInteraction(picker)}
else 


{
(link).setPickableToInteraction(pickable)}

(Scalalinks).addUnique(link)}
 return result
}

    def initialise(actionRegistry : _root_.kermeta.ki.malai.action.ActionRegistry):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
Scalaactivated = false;
(this).ScalaactionRegistry = actionRegistry;}
 return result
}

    def `setActivatedEMF_renameAs`(activated : java.lang.Boolean):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).Scalaactivated = activated;
(Scalalinks).each({(link)=>

{
(link).setActivated(activated)}
})
interimFeedback()}
 return result
}

    def initialiseLinks(eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager):Unit

    def interimFeedback():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.instrument.Instrument"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

