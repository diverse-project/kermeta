package kermeta.ki.malai.interaction
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait StateMachineAspect  extends kermeta.ki.malai.interaction.EventHandlerAspect with kermeta.ki.malai.interaction.StateMachine{
var eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager= _
def KergetEventManager() : _root_.kermeta.ki.malai.interaction.event.EventManager={this.eventManager}
def KersetEventManager(arg:_root_.kermeta.ki.malai.interaction.event.EventManager)={ this.eventManager = arg}
def ScalaeventManager : _root_.kermeta.ki.malai.interaction.event.EventManager={this.KergetEventManager()}.asInstanceOf[_root_.kermeta.ki.malai.interaction.event.EventManager]
def ScalaeventManager_=(value : _root_.kermeta.ki.malai.interaction.event.EventManager)={this.KersetEventManager(value)}
var currentState : _root_.kermeta.ki.malai.interaction.State= _
def KergetCurrentState() : _root_.kermeta.ki.malai.interaction.State={this.currentState}
def KersetCurrentState(arg:_root_.kermeta.ki.malai.interaction.State)={ this.currentState = arg}
def ScalacurrentState : _root_.kermeta.ki.malai.interaction.State={this.KergetCurrentState()}.asInstanceOf[_root_.kermeta.ki.malai.interaction.State]
def ScalacurrentState_=(value : _root_.kermeta.ki.malai.interaction.State)={this.KersetCurrentState(value)}
var activated : _root_.java.lang.Boolean= _
def KergetActivated() : _root_.java.lang.Boolean={this.activated}
def KersetActivated(arg:_root_.java.lang.Boolean)={ this.activated = arg}
def Scalaactivated : _root_.java.lang.Boolean={this.KergetActivated()}.asInstanceOf[_root_.java.lang.Boolean]
def Scalaactivated_=(value : _root_.java.lang.Boolean)={this.KersetActivated(value)}
var states : java.util.List[_root_.kermeta.ki.malai.interaction.State] = new java.util.ArrayList[_root_.kermeta.ki.malai.interaction.State]
def KergetStates() : java.util.List[_root_.kermeta.ki.malai.interaction.State]={this.states}
def KersetStates(arg:java.util.List[_root_.kermeta.ki.malai.interaction.State])={ this.states = arg}
def Scalastates : java.util.List[_root_.kermeta.ki.malai.interaction.State]={this.KergetStates()}.asInstanceOf[java.util.List[_root_.kermeta.ki.malai.interaction.State]]
def Scalastates_=(value : java.util.List[_root_.kermeta.ki.malai.interaction.State])={this.KergetStates().clear
this.KergetStates().addAll(value)
}
var initState : _root_.kermeta.ki.malai.interaction.InitState= _
def KergetInitState() : _root_.kermeta.ki.malai.interaction.InitState={this.initState}
def KersetInitState(arg:_root_.kermeta.ki.malai.interaction.InitState)={ this.initState = arg}
def ScalainitState : _root_.kermeta.ki.malai.interaction.InitState={this.KergetInitState()}.asInstanceOf[_root_.kermeta.ki.malai.interaction.InitState]
def ScalainitState_=(value : _root_.kermeta.ki.malai.interaction.InitState)={this.KersetInitState(value)}

    override def onTextChanged(textCompName : _root_.java.lang.String, TextValue : _root_.java.lang.String):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if (Scalaactivated)

{
var stop : _root_.java.lang.Boolean = false;
((ScalacurrentState).Scalatransitions).exists({(t)=>

{
if ((t).isInstanceOf[_root_.kermeta.ki.malai.interaction.TextChangedTransition])

{
var tct : _root_.kermeta.ki.malai.interaction.TextChangedTransition = (t).asInstanceOf[_root_.kermeta.ki.malai.interaction.TextChangedTransition];
(tct).ScalatextCompName = textCompName;
(tct).Scalatext = TextValue;
if ((t).isGuardRespected())

{
stop = true;
executeTransition(t)}
}

stop}
})}
}
 return result
}

    override def onRelease(button : java.lang.Integer, px : _root_.java.lang.Double, py : _root_.java.lang.Double, idHID : java.lang.Integer):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if (Scalaactivated)

{
var stop : _root_.java.lang.Boolean = false;
var t : _root_.kermeta.ki.malai.interaction.Transition = null.asInstanceOf[_root_.kermeta.ki.malai.interaction.Transition];
((ScalacurrentState).Scalatransitions).exists({(t)=>

{
if ((t).isInstanceOf[_root_.kermeta.ki.malai.interaction.ReleaseTransition])

{
var rt : _root_.kermeta.ki.malai.interaction.ReleaseTransition = (t).asInstanceOf[_root_.kermeta.ki.malai.interaction.ReleaseTransition];
(rt).Scalapx = px;
(rt).Scalapy = py;
(rt).Scalabutton = button;
if ((t).isGuardRespected())

{
stop = true;
executeTransition(t)}
}

stop}
})}
}
 return result
}

    def executeTransition(t : _root_.kermeta.ki.malai.interaction.Transition):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if (Scalaactivated)

{


try {
 (t).action()
 (ScalacurrentState).onOutgoing()
 ScalacurrentState = (t).ScalaoutputState;
 (ScalacurrentState).onIngoing() 
} catch {
 case ex:_root_.kermeta.exceptions.Exception => {reinit()
 }
 }
}
}
 return result
}

    override def onKeyRelease(key : java.lang.Integer, idHID : java.lang.Integer):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if (Scalaactivated)

{
var stop : _root_.java.lang.Boolean = false;
var t : _root_.kermeta.ki.malai.interaction.Transition = null.asInstanceOf[_root_.kermeta.ki.malai.interaction.Transition];
((ScalacurrentState).Scalatransitions).exists({(t)=>

{
if ((t).isInstanceOf[_root_.kermeta.ki.malai.interaction.KeyReleaseTransition])

{
((t).asInstanceOf[_root_.kermeta.ki.malai.interaction.KeyReleaseTransition]).Scalakey = key;
if ((t).isGuardRespected())

{
stop = true;
executeTransition(t)}
}

stop}
})}
}
 return result
}

    override def onButtonPressed(button : _root_.kermeta.ki.malai.widget.Button):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if (Scalaactivated)

{
var stop : _root_.java.lang.Boolean = false;
var t : _root_.kermeta.ki.malai.interaction.Transition = null.asInstanceOf[_root_.kermeta.ki.malai.interaction.Transition];
((ScalacurrentState).Scalatransitions).exists({(t)=>

{
if ((t).isInstanceOf[_root_.kermeta.ki.malai.interaction.ButtonPressedTransition])

{
((t).asInstanceOf[_root_.kermeta.ki.malai.interaction.ButtonPressedTransition]).Scalabutton = button;
if ((t).isGuardRespected())

{
stop = true;
executeTransition(t)}
}

stop}
})}
}
 return result
}

    override def onKeyPressure(key : java.lang.Integer, idHID : java.lang.Integer):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if (Scalaactivated)

{
var stop : _root_.java.lang.Boolean = false;
var t : _root_.kermeta.ki.malai.interaction.Transition = null.asInstanceOf[_root_.kermeta.ki.malai.interaction.Transition];
((ScalacurrentState).Scalatransitions).exists({(t)=>

{
if ((t).isInstanceOf[_root_.kermeta.ki.malai.interaction.KeyPressureTransition])

{
((t).asInstanceOf[_root_.kermeta.ki.malai.interaction.KeyPressureTransition]).Scalakey = key;
if ((t).isGuardRespected())

{
stop = true;
executeTransition(t)}
}

stop}
})}
}
 return result
}

    def isRunning():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = ((Scalaactivated)).and((ScalacurrentState) != (ScalainitState));}
 return result
}

    def initialise(eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).ScalaeventManager = eventManager;
Scalaactivated = true;
ScalainitState = kermeta.ki.malai.interaction.RichFactory.createInitState;
(ScalainitState).initialise("init")
addState(ScalainitState)
reinit()
initStateMachine()}
 return result
}

    def initStateMachine():Unit

    override def onPressure(button : java.lang.Integer, px : _root_.java.lang.Double, py : _root_.java.lang.Double, idHID : java.lang.Integer):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if (Scalaactivated)

{
var stop : _root_.java.lang.Boolean = false;
var t : _root_.kermeta.ki.malai.interaction.Transition = null.asInstanceOf[_root_.kermeta.ki.malai.interaction.Transition];
((ScalacurrentState).Scalatransitions).exists({(t)=>

{
if ((t).isInstanceOf[_root_.kermeta.ki.malai.interaction.PressureTransition])

{
var pt : _root_.kermeta.ki.malai.interaction.PressureTransition = (t).asInstanceOf[_root_.kermeta.ki.malai.interaction.PressureTransition];
(pt).Scalapx = px;
(pt).Scalapy = py;
(pt).Scalabutton = button;
if ((t).isGuardRespected())

{
stop = true;
executeTransition(t)}
}

stop}
})}
}
 return result
}

    override def onWheel(px : _root_.java.lang.Double, py : _root_.java.lang.Double, isUp : java.lang.Boolean, increment : java.lang.Integer, idHID : java.lang.Integer):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if (Scalaactivated)

{
var stop : _root_.java.lang.Boolean = false;
var t : _root_.kermeta.ki.malai.interaction.Transition = null.asInstanceOf[_root_.kermeta.ki.malai.interaction.Transition];
((ScalacurrentState).Scalatransitions).exists({(t)=>

{
if ((t).isInstanceOf[_root_.kermeta.ki.malai.interaction.WheelTransition])

{
var wt : _root_.kermeta.ki.malai.interaction.WheelTransition = (t).asInstanceOf[_root_.kermeta.ki.malai.interaction.WheelTransition];
(wt).Scalapx = px;
(wt).Scalapy = py;
(wt).ScalaisUp = isUp;
(wt).Scalaincrement = increment;
if ((t).isGuardRespected())

{
stop = true;
executeTransition(t)}
}

stop}
})}
}
 return result
}

    def `setActivatedEMF_renameAs`(activated : java.lang.Boolean):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).Scalaactivated = activated;}
 return result
}

    def reinit():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
ScalacurrentState = ScalainitState;}
 return result
}

    def addState(state : _root_.kermeta.ki.malai.interaction.State):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if ((state) != (null))

{
(Scalastates).addUnique(state)
(state).ScalastateMachine = this;}
}
 return result
}

    override def onMove(button : java.lang.Integer, px : _root_.java.lang.Double, py : _root_.java.lang.Double, pressed : java.lang.Boolean, idHID : java.lang.Integer):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if (Scalaactivated)

{
var stop : _root_.java.lang.Boolean = false;
var t : _root_.kermeta.ki.malai.interaction.Transition = null.asInstanceOf[_root_.kermeta.ki.malai.interaction.Transition];
((ScalacurrentState).Scalatransitions).exists({(t)=>

{
if ((t).isInstanceOf[_root_.kermeta.ki.malai.interaction.MoveTransition])

{
var mt : _root_.kermeta.ki.malai.interaction.MoveTransition = (t).asInstanceOf[_root_.kermeta.ki.malai.interaction.MoveTransition];
(mt).Scalapx = px;
(mt).Scalapy = py;
(mt).Scalabutton = button;
(mt).Scalapressed = pressed;
if ((t).isGuardRespected())

{
stop = true;
executeTransition(t)}
}

stop}
})}
}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.interaction.StateMachine"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

