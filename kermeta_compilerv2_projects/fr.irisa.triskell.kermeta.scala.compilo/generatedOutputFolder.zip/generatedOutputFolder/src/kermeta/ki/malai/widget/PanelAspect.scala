package kermeta.ki.malai.widget
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait PanelAspect  extends kermeta.ki.malai.widget.GraphicalComponentAspect with kermeta.ki.malai.picking.PickerAspect with kermeta.ki.malai.widget.Panel{
var components : java.util.List[_root_.kermeta.ki.malai.widget.GraphicalComponent] = new java.util.ArrayList[_root_.kermeta.ki.malai.widget.GraphicalComponent]
def KergetComponents() : java.util.List[_root_.kermeta.ki.malai.widget.GraphicalComponent]={this.components}
def KersetComponents(arg:java.util.List[_root_.kermeta.ki.malai.widget.GraphicalComponent])={ this.components = arg}
def Scalacomponents : java.util.List[_root_.kermeta.ki.malai.widget.GraphicalComponent]={this.KergetComponents()}.asInstanceOf[java.util.List[_root_.kermeta.ki.malai.widget.GraphicalComponent]]
def Scalacomponents_=(value : java.util.List[_root_.kermeta.ki.malai.widget.GraphicalComponent])={this.KergetComponents().clear
this.KergetComponents().addAll(value)
}

    override def getPickableAt(px : _root_.java.lang.Double, py : _root_.java.lang.Double):_root_.kermeta.ki.malai.picking.Pickable = {
var result : _root_.kermeta.ki.malai.picking.Pickable = null.asInstanceOf[_root_.kermeta.ki.malai.picking.Pickable]; 


{
(Scalacomponents).exists({(c)=>

{
if (((c).isInstanceOf[_root_.kermeta.ki.malai.picking.Pickable]).andThen({(b)=>

{
(c).contains(px, py)}
}))

{
result = c;}
else 


{
if ((c).isInstanceOf[_root_.kermeta.ki.malai.picking.Picker])

{
result = ((c).asInstanceOf[_root_.kermeta.ki.malai.picking.Picker]).getPickableAt((px).minus(((c).getX()).toReal()), (py).minus(((c).getY()).toReal()));}
}

(kermeta.standard.RichFactory.isVoid((result))).not()}
})}
 return result
}

    def hasScrollbars():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
try{
result = org.kermeta.ki.malai.widget.Panel.hasScrollbars(this).asInstanceOf[_root_.java.lang.Boolean];
}catch { case e:ClassCastException => {}}
}
 return result
}

    def scrollHorizontally(increment : java.lang.Integer):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
org.kermeta.ki.malai.widget.Panel.scrollHorizontally(this,increment)}
 return result
}

    override def getPickerAt(px : _root_.java.lang.Double, py : _root_.java.lang.Double):_root_.kermeta.ki.malai.picking.Picker = {
var result : _root_.kermeta.ki.malai.picking.Picker = null.asInstanceOf[_root_.kermeta.ki.malai.picking.Picker]; 


{
result = ((Scalacomponents).detect({(c)=>

{
((c).isInstanceOf[_root_.kermeta.ki.malai.picking.Picker]).andThen({(b)=>

{
(c).contains(px, py)}
})}
})).asInstanceOf[_root_.kermeta.ki.malai.picking.Picker];}
 return result
}

    override def containsObject(obj : _root_.fr.irisa.triskell.kermeta.language.structure.Object):java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = (Scalacomponents).exists({(c)=>

{
(((c) == (obj))).orElse({(b)=>

{
((c).isInstanceOf[_root_.kermeta.ki.malai.picking.Picker]).andThen({(b)=>

{
((c).asInstanceOf[_root_.kermeta.ki.malai.picking.Picker]).containsObject(obj)}
})}
})}
});}
 return result
}

    def isHorizontalScrollbarVisible():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
try{
result = org.kermeta.ki.malai.widget.Panel.isHorizontalScrollbarVisible(this).asInstanceOf[_root_.java.lang.Boolean];
}catch { case e:ClassCastException => {}}
}
 return result
}

    override def initialise(eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
org.kermeta.ki.malai.widget.Panel.initialise(this,eventManager)}
 return result
}

    def scrollVertically(increment : java.lang.Integer):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
org.kermeta.ki.malai.widget.Panel.scrollVertically(this,increment)}
 return result
}

    def isVerticalScrollbarVisible():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
try{
result = org.kermeta.ki.malai.widget.Panel.isVerticalScrollbarVisible(this).asInstanceOf[_root_.java.lang.Boolean];
}catch { case e:ClassCastException => {}}
}
 return result
}

    def addComponent(component : _root_.kermeta.ki.malai.widget.GraphicalComponent):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(Scalacomponents).addUnique(component)
org.kermeta.ki.malai.widget.Panel.add(this,component)}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.widget.Panel"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

