package kermeta.ki.malai.action
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait ScrollAspect  extends kermeta.ki.malai.action.ActionAspect with kermeta.ki.malai.action.Scroll{
var panel : _root_.kermeta.ki.malai.widget.Panel= _
def KergetPanel() : _root_.kermeta.ki.malai.widget.Panel={this.panel}
def KersetPanel(arg:_root_.kermeta.ki.malai.widget.Panel)={ this.panel = arg}
def Scalapanel : _root_.kermeta.ki.malai.widget.Panel={this.KergetPanel()}.asInstanceOf[_root_.kermeta.ki.malai.widget.Panel]
def Scalapanel_=(value : _root_.kermeta.ki.malai.widget.Panel)={this.KersetPanel(value)}
var increment : Int= _
def KergetIncrement() : Int={this.increment}
def KersetIncrement(arg:Int)={ this.increment = arg}
def Scalaincrement : Int={this.KergetIncrement()}.asInstanceOf[Int]
def Scalaincrement_=(value : Int)={this.KersetIncrement(value)}

    override def canDo():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = ((((kermeta.standard.RichFactory.isVoid((Scalapanel))).andThen({(b)=>

{
(Scalapanel).hasScrollbars()}
})).not())).and((kermeta.standard.RichFactory.isVoid((Scalaincrement))).not());}
 return result
}

    override def hadEffect():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = isDone();}
 return result
}

    override def cancelledBy(action : _root_.fr.irisa.triskell.kermeta.language.structure.Class):java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = false;}
 return result
}

    override def isRegisterable():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = false;}
 return result
}

    override def doActionBody():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if ((Scalapanel).isVerticalScrollbarVisible())

{
(Scalapanel).scrollVertically(Scalaincrement)}
else 


{
(Scalapanel).scrollHorizontally(Scalaincrement)}

Scaladone}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.action.Scroll"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

