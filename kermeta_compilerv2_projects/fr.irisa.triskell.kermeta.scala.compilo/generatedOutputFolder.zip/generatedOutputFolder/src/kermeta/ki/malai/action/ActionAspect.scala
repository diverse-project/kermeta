package kermeta.ki.malai.action
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait ActionAspect  extends ScalaAspect.fr.irisa.triskell.kermeta.language.structure.ObjectAspect with kermeta.ki.malai.action.Action{
var actionRegistry : _root_.kermeta.ki.malai.action.ActionRegistry= _
def KergetActionRegistry() : _root_.kermeta.ki.malai.action.ActionRegistry={this.actionRegistry}
def KersetActionRegistry(arg:_root_.kermeta.ki.malai.action.ActionRegistry)={ this.actionRegistry = arg}
def ScalaactionRegistry : _root_.kermeta.ki.malai.action.ActionRegistry={this.KergetActionRegistry()}.asInstanceOf[_root_.kermeta.ki.malai.action.ActionRegistry]
def ScalaactionRegistry_=(value : _root_.kermeta.ki.malai.action.ActionRegistry)={this.KersetActionRegistry(value)}
var done : _root_.java.lang.Boolean= _
def KergetDone() : _root_.java.lang.Boolean={this.done}
def KersetDone(arg:_root_.java.lang.Boolean)={ this.done = arg}
def Scaladone : _root_.java.lang.Boolean={this.KergetDone()}.asInstanceOf[_root_.java.lang.Boolean]
def Scaladone_=(value : _root_.java.lang.Boolean)={this.KersetDone(value)}
var started : _root_.java.lang.Boolean= _
def KergetStarted() : _root_.java.lang.Boolean={this.started}
def KersetStarted(arg:_root_.java.lang.Boolean)={ this.started = arg}
def Scalastarted : _root_.java.lang.Boolean={this.KergetStarted()}.asInstanceOf[_root_.java.lang.Boolean]
def Scalastarted_=(value : _root_.java.lang.Boolean)={this.KersetStarted(value)}

    def doIt():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
if (canDo())

{
Scalastarted = true;
result = true;
doActionBody()
((ScalaactionRegistry).Scalahandlers).each({(h)=>

{
(h).onActionExecuted(this)}
})}
else 


{
result = false;}
}
 return result
}

    def isDone():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = Scaladone;}
 return result
}

    def canDo():java.lang.Boolean

    def hadEffect():java.lang.Boolean

    def isRegisterable():java.lang.Boolean

    def cancelledBy(action : _root_.fr.irisa.triskell.kermeta.language.structure.Class):java.lang.Boolean

    def initialise(actionRegistry : _root_.kermeta.ki.malai.action.ActionRegistry):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
Scaladone = false;
Scalastarted = false;
(this).ScalaactionRegistry = actionRegistry;}
 return result
}

    def `setDoneEMF_renameAs`():Unit = {
var result : _root_.kermeta.standard.Void = null.asInstanceOf[_root_.kermeta.standard.Void]; 


{
Scaladone = true;}
 return result
}

    def isStarted():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = Scalastarted;}
 return result
}

    def `setStartedEMF_renameAs`(started : java.lang.Boolean):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).Scalastarted = started;}
 return result
}

    def doActionBody():Unit = {
var result : _root_.kermeta.standard.Void = null.asInstanceOf[_root_.kermeta.standard.Void]; 


{
}
 return result
}

    def abort():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
Scaladone}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.action.Action"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

