package kermeta.ki.malai.interaction
trait CtrlMultiPress extends kermeta.ki.malai.interaction.Interaction{

    override def initStateMachine() : Unit
    override def reinit() : Unit}

