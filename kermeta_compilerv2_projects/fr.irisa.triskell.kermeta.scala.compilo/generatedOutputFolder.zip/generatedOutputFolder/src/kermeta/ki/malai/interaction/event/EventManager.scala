package kermeta.ki.malai.interaction.event
trait EventManager extends kermeta.ki.malai.dispatcher.Dispatchable{

    def process(event : _root_.kermeta.ki.malai.interaction.event.Event) : Unit
    def initialise(dispatcher : _root_.kermeta.ki.malai.dispatcher.AbstractDispatcher) : Unit
    override def run() : Unit
    override def isWaiting() : java.lang.Boolean}

