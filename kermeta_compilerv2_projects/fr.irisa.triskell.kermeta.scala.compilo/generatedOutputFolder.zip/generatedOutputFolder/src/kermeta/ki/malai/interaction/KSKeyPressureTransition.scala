package kermeta.ki.malai.interaction
trait KSKeyPressureTransition extends kermeta.ki.malai.interaction.KeyPressureTransition{

    override def action() : Unit
    override def isGuardRespected() : java.lang.Boolean}

