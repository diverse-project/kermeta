package kermeta.ki.malai.interaction
trait ButtonPressed extends kermeta.ki.malai.interaction.Interaction{

    override def initStateMachine() : Unit
    override def reinit() : Unit}

