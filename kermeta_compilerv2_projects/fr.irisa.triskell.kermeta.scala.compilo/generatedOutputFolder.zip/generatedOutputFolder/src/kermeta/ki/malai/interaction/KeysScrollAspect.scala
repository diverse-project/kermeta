package kermeta.ki.malai.interaction
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait KeysScrollAspect  extends kermeta.ki.malai.interaction.InteractionAspect with kermeta.ki.malai.interaction.KeysScroll{
var px : _root_.java.lang.Double= _
def KergetPx() : _root_.java.lang.Double={this.px}
def KersetPx(arg:_root_.java.lang.Double)={ this.px = arg}
def Scalapx : _root_.java.lang.Double={this.KergetPx()}.asInstanceOf[_root_.java.lang.Double]
def Scalapx_=(value : _root_.java.lang.Double)={this.KersetPx(value)}
var py : _root_.java.lang.Double= _
def KergetPy() : _root_.java.lang.Double={this.py}
def KersetPy(arg:_root_.java.lang.Double)={ this.py = arg}
def Scalapy : _root_.java.lang.Double={this.KergetPy()}.asInstanceOf[_root_.java.lang.Double]
def Scalapy_=(value : _root_.java.lang.Double)={this.KersetPy(value)}
var keys : java.util.List[Int] = new java.util.ArrayList[Int]
def KergetKeys() : java.util.List[Int]={this.keys}
def KersetKeys(arg:java.util.List[Int])={ this.keys = arg}
def Scalakeys : java.util.List[Int]={this.KergetKeys()}.asInstanceOf[java.util.List[Int]]
def Scalakeys_=(value : java.util.List[Int])={this.KergetKeys().clear
this.KergetKeys().addAll(value)
}
var `object` : _root_.kermeta.ki.malai.picking.Pickable= _
def KergetObject() : _root_.kermeta.ki.malai.picking.Pickable={this.`object`}
def KersetObject(arg:_root_.kermeta.ki.malai.picking.Pickable)={ this.`object` = arg}
def Scalaobject : _root_.kermeta.ki.malai.picking.Pickable={this.KergetObject()}.asInstanceOf[_root_.kermeta.ki.malai.picking.Pickable]
def Scalaobject_=(value : _root_.kermeta.ki.malai.picking.Pickable)={this.KersetObject(value)}
var numberUp : Int= _
def KergetNumberUp() : Int={this.numberUp}
def KersetNumberUp(arg:Int)={ this.numberUp = arg}
def ScalanumberUp : Int={this.KergetNumberUp()}.asInstanceOf[Int]
def ScalanumberUp_=(value : Int)={this.KersetNumberUp(value)}

    override def initStateMachine():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var key : _root_.kermeta.ki.malai.interaction.State = kermeta.ki.malai.interaction.RichFactory.createIntermediaryState;
var scroll : _root_.kermeta.ki.malai.interaction.State = kermeta.ki.malai.interaction.RichFactory.createIntermediaryState;
var ending : _root_.kermeta.ki.malai.interaction.State = kermeta.ki.malai.interaction.RichFactory.createTerminalState;
var abort : _root_.kermeta.ki.malai.interaction.State = kermeta.ki.malai.interaction.RichFactory.createAbortingState;
(ending).initialise("ending")
(key).initialise("key")
(scroll).initialise("scroll")
(abort).initialise("abort")
addState(key)
addState(scroll)
addState(ending)
addState(abort)
var kp : _root_.kermeta.ki.malai.interaction.KSKeyPressureTransition = kermeta.ki.malai.interaction.RichFactory.createKSKeyPressureTransition;
(kp).ScalakeysScroll = this;
(kp).initialise(ScalainitState, key)
kp = kermeta.ki.malai.interaction.RichFactory.createKSKeyPressureTransition;
(kp).ScalakeysScroll = this;
(kp).initialise(key, key)
var krEmpty : _root_.kermeta.ki.malai.interaction.EmptyKeyReleaseTransition = kermeta.ki.malai.interaction.RichFactory.createEmptyKeyReleaseTransition;
(krEmpty).ScalakeysScroll = this;
(krEmpty).initialise(key, abort)
var kr : _root_.kermeta.ki.malai.interaction.KSKeyReleaseTransition = kermeta.ki.malai.interaction.RichFactory.createKSKeyReleaseTransition;
(kp).ScalakeysScroll = this;
(kr).initialise(key, key)
var wt : _root_.kermeta.ki.malai.interaction.KSWheelTransition = kermeta.ki.malai.interaction.RichFactory.createKSWheelTransition;
(wt).ScalakeysScroll = this;
(wt).initialise(ScalainitState, ending)
wt = kermeta.ki.malai.interaction.RichFactory.createKSWheelTransition;
(wt).ScalakeysScroll = this;
(wt).initialise(key, scroll)
wt = kermeta.ki.malai.interaction.RichFactory.createKSWheelTransition;
(wt).ScalakeysScroll = this;
(wt).initialise(scroll, scroll)
kr = kermeta.ki.malai.interaction.RichFactory.createKSKeyReleaseTransition;
(kr).ScalakeysScroll = this;
(kr).initialise(scroll, scroll)
kp = kermeta.ki.malai.interaction.RichFactory.createKSKeyPressureTransition;
(kp).ScalakeysScroll = this;
(kp).initialise(scroll, scroll)
krEmpty = kermeta.ki.malai.interaction.RichFactory.createEmptyKeyReleaseTransition;
(krEmpty).ScalakeysScroll = this;
(krEmpty).initialise(scroll, ending)}
 return result
}

    override def reinit():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
super[InteractionAspect].reinit()
(Scalakeys).clear()
Scalaobject = null.asInstanceOf[_root_.kermeta.ki.malai.picking.Pickable];
Scalapx = null.asInstanceOf[_root_.java.lang.Double];
Scalapy = null.asInstanceOf[_root_.java.lang.Double];
ScalanumberUp = 0;}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.interaction.KeysScroll"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

