package kermeta.ki.malai.interaction
trait KSWheelTransition extends kermeta.ki.malai.interaction.WheelTransition{

    override def action() : Unit
    override def isGuardRespected() : java.lang.Boolean}

