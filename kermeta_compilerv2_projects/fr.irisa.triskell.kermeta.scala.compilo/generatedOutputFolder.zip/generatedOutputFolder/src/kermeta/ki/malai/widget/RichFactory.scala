package kermeta.ki.malai.widget
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
object RichFactory{
 def createButton : kermeta.ki.malai.widget.Button = { new kermeta.ki.malai.widget.RichButton }
 def createToggleButton : kermeta.ki.malai.widget.ToggleButton = { new kermeta.ki.malai.widget.RichToggleButton }
 def createPanel : kermeta.ki.malai.widget.Panel = { new kermeta.ki.malai.widget.RichPanel }
}

