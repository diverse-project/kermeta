package kermeta.ki.malai.interaction
trait CtrlMultiPressEscapeKeyPressureTransition extends kermeta.ki.malai.interaction.KeyPressureTransition{

    override def isGuardRespected() : java.lang.Boolean}

