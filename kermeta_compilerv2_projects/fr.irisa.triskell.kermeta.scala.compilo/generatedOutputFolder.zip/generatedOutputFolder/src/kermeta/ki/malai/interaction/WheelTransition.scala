package kermeta.ki.malai.interaction
trait WheelTransition extends kermeta.ki.malai.interaction.PointingDeviceTransition{

    override def initialise(inputState : _root_.kermeta.ki.malai.interaction.State, outputState : _root_.kermeta.ki.malai.interaction.State) : Unit}

