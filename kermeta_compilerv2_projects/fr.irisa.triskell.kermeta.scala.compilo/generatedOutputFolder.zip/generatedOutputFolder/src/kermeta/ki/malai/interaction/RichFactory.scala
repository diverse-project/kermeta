package kermeta.ki.malai.interaction
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
object RichFactory{
 def createCtrlMultiPress : kermeta.ki.malai.interaction.CtrlMultiPress = { new kermeta.ki.malai.interaction.RichCtrlMultiPress }
 def createCtrlMultiPressPressureTransition : kermeta.ki.malai.interaction.CtrlMultiPressPressureTransition = { new kermeta.ki.malai.interaction.RichCtrlMultiPressPressureTransition }
 def createCtrlMultiPressKeyPressureTransition : kermeta.ki.malai.interaction.CtrlMultiPressKeyPressureTransition = { new kermeta.ki.malai.interaction.RichCtrlMultiPressKeyPressureTransition }
 def createCtrlMultiPressEscapeKeyPressureTransition : kermeta.ki.malai.interaction.CtrlMultiPressEscapeKeyPressureTransition = { new kermeta.ki.malai.interaction.RichCtrlMultiPressEscapeKeyPressureTransition }
 def createPress : kermeta.ki.malai.interaction.Press = { new kermeta.ki.malai.interaction.RichPress }
 def createPressPressureTransition : kermeta.ki.malai.interaction.PressPressureTransition = { new kermeta.ki.malai.interaction.RichPressPressureTransition }
 def createButtonPressedTransition : kermeta.ki.malai.interaction.ButtonPressedTransition = { new kermeta.ki.malai.interaction.RichButtonPressedTransition }
 def createKeyPressureTransition : kermeta.ki.malai.interaction.KeyPressureTransition = { new kermeta.ki.malai.interaction.RichKeyPressureTransition }
 def createKeyReleaseTransition : kermeta.ki.malai.interaction.KeyReleaseTransition = { new kermeta.ki.malai.interaction.RichKeyReleaseTransition }
 def createMoveTransition : kermeta.ki.malai.interaction.MoveTransition = { new kermeta.ki.malai.interaction.RichMoveTransition }
 def createWheelTransition : kermeta.ki.malai.interaction.WheelTransition = { new kermeta.ki.malai.interaction.RichWheelTransition }
 def createPressureTransition : kermeta.ki.malai.interaction.PressureTransition = { new kermeta.ki.malai.interaction.RichPressureTransition }
 def createReleaseTransition : kermeta.ki.malai.interaction.ReleaseTransition = { new kermeta.ki.malai.interaction.RichReleaseTransition }
 def createTextChangedTransition : kermeta.ki.malai.interaction.TextChangedTransition = { new kermeta.ki.malai.interaction.RichTextChangedTransition }
 def createButtonPressed : kermeta.ki.malai.interaction.ButtonPressed = { new kermeta.ki.malai.interaction.RichButtonPressed }
 def createButtonPressedPressTransition : kermeta.ki.malai.interaction.ButtonPressedPressTransition = { new kermeta.ki.malai.interaction.RichButtonPressedPressTransition }
 def createKeysScroll : kermeta.ki.malai.interaction.KeysScroll = { new kermeta.ki.malai.interaction.RichKeysScroll }
 def createKSKeyPressureTransition : kermeta.ki.malai.interaction.KSKeyPressureTransition = { new kermeta.ki.malai.interaction.RichKSKeyPressureTransition }
 def createEmptyKeyReleaseTransition : kermeta.ki.malai.interaction.EmptyKeyReleaseTransition = { new kermeta.ki.malai.interaction.RichEmptyKeyReleaseTransition }
 def createKSKeyReleaseTransition : kermeta.ki.malai.interaction.KSKeyReleaseTransition = { new kermeta.ki.malai.interaction.RichKSKeyReleaseTransition }
 def createKSWheelTransition : kermeta.ki.malai.interaction.KSWheelTransition = { new kermeta.ki.malai.interaction.RichKSWheelTransition }
 def createIntermediaryState : kermeta.ki.malai.interaction.IntermediaryState = { new kermeta.ki.malai.interaction.RichIntermediaryState }
 def createAbortingState : kermeta.ki.malai.interaction.AbortingState = { new kermeta.ki.malai.interaction.RichAbortingState }
 def createInitState : kermeta.ki.malai.interaction.InitState = { new kermeta.ki.malai.interaction.RichInitState }
 def createTerminalState : kermeta.ki.malai.interaction.TerminalState = { new kermeta.ki.malai.interaction.RichTerminalState }
}

