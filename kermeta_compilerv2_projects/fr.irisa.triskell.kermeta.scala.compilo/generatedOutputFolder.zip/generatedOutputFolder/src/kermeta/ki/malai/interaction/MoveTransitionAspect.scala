package kermeta.ki.malai.interaction
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait MoveTransitionAspect  extends kermeta.ki.malai.interaction.PointingDeviceTransitionAspect with kermeta.ki.malai.interaction.MoveTransition{
var pressed : _root_.java.lang.Boolean= _
def KergetPressed() : _root_.java.lang.Boolean={this.pressed}
def KersetPressed(arg:_root_.java.lang.Boolean)={ this.pressed = arg}
def Scalapressed : _root_.java.lang.Boolean={this.KergetPressed()}.asInstanceOf[_root_.java.lang.Boolean]
def Scalapressed_=(value : _root_.java.lang.Boolean)={this.KersetPressed(value)}

    override def initialise(inputState : _root_.kermeta.ki.malai.interaction.State, outputState : _root_.kermeta.ki.malai.interaction.State):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
super[PointingDeviceTransitionAspect].initialise(inputState,outputState)
Scalapressed = false;}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.interaction.MoveTransition"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

