package kermeta.ki.malai.instrument
trait ButtonPressed2Redo extends kermeta.ki.malai.instrument.ButtonPressLink{

    override def createAction() : Unit
    override def updateAction() : Unit
    override def getActionClass() : _root_.fr.irisa.triskell.kermeta.language.structure.Class
    override def isConditionRespected() : java.lang.Boolean}

