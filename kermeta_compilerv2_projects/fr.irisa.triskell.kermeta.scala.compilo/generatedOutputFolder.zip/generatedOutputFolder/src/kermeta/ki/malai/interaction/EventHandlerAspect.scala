package kermeta.ki.malai.interaction
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait EventHandlerAspect  extends ScalaAspect.fr.irisa.triskell.kermeta.language.structure.ObjectAspect with kermeta.ki.malai.interaction.EventHandler{

    def onTextChanged(textCompName : _root_.java.lang.String, TextValue : _root_.java.lang.String):Unit

    def onRelease(button : java.lang.Integer, px : _root_.java.lang.Double, py : _root_.java.lang.Double, idHID : java.lang.Integer):Unit

    def matches(`object` : _root_.fr.irisa.triskell.kermeta.language.structure.Object):java.lang.Boolean

    def onWheel(px : _root_.java.lang.Double, py : _root_.java.lang.Double, isUp : java.lang.Boolean, increment : java.lang.Integer, idHID : java.lang.Integer):Unit

    def onKeyRelease(key : java.lang.Integer, idHID : java.lang.Integer):Unit

    def onButtonPressed(button : _root_.kermeta.ki.malai.widget.Button):Unit

    def onKeyPressure(key : java.lang.Integer, idHID : java.lang.Integer):Unit

    def onPressure(button : java.lang.Integer, px : _root_.java.lang.Double, py : _root_.java.lang.Double, idHID : java.lang.Integer):Unit

    def onMove(button : java.lang.Integer, px : _root_.java.lang.Double, py : _root_.java.lang.Double, pressed : java.lang.Boolean, idHID : java.lang.Integer):Unit
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.interaction.EventHandler"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

