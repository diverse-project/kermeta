package kermeta.ki.malai.interaction
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait InteractionAspect  extends kermeta.ki.malai.interaction.StateMachineAspect with kermeta.ki.malai.interaction.Interaction{
var pickable : _root_.kermeta.ki.malai.picking.Pickable= _
def KergetPickable() : _root_.kermeta.ki.malai.picking.Pickable={this.pickable}
def KersetPickable(arg:_root_.kermeta.ki.malai.picking.Pickable)={ this.pickable = arg}
def Scalapickable : _root_.kermeta.ki.malai.picking.Pickable={this.KergetPickable()}.asInstanceOf[_root_.kermeta.ki.malai.picking.Pickable]
def Scalapickable_=(value : _root_.kermeta.ki.malai.picking.Pickable)={this.KersetPickable(value)}
var picker : _root_.kermeta.ki.malai.picking.Picker= _
def KergetPicker() : _root_.kermeta.ki.malai.picking.Picker={this.picker}
def KersetPicker(arg:_root_.kermeta.ki.malai.picking.Picker)={ this.picker = arg}
def Scalapicker : _root_.kermeta.ki.malai.picking.Picker={this.KergetPicker()}.asInstanceOf[_root_.kermeta.ki.malai.picking.Picker]
def Scalapicker_=(value : _root_.kermeta.ki.malai.picking.Picker)={this.KersetPicker(value)}
var handlers : java.util.List[_root_.kermeta.ki.malai.interaction.InteractionHandler] = new java.util.ArrayList[_root_.kermeta.ki.malai.interaction.InteractionHandler]
def KergetHandlers() : java.util.List[_root_.kermeta.ki.malai.interaction.InteractionHandler]={this.handlers}
def KersetHandlers(arg:java.util.List[_root_.kermeta.ki.malai.interaction.InteractionHandler])={ this.handlers = arg}
def Scalahandlers : java.util.List[_root_.kermeta.ki.malai.interaction.InteractionHandler]={this.KergetHandlers()}.asInstanceOf[java.util.List[_root_.kermeta.ki.malai.interaction.InteractionHandler]]
def Scalahandlers_=(value : java.util.List[_root_.kermeta.ki.malai.interaction.InteractionHandler])={this.KergetHandlers().clear
this.KergetHandlers().addAll(value)
}

    def getPickableAt(px : _root_.java.lang.Double, py : _root_.java.lang.Double):_root_.kermeta.ki.malai.picking.Pickable = {
var result : _root_.kermeta.ki.malai.picking.Pickable = null.asInstanceOf[_root_.kermeta.ki.malai.picking.Pickable]; 


{
if (kermeta.standard.RichFactory.isVoid((Scalapicker)))

{
result = if ((kermeta.standard.RichFactory.isVoid((Scalapickable))).orElse({(v)=>

{
(Scalapickable).contains(px, py)}
}))

{
null}
else 


{
Scalapickable}
;}
else 


{
result = (Scalapicker).getPickableAt(px, py);}
}
 return result
}

    override def matches(obj : _root_.fr.irisa.triskell.kermeta.language.structure.Object):java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = if (((((kermeta.standard.RichFactory.isVoid((obj)))).and(kermeta.standard.RichFactory.isVoid((Scalapickable))))).and(kermeta.standard.RichFactory.isVoid((Scalapicker))))

{
false}
else 


{
if (kermeta.standard.RichFactory.isVoid((Scalapicker)))

{
((Scalapickable) == (obj))}
else 


{
(((Scalapicker) == (obj))).orElse({(b)=>

{
(Scalapicker).containsObject(obj)}
})}
}
;}
 return result
}

    def notifyHandlersOnStop():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{


try {
 (Scalahandlers).each({(handler)=>

 {
 (handler).interactionStops(this)}
 }) 
} catch {
 case ex:_root_.kermeta.exceptions.Exception => {(stdio).writeln(((((ex)+"")).plus(" ")).plus((((ex).Scalamessage)+"")))
 notifyHandlersOnAborting()
 throw ex
 }
 }
}
 return result
}

    override def initialise(eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
super[StateMachineAspect].initialise(eventManager)
((eventManager).Scalahandlers).addUnique(this)}
 return result
}

    def notifyHandlersOnAborting():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(Scalahandlers).each({(handler)=>

{
(handler).interactionAborts(this)}
})}
 return result
}

    def notifyHandlersOnUpdate():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{


try {
 (Scalahandlers).each({(handler)=>

 {
 (handler).interactionUpdates(this)}
 }) 
} catch {
 case ex:_root_.kermeta.exceptions.Exception => {(stdio).writeln(((((ex)+"")).plus(" ")).plus((((ex).Scalamessage)+"")))
 notifyHandlersOnAborting()
 throw ex
 }
 }
}
 return result
}

    def notifyHandlersOnStart():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{


try {
 (Scalahandlers).each({(handler)=>

 {
 (handler).interactionStarts(this)}
 }) 
} catch {
 case ex:_root_.kermeta.exceptions.Exception => {(stdio).writeln(((((ex)+"")).plus(" ")).plus((((ex).Scalamessage)+"")))
 notifyHandlersOnAborting()
 throw ex
 }
 }
}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.interaction.Interaction"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

