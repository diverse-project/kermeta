package kermeta.ki.malai.interaction
trait TerminalState extends kermeta.ki.malai.interaction.State{

    override def onIngoing() : Unit}

