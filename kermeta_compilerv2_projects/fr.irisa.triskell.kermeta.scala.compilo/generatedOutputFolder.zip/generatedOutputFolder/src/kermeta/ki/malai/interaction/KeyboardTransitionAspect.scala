package kermeta.ki.malai.interaction
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait KeyboardTransitionAspect  extends kermeta.ki.malai.interaction.TransitionAspect with kermeta.ki.malai.interaction.KeyboardTransition{
var key : Int= _
def KergetKey() : Int={this.key}
def KersetKey(arg:Int)={ this.key = arg}
def Scalakey : Int={this.KergetKey()}.asInstanceOf[Int]
def Scalakey_=(value : Int)={this.KersetKey(value)}

    override def initialise(inputState : _root_.kermeta.ki.malai.interaction.State, outputState : _root_.kermeta.ki.malai.interaction.State):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
super[TransitionAspect].initialise(inputState,outputState)
Scalakey = (1).uminus();}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.interaction.KeyboardTransition"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

