package kermeta.ki.malai.interaction
trait ButtonPressedPressTransition extends kermeta.ki.malai.interaction.ButtonPressedTransition{

    override def action() : Unit}

