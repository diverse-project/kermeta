package kermeta.ki.malai.interaction
trait PressPressureTransition extends kermeta.ki.malai.interaction.PressureTransition{

    override def action() : Unit}

