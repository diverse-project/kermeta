package kermeta.ki.malai.dispatcher
trait Dispatchable extends fr.irisa.triskell.kermeta.language.structure.Object{

    def run() : Unit
    def isWaiting() : java.lang.Boolean}

