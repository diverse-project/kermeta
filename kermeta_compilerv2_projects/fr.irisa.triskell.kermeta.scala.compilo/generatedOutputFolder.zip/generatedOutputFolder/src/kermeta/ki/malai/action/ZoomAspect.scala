package kermeta.ki.malai.action
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait ZoomAspect  extends kermeta.ki.malai.action.ActionAspect with kermeta.ki.malai.action.Zoom{
var metamodel : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit= _
def KergetMetamodel() : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit={this.metamodel}
def KersetMetamodel(arg:_root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit)={ this.metamodel = arg}
def Scalametamodel : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit={this.KergetMetamodel()}.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit]
def Scalametamodel_=(value : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit)={this.KersetMetamodel(value)}
var increment : Int= _
def KergetIncrement() : Int={this.increment}
def KersetIncrement(arg:Int)={ this.increment = arg}
def Scalaincrement : Int={this.KergetIncrement()}.asInstanceOf[Int]
def Scalaincrement_=(value : Int)={this.KersetIncrement(value)}
var px : Int= _
def KergetPx() : Int={this.px}
def KersetPx(arg:Int)={ this.px = arg}
def Scalapx : Int={this.KergetPx()}.asInstanceOf[Int]
def Scalapx_=(value : Int)={this.KersetPx(value)}
var zoomable : _root_.kermeta.ki.malai.picking.Picker= _
def KergetZoomable() : _root_.kermeta.ki.malai.picking.Picker={this.zoomable}
def KersetZoomable(arg:_root_.kermeta.ki.malai.picking.Picker)={ this.zoomable = arg}
def Scalazoomable : _root_.kermeta.ki.malai.picking.Picker={this.KergetZoomable()}.asInstanceOf[_root_.kermeta.ki.malai.picking.Picker]
def Scalazoomable_=(value : _root_.kermeta.ki.malai.picking.Picker)={this.KersetZoomable(value)}
var py : Int= _
def KergetPy() : Int={this.py}
def KersetPy(arg:Int)={ this.py = arg}
def Scalapy : Int={this.KergetPy()}.asInstanceOf[Int]
def Scalapy_=(value : Int)={this.KersetPy(value)}
var previousIncrement : Int= _
def KergetPreviousIncrement() : Int={this.previousIncrement}
def KersetPreviousIncrement(arg:Int)={ this.previousIncrement = arg}
def ScalapreviousIncrement : Int={this.KergetPreviousIncrement()}.asInstanceOf[Int]
def ScalapreviousIncrement_=(value : Int)={this.KersetPreviousIncrement(value)}

    override def canDo():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = (((((kermeta.standard.RichFactory.isVoid((Scalazoomable))).not())).and((kermeta.standard.RichFactory.isVoid((Scalametamodel))).not()))).and((kermeta.standard.RichFactory.isVoid((Scalaincrement))).not());}
 return result
}

    override def hadEffect():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = isDone();}
 return result
}

    override def isRegisterable():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = false;}
 return result
}

    override def cancelledBy(action : _root_.fr.irisa.triskell.kermeta.language.structure.Class):java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = false;}
 return result
}

    def getZoomIncrement():_root_.java.lang.Double = {
var result : _root_.java.lang.Double = null.asInstanceOf[_root_.java.lang.Double]; 


{
result = ("0.25").toReal();}
 return result
}

    override def doActionBody():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var incr : Int = if (kermeta.standard.RichFactory.isVoid((ScalapreviousIncrement)))

{
Scalaincrement}
else 


{
(Scalaincrement).minus(ScalapreviousIncrement)}
;
if ((incr).isGreater(0))

{
org.kermeta.ki.malai.ZoomUtils.zoomIn(Scalazoomable,(getZoomIncrement()).mult((incr).toReal()))}
else 


{
org.kermeta.ki.malai.ZoomUtils.zoomOut(Scalazoomable,((getZoomIncrement()).mult((incr).toReal())).mult(((1).toReal()).uminus()))}

org.kermeta.ki.visual.view.MetamodelView.update(Scalametamodel)
Scaladone
ScalapreviousIncrement = Scalaincrement;}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.action.Zoom"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

