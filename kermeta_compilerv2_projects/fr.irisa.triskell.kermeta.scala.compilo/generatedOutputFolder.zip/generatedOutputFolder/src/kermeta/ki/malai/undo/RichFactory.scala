package kermeta.ki.malai.undo
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
object RichFactory{
 def createUndoCollector : kermeta.ki.malai.undo.UndoCollector = { new kermeta.ki.malai.undo.RichUndoCollector }
 def createUndoHandler : kermeta.ki.malai.undo.UndoHandler = { new kermeta.ki.malai.undo.RichUndoHandler }
}

