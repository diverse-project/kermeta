package kermeta.ki.malai.interaction
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait StateAspect  extends ScalaAspect.fr.irisa.triskell.kermeta.language.structure.ObjectAspect with kermeta.ki.malai.interaction.State{
var stateMachine : _root_.kermeta.ki.malai.interaction.StateMachine= _
def KergetStateMachine() : _root_.kermeta.ki.malai.interaction.StateMachine={this.stateMachine}
def KersetStateMachine(arg:_root_.kermeta.ki.malai.interaction.StateMachine)={ this.stateMachine = arg}
def ScalastateMachine : _root_.kermeta.ki.malai.interaction.StateMachine={this.KergetStateMachine()}.asInstanceOf[_root_.kermeta.ki.malai.interaction.StateMachine]
def ScalastateMachine_=(value : _root_.kermeta.ki.malai.interaction.StateMachine)={this.KersetStateMachine(value)}
var transitions : java.util.List[_root_.kermeta.ki.malai.interaction.Transition] = new java.util.ArrayList[_root_.kermeta.ki.malai.interaction.Transition]
def KergetTransitions() : java.util.List[_root_.kermeta.ki.malai.interaction.Transition]={this.transitions}
def KersetTransitions(arg:java.util.List[_root_.kermeta.ki.malai.interaction.Transition])={ this.transitions = arg}
def Scalatransitions : java.util.List[_root_.kermeta.ki.malai.interaction.Transition]={this.KergetTransitions()}.asInstanceOf[java.util.List[_root_.kermeta.ki.malai.interaction.Transition]]
def Scalatransitions_=(value : java.util.List[_root_.kermeta.ki.malai.interaction.Transition])={this.KergetTransitions().clear
this.KergetTransitions().addAll(value)
}
var name : _root_.java.lang.String= _
def KergetName() : _root_.java.lang.String={this.name}
def KersetName(arg:_root_.java.lang.String)={ this.name = arg}
def Scalaname : _root_.java.lang.String={this.KergetName()}.asInstanceOf[_root_.java.lang.String]
def Scalaname_=(value : _root_.java.lang.String)={this.KersetName(value)}

    def initialise(name : _root_.java.lang.String):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).Scalaname = name;}
 return result
}

    def onOutgoing():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
}
 return result
}

    override def toString():_root_.java.lang.String = {
var result : _root_.java.lang.String = null.asInstanceOf[_root_.java.lang.String]; 


{
result = (((super[ObjectAspect].toString()).plus("[")).plus(Scalaname)).plus(", ");
(Scalatransitions).each({(t)=>

{
result = ((result).plus(((t)+""))).plus(", ");}
})
result = (result).plus("]");}
 return result
}

    def onIngoing():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
}
 return result
}

    def addTransition(trans : _root_.kermeta.ki.malai.interaction.Transition):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if ((trans) != (null))

{
(Scalatransitions).addUnique(trans)}
}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.interaction.State"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

