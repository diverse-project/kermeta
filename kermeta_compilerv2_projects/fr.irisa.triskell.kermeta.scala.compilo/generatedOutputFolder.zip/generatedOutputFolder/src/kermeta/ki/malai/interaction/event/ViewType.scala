package kermeta.ki.malai.interaction.event
 class RichMouseWheelEvent extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.interaction.event.MouseWheelEvent with kermeta.ki.malai.interaction.event.MouseWheelEventAspect 
 class RichKeyEvent extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.interaction.event.KeyEvent with kermeta.ki.malai.interaction.event.KeyEventAspect 
 abstract class RichInputEvent extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.interaction.event.InputEvent with kermeta.ki.malai.interaction.event.InputEventAspect 
 class RichEvent extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.interaction.event.Event with kermeta.ki.malai.interaction.event.EventAspect 
 class RichMouseEvent extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.interaction.event.MouseEvent with kermeta.ki.malai.interaction.event.MouseEventAspect 
 class RichEventManager extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.interaction.event.EventManager with kermeta.ki.malai.interaction.event.EventManagerAspect 
 abstract class RichAWTEvent extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.interaction.event.AWTEvent with kermeta.ki.malai.interaction.event.AWTEventAspect 
 class RichActionEvent extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.interaction.event.ActionEvent with kermeta.ki.malai.interaction.event.ActionEventAspect 

