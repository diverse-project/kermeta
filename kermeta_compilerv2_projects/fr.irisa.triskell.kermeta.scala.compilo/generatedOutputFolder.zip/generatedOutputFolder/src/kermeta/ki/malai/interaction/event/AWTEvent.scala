package kermeta.ki.malai.interaction.event
trait AWTEvent extends fr.irisa.triskell.kermeta.language.structure.Object{

    def getSourceObject() : _root_.fr.irisa.triskell.kermeta.language.structure.Object}

