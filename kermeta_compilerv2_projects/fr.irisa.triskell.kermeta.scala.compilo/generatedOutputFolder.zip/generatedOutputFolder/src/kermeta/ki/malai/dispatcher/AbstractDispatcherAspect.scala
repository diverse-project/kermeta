package kermeta.ki.malai.dispatcher
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait AbstractDispatcherAspect  extends ScalaAspect.fr.irisa.triskell.kermeta.language.structure.ObjectAspect with kermeta.ki.malai.dispatcher.AbstractDispatcher{
var running : _root_.java.lang.Boolean= _
def KergetRunning() : _root_.java.lang.Boolean={this.running}
def KersetRunning(arg:_root_.java.lang.Boolean)={ this.running = arg}
def Scalarunning : _root_.java.lang.Boolean={this.KergetRunning()}.asInstanceOf[_root_.java.lang.Boolean]
def Scalarunning_=(value : _root_.java.lang.Boolean)={this.KersetRunning(value)}

    def initialise():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
org.kermeta.ki.malai.dispatcherWrapper.DispatcherWrapper.initialise(this)}
 return result
}

    def run():Unit

    def waitForEvent():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
org.kermeta.ki.malai.dispatcherWrapper.DispatcherWrapper.waitForEvent(this)}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.dispatcher.AbstractDispatcher"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

