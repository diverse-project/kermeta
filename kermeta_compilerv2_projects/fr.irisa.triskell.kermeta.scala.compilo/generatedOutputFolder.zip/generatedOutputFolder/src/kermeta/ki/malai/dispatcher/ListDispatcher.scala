package kermeta.ki.malai.dispatcher
trait ListDispatcher extends kermeta.ki.malai.dispatcher.AbstractDispatcher{

    override def run() : Unit}

