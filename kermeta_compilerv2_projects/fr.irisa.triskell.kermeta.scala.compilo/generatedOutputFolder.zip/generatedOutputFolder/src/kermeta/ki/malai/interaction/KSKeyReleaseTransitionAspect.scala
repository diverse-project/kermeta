package kermeta.ki.malai.interaction
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait KSKeyReleaseTransitionAspect  extends kermeta.ki.malai.interaction.KeyReleaseTransitionAspect with kermeta.ki.malai.interaction.KSKeyReleaseTransition{
var keysScroll : _root_.kermeta.ki.malai.interaction.KeysScroll= _
def KergetKeysScroll() : _root_.kermeta.ki.malai.interaction.KeysScroll={this.keysScroll}
def KersetKeysScroll(arg:_root_.kermeta.ki.malai.interaction.KeysScroll)={ this.keysScroll = arg}
def ScalakeysScroll : _root_.kermeta.ki.malai.interaction.KeysScroll={this.KergetKeysScroll()}.asInstanceOf[_root_.kermeta.ki.malai.interaction.KeysScroll]
def ScalakeysScroll_=(value : _root_.kermeta.ki.malai.interaction.KeysScroll)={this.KersetKeysScroll(value)}

    override def action():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
((ScalakeysScroll).Scalakeys).remove(Scalakey)}
 return result
}

    override def isGuardRespected():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = (((ScalakeysScroll).Scalakeys).size()).isGreater(1);}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.interaction.KSKeyReleaseTransition"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

