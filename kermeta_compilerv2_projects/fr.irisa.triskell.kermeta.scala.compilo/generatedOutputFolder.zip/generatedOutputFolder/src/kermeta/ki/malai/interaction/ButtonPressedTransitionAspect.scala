package kermeta.ki.malai.interaction
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait ButtonPressedTransitionAspect  extends kermeta.ki.malai.interaction.TransitionAspect with kermeta.ki.malai.interaction.ButtonPressedTransition{
var button : _root_.kermeta.ki.malai.widget.Button= _
def KergetButton() : _root_.kermeta.ki.malai.widget.Button={this.button}
def KersetButton(arg:_root_.kermeta.ki.malai.widget.Button)={ this.button = arg}
def Scalabutton : _root_.kermeta.ki.malai.widget.Button={this.KergetButton()}.asInstanceOf[_root_.kermeta.ki.malai.widget.Button]
def Scalabutton_=(value : _root_.kermeta.ki.malai.widget.Button)={this.KersetButton(value)}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.interaction.ButtonPressedTransition"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

