package kermeta.ki.malai.dispatcher
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait SingleDispatcherAspect  extends kermeta.ki.malai.dispatcher.AbstractDispatcherAspect with kermeta.ki.malai.dispatcher.SingleDispatcher{
var process : _root_.kermeta.ki.malai.dispatcher.Dispatchable= _
def KergetProcess() : _root_.kermeta.ki.malai.dispatcher.Dispatchable={this.process}
def KersetProcess(arg:_root_.kermeta.ki.malai.dispatcher.Dispatchable)={ this.process = arg}
def Scalaprocess : _root_.kermeta.ki.malai.dispatcher.Dispatchable={this.KergetProcess()}.asInstanceOf[_root_.kermeta.ki.malai.dispatcher.Dispatchable]
def Scalaprocess_=(value : _root_.kermeta.ki.malai.dispatcher.Dispatchable)={this.KersetProcess(value)}

    override def run():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{


{Scalarunning = true;
while (!((Scalarunning).not()))


{


try {
 waitForEvent()


 {true
 while (!(((Scalaprocess).isWaiting()).not()))


 {
 Scalaprocess.run()}
 } 
} catch {
 case ex:_root_.kermeta.exceptions.Exception => {Scalarunning = false;
 }
 }
}
}
org.kermeta.ki.malai.kermetaMap.RuntimeObject2JavaMap.cleanMap(this)}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.dispatcher.SingleDispatcher"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

