package kermeta.ki.malai.undo
 class RichUndoCollector extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.undo.UndoCollector with kermeta.ki.malai.undo.UndoCollectorAspect 
 class RichUndoHandler extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.undo.UndoHandler with kermeta.ki.malai.undo.UndoHandlerAspect 
 abstract class RichUndoable extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.undo.Undoable with kermeta.ki.malai.undo.UndoableAspect 

