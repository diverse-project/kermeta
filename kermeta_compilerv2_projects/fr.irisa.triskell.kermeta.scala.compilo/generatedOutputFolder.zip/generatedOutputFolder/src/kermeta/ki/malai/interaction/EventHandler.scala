package kermeta.ki.malai.interaction
trait EventHandler extends fr.irisa.triskell.kermeta.language.structure.Object{

    def onTextChanged(textCompName : _root_.java.lang.String, TextValue : _root_.java.lang.String) : Unit
    def onRelease(button : java.lang.Integer, px : _root_.java.lang.Double, py : _root_.java.lang.Double, idHID : java.lang.Integer) : Unit
    def matches(`object` : _root_.fr.irisa.triskell.kermeta.language.structure.Object) : java.lang.Boolean
    def onWheel(px : _root_.java.lang.Double, py : _root_.java.lang.Double, isUp : java.lang.Boolean, increment : java.lang.Integer, idHID : java.lang.Integer) : Unit
    def onKeyRelease(key : java.lang.Integer, idHID : java.lang.Integer) : Unit
    def onButtonPressed(button : _root_.kermeta.ki.malai.widget.Button) : Unit
    def onKeyPressure(key : java.lang.Integer, idHID : java.lang.Integer) : Unit
    def onPressure(button : java.lang.Integer, px : _root_.java.lang.Double, py : _root_.java.lang.Double, idHID : java.lang.Integer) : Unit
    def onMove(button : java.lang.Integer, px : _root_.java.lang.Double, py : _root_.java.lang.Double, pressed : java.lang.Boolean, idHID : java.lang.Integer) : Unit}

