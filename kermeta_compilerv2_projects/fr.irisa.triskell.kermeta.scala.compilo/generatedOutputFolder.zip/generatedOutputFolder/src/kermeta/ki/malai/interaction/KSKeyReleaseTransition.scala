package kermeta.ki.malai.interaction
trait KSKeyReleaseTransition extends kermeta.ki.malai.interaction.KeyReleaseTransition{

    override def action() : Unit
    override def isGuardRespected() : java.lang.Boolean}

