package kermeta.ki.malai.interaction.event
trait InputEvent extends kermeta.ki.malai.interaction.event.AWTEvent{

    def getModifiers() : java.lang.Integer
    def getModifiersEx() : java.lang.Integer}

