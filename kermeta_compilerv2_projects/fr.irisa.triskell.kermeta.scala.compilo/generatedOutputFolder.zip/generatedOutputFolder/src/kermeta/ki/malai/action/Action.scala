package kermeta.ki.malai.action
trait Action extends fr.irisa.triskell.kermeta.language.structure.Object{

    def doIt() : java.lang.Boolean
    def isDone() : java.lang.Boolean
    def canDo() : java.lang.Boolean
    def hadEffect() : java.lang.Boolean
    def isRegisterable() : java.lang.Boolean
    def cancelledBy(action : _root_.fr.irisa.triskell.kermeta.language.structure.Class) : java.lang.Boolean
    def initialise(actionRegistry : _root_.kermeta.ki.malai.action.ActionRegistry) : Unit
    def `setDoneEMF_renameAs`() : Unit
    def isStarted() : java.lang.Boolean
    def `setStartedEMF_renameAs`(started : java.lang.Boolean) : Unit
    def doActionBody() : Unit
    def abort() : Unit}

