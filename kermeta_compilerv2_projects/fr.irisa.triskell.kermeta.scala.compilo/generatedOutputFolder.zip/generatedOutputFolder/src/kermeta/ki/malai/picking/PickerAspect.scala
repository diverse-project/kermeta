package kermeta.ki.malai.picking
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait PickerAspect  extends ScalaAspect.fr.irisa.triskell.kermeta.language.structure.ObjectAspect with kermeta.ki.malai.picking.Picker{

    def getPickableAt(px : _root_.java.lang.Double, py : _root_.java.lang.Double):_root_.kermeta.ki.malai.picking.Pickable

    def getPickerAt(px : _root_.java.lang.Double, py : _root_.java.lang.Double):_root_.kermeta.ki.malai.picking.Picker

    def containsObject(obj : _root_.fr.irisa.triskell.kermeta.language.structure.Object):java.lang.Boolean
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.picking.Picker"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

