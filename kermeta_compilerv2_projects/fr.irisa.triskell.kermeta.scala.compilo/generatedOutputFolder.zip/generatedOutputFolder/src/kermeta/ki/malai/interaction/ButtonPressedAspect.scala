package kermeta.ki.malai.interaction
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait ButtonPressedAspect  extends kermeta.ki.malai.interaction.InteractionAspect with kermeta.ki.malai.interaction.ButtonPressed{
var button : _root_.kermeta.ki.malai.widget.Button= _
def KergetButton() : _root_.kermeta.ki.malai.widget.Button={this.button}
def KersetButton(arg:_root_.kermeta.ki.malai.widget.Button)={ this.button = arg}
def Scalabutton : _root_.kermeta.ki.malai.widget.Button={this.KergetButton()}.asInstanceOf[_root_.kermeta.ki.malai.widget.Button]
def Scalabutton_=(value : _root_.kermeta.ki.malai.widget.Button)={this.KersetButton(value)}

    override def initStateMachine():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var pressed : _root_.kermeta.ki.malai.interaction.TerminalState = kermeta.ki.malai.interaction.RichFactory.createTerminalState;
(pressed).initialise("pressed")
addState(pressed)
var bppt : _root_.kermeta.ki.malai.interaction.ButtonPressedPressTransition = kermeta.ki.malai.interaction.RichFactory.createButtonPressedPressTransition;
(bppt).ScalabuttonPressed = this;
(bppt).initialise(ScalainitState, pressed)}
 return result
}

    override def reinit():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
super[InteractionAspect].reinit()
Scalabutton = null.asInstanceOf[_root_.kermeta.ki.malai.widget.Button];}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.interaction.ButtonPressed"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

