package kermeta.ki.malai.interaction
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait TextChangedTransitionAspect  extends kermeta.ki.malai.interaction.TransitionAspect with kermeta.ki.malai.interaction.TextChangedTransition{
var text : _root_.java.lang.String= _
def KergetText() : _root_.java.lang.String={this.text}
def KersetText(arg:_root_.java.lang.String)={ this.text = arg}
def Scalatext : _root_.java.lang.String={this.KergetText()}.asInstanceOf[_root_.java.lang.String]
def Scalatext_=(value : _root_.java.lang.String)={this.KersetText(value)}
var textCompName : _root_.java.lang.String= _
def KergetTextCompName() : _root_.java.lang.String={this.textCompName}
def KersetTextCompName(arg:_root_.java.lang.String)={ this.textCompName = arg}
def ScalatextCompName : _root_.java.lang.String={this.KergetTextCompName()}.asInstanceOf[_root_.java.lang.String]
def ScalatextCompName_=(value : _root_.java.lang.String)={this.KersetTextCompName(value)}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.interaction.TextChangedTransition"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

