package kermeta.ki.malai.interaction.event
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait KeyEventAspect  extends kermeta.ki.malai.interaction.event.InputEventAspect with kermeta.ki.malai.interaction.event.KeyEvent{

    def getKeyChar():_root_.java.lang.String = {
var result : _root_.java.lang.String = null.asInstanceOf[_root_.java.lang.String]; 


{
try{
result = org.kermeta.ki.malai.interaction.eventWrapper.KeyEventWrapper.getKeyChar(this).asInstanceOf[_root_.java.lang.String];
}catch { case e:ClassCastException => {}}
}
 return result
}

    def getKeyLocation():java.lang.Integer = {
var result : java.lang.Integer = null.asInstanceOf[java.lang.Integer]; 


{
try{
result = org.kermeta.ki.malai.interaction.eventWrapper.KeyEventWrapper.getKeyLocation(this).asInstanceOf[Int];
}catch { case e:ClassCastException => {}}
}
 return result
}

    def getKeyCode():java.lang.Integer = {
var result : java.lang.Integer = null.asInstanceOf[java.lang.Integer]; 


{
try{
result = org.kermeta.ki.malai.interaction.eventWrapper.KeyEventWrapper.getKeyCode(this).asInstanceOf[Int];
}catch { case e:ClassCastException => {}}
}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.interaction.event.KeyEvent"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

