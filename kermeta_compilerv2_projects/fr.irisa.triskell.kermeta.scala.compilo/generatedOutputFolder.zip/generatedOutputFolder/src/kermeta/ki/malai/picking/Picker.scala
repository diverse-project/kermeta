package kermeta.ki.malai.picking
trait Picker extends fr.irisa.triskell.kermeta.language.structure.Object{

    def getPickableAt(px : _root_.java.lang.Double, py : _root_.java.lang.Double) : _root_.kermeta.ki.malai.picking.Pickable
    def getPickerAt(px : _root_.java.lang.Double, py : _root_.java.lang.Double) : _root_.kermeta.ki.malai.picking.Picker
    def containsObject(obj : _root_.fr.irisa.triskell.kermeta.language.structure.Object) : java.lang.Boolean}

