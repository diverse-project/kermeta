package kermeta.ki.malai.action
trait ActionHandler extends fr.irisa.triskell.kermeta.language.structure.Object{

    def onActionAborted(action : _root_.kermeta.ki.malai.action.Action) : Unit
    def onActionCancelled(action : _root_.kermeta.ki.malai.action.Action) : Unit
    def onActionAdded(action : _root_.kermeta.ki.malai.action.Action) : Unit
    def onActionExecuted(action : _root_.kermeta.ki.malai.action.Action) : Unit}

