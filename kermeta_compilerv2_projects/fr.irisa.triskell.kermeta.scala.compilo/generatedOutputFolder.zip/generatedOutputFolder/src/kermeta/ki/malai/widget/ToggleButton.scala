package kermeta.ki.malai.widget
trait ToggleButton extends kermeta.ki.malai.widget.Button{
}

