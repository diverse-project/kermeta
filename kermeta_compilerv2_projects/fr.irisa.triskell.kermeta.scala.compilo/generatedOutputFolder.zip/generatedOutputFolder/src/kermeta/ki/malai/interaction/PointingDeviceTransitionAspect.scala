package kermeta.ki.malai.interaction
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait PointingDeviceTransitionAspect  extends kermeta.ki.malai.interaction.TransitionAspect with kermeta.ki.malai.interaction.PointingDeviceTransition{
var px : _root_.java.lang.Double= _
def KergetPx() : _root_.java.lang.Double={this.px}
def KersetPx(arg:_root_.java.lang.Double)={ this.px = arg}
def Scalapx : _root_.java.lang.Double={this.KergetPx()}.asInstanceOf[_root_.java.lang.Double]
def Scalapx_=(value : _root_.java.lang.Double)={this.KersetPx(value)}
var py : _root_.java.lang.Double= _
def KergetPy() : _root_.java.lang.Double={this.py}
def KersetPy(arg:_root_.java.lang.Double)={ this.py = arg}
def Scalapy : _root_.java.lang.Double={this.KergetPy()}.asInstanceOf[_root_.java.lang.Double]
def Scalapy_=(value : _root_.java.lang.Double)={this.KersetPy(value)}
var button : Int= _
def KergetButton() : Int={this.button}
def KersetButton(arg:Int)={ this.button = arg}
def Scalabutton : Int={this.KergetButton()}.asInstanceOf[Int]
def Scalabutton_=(value : Int)={this.KersetButton(value)}

    override def initialise(inputState : _root_.kermeta.ki.malai.interaction.State, outputState : _root_.kermeta.ki.malai.interaction.State):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
super[TransitionAspect].initialise(inputState,outputState)
Scalapx = null.asInstanceOf[_root_.java.lang.Double];
Scalapy = null.asInstanceOf[_root_.java.lang.Double];
Scalabutton = null.asInstanceOf[Int];}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.interaction.PointingDeviceTransition"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

