package kermeta.ki.malai.interaction
trait KeyReleaseTransition extends kermeta.ki.malai.interaction.KeyboardTransition{
}

