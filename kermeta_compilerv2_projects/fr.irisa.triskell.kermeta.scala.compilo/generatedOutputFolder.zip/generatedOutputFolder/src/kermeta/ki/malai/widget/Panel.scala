package kermeta.ki.malai.widget
trait Panel extends kermeta.ki.malai.widget.GraphicalComponent with kermeta.ki.malai.picking.Picker{

    override def getPickableAt(px : _root_.java.lang.Double, py : _root_.java.lang.Double) : _root_.kermeta.ki.malai.picking.Pickable
    def hasScrollbars() : java.lang.Boolean
    def scrollHorizontally(increment : java.lang.Integer) : Unit
    override def getPickerAt(px : _root_.java.lang.Double, py : _root_.java.lang.Double) : _root_.kermeta.ki.malai.picking.Picker
    override def containsObject(obj : _root_.fr.irisa.triskell.kermeta.language.structure.Object) : java.lang.Boolean
    def isHorizontalScrollbarVisible() : java.lang.Boolean
    override def initialise(eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager) : Unit
    def scrollVertically(increment : java.lang.Integer) : Unit
    def isVerticalScrollbarVisible() : java.lang.Boolean
    def addComponent(component : _root_.kermeta.ki.malai.widget.GraphicalComponent) : Unit}

