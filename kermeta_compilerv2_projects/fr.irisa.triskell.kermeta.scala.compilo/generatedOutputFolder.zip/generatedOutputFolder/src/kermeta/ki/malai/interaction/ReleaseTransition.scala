package kermeta.ki.malai.interaction
trait ReleaseTransition extends kermeta.ki.malai.interaction.PointingDeviceTransition{
}

