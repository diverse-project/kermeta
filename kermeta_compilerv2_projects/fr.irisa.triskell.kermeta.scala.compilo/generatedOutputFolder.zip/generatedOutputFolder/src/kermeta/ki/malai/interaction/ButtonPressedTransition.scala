package kermeta.ki.malai.interaction
trait ButtonPressedTransition extends kermeta.ki.malai.interaction.Transition{
}

