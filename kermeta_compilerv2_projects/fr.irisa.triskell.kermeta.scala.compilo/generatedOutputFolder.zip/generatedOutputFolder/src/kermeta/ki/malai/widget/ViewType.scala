package kermeta.ki.malai.widget
 abstract class RichGraphicalComponent extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.widget.GraphicalComponent with kermeta.ki.malai.widget.GraphicalComponentAspect 
 class RichButton extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.widget.Button with kermeta.ki.malai.widget.ButtonAspect 
 class RichToggleButton extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.widget.ToggleButton with kermeta.ki.malai.widget.ToggleButtonAspect 
 class RichPanel extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with kermeta.ki.malai.widget.Panel with kermeta.ki.malai.widget.PanelAspect 

