package kermeta.ki.malai.interaction
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait CtrlMultiPressAspect  extends kermeta.ki.malai.interaction.InteractionAspect with kermeta.ki.malai.interaction.CtrlMultiPress{
var pxs : _root_.java.util.List[_root_.java.lang.Double]= _
def KergetPxs() : _root_.java.util.List[_root_.java.lang.Double]={this.pxs}
def KersetPxs(arg:_root_.java.util.List[_root_.java.lang.Double])={ this.pxs = arg}
def Scalapxs : _root_.java.util.List[_root_.java.lang.Double]={this.KergetPxs()}.asInstanceOf[_root_.java.util.List[_root_.java.lang.Double]]
def Scalapxs_=(value : _root_.java.util.List[_root_.java.lang.Double])={this.KersetPxs(value)}
var objects : java.util.List[_root_.kermeta.ki.malai.picking.Pickable] = new java.util.ArrayList[_root_.kermeta.ki.malai.picking.Pickable]
def KergetObjects() : java.util.List[_root_.kermeta.ki.malai.picking.Pickable]={this.objects}
def KersetObjects(arg:java.util.List[_root_.kermeta.ki.malai.picking.Pickable])={ this.objects = arg}
def Scalaobjects : java.util.List[_root_.kermeta.ki.malai.picking.Pickable]={this.KergetObjects()}.asInstanceOf[java.util.List[_root_.kermeta.ki.malai.picking.Pickable]]
def Scalaobjects_=(value : java.util.List[_root_.kermeta.ki.malai.picking.Pickable])={this.KergetObjects().clear
this.KergetObjects().addAll(value)
}
var pys : _root_.java.util.List[_root_.java.lang.Double]= _
def KergetPys() : _root_.java.util.List[_root_.java.lang.Double]={this.pys}
def KersetPys(arg:_root_.java.util.List[_root_.java.lang.Double])={ this.pys = arg}
def Scalapys : _root_.java.util.List[_root_.java.lang.Double]={this.KergetPys()}.asInstanceOf[_root_.java.util.List[_root_.java.lang.Double]]
def Scalapys_=(value : _root_.java.util.List[_root_.java.lang.Double])={this.KersetPys(value)}

    override def initStateMachine():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var keyPressed : _root_.kermeta.ki.malai.interaction.State = kermeta.ki.malai.interaction.RichFactory.createIntermediaryState;
var pressed : _root_.kermeta.ki.malai.interaction.State = kermeta.ki.malai.interaction.RichFactory.createIntermediaryState;
var released : _root_.kermeta.ki.malai.interaction.State = kermeta.ki.malai.interaction.RichFactory.createIntermediaryState;
var aborted : _root_.kermeta.ki.malai.interaction.AbortingState = kermeta.ki.malai.interaction.RichFactory.createAbortingState;
var keyReleased : _root_.kermeta.ki.malai.interaction.TerminalState = kermeta.ki.malai.interaction.RichFactory.createTerminalState;
(keyPressed).initialise("keyPressed")
(keyReleased).initialise("keyReleased")
(pressed).initialise("pressed")
(released).initialise("released")
(aborted).initialise("aborted")
addState(keyPressed)
addState(pressed)
addState(keyReleased)
addState(released)
addState(aborted)
var transition : _root_.kermeta.ki.malai.interaction.Transition = null.asInstanceOf[_root_.kermeta.ki.malai.interaction.Transition];
transition = kermeta.ki.malai.interaction.RichFactory.createCtrlMultiPressKeyPressureTransition;
(transition).initialise(ScalainitState, keyPressed)
transition = kermeta.ki.malai.interaction.RichFactory.createMoveTransition;
(transition).initialise(keyPressed, keyPressed)
transition = kermeta.ki.malai.interaction.RichFactory.createKeyReleaseTransition;
(transition).initialise(keyPressed, aborted)
var mp : _root_.kermeta.ki.malai.interaction.CtrlMultiPressPressureTransition = kermeta.ki.malai.interaction.RichFactory.createCtrlMultiPressPressureTransition;
(mp).ScalactrlPress = this;
(mp).initialise(keyPressed, pressed)
transition = kermeta.ki.malai.interaction.RichFactory.createCtrlMultiPressEscapeKeyPressureTransition;
(transition).initialise(pressed, aborted)
transition = kermeta.ki.malai.interaction.RichFactory.createMoveTransition;
(transition).initialise(pressed, pressed)
transition = kermeta.ki.malai.interaction.RichFactory.createKeyReleaseTransition;
(transition).initialise(pressed, keyReleased)
transition = kermeta.ki.malai.interaction.RichFactory.createReleaseTransition;
(transition).initialise(pressed, released)
mp = kermeta.ki.malai.interaction.RichFactory.createCtrlMultiPressPressureTransition;
(mp).ScalactrlPress = this;
(mp).initialise(released, pressed)
transition = kermeta.ki.malai.interaction.RichFactory.createKeyReleaseTransition;
(transition).initialise(released, keyReleased)
transition = kermeta.ki.malai.interaction.RichFactory.createCtrlMultiPressEscapeKeyPressureTransition;
(transition).initialise(released, aborted)
transition = kermeta.ki.malai.interaction.RichFactory.createMoveTransition;
(transition).initialise(released, released)}
 return result
}

    override def reinit():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
super[InteractionAspect].reinit()
Scalapxs = kermeta.standard.RichFactory.createSequence[_root_.java.lang.Double];
Scalapys = kermeta.standard.RichFactory.createSequence[_root_.java.lang.Double];
(Scalaobjects).clear()}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.interaction.CtrlMultiPress"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

