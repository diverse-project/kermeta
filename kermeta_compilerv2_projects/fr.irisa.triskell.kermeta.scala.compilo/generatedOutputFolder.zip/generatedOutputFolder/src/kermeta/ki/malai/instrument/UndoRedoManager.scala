package kermeta.ki.malai.instrument
trait UndoRedoManager extends kermeta.ki.malai.instrument.Instrument with kermeta.ki.malai.undo.UndoHandler{

    override def updateUndo() : Unit
    override def `setActivatedEMF_renameAs`(activated : java.lang.Boolean) : Unit
    override def initialiseLinks(eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager) : Unit
    def initialiseWidgets(eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager) : Unit}

