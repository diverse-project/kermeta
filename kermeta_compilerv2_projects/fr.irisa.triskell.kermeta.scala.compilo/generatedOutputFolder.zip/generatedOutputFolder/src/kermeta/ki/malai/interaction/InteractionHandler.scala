package kermeta.ki.malai.interaction
trait InteractionHandler extends fr.irisa.triskell.kermeta.language.structure.Object{

    def interactionStarts(ai : _root_.kermeta.ki.malai.interaction.Interaction) : Unit
    def interactionAborts(ai : _root_.kermeta.ki.malai.interaction.Interaction) : Unit
    def interactionStops(ai : _root_.kermeta.ki.malai.interaction.Interaction) : Unit
    def interactionUpdates(ai : _root_.kermeta.ki.malai.interaction.Interaction) : Unit}

