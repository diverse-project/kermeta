package kermeta.ki.malai.dispatcher
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
object RichFactory{
 def createSingleDispatcher : kermeta.ki.malai.dispatcher.SingleDispatcher = { new kermeta.ki.malai.dispatcher.RichSingleDispatcher }
 def createListDispatcher : kermeta.ki.malai.dispatcher.ListDispatcher = { new kermeta.ki.malai.dispatcher.RichListDispatcher }
}

