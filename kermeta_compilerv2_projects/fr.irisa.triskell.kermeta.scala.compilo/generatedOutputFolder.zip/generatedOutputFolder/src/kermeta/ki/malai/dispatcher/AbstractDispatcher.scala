package kermeta.ki.malai.dispatcher
trait AbstractDispatcher extends fr.irisa.triskell.kermeta.language.structure.Object{

    def initialise() : Unit
    def run() : Unit
    def waitForEvent() : Unit}

