package kermeta.ki.malai.instrument
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait Scroll2ZoomAspect  extends kermeta.ki.malai.instrument.LinkAspect with kermeta.ki.malai.instrument.Scroll2Zoom{

    override def createAction():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var zoomIn : _root_.kermeta.ki.malai.action.Zoom = kermeta.ki.malai.action.RichFactory.createZoom;
var zoomer : _root_.kermeta.ki.malai.instrument.Zoomer = (Scalainstrument).asInstanceOf[_root_.kermeta.ki.malai.instrument.Zoomer];
(zoomIn).Scalazoomable = (zoomer).Scalazoomable;
(zoomIn).Scalametamodel = (zoomer).Scalametamodel;
(zoomIn).initialise((Scalainstrument).ScalaactionRegistry)
Scalaaction = zoomIn;}
 return result
}

    override def createInteraction():_root_.kermeta.ki.malai.interaction.Interaction = {
var result : _root_.kermeta.ki.malai.interaction.Interaction = null.asInstanceOf[_root_.kermeta.ki.malai.interaction.Interaction]; 


{
result = kermeta.ki.malai.interaction.RichFactory.createKeysScroll;}
 return result
}

    override def updateAction():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var scroll : _root_.kermeta.ki.malai.interaction.KeysScroll = (Scalainteraction).asInstanceOf[_root_.kermeta.ki.malai.interaction.KeysScroll];
var zoom : _root_.kermeta.ki.malai.action.Zoom = (Scalaaction).asInstanceOf[_root_.kermeta.ki.malai.action.Zoom];
(zoom).Scalaincrement = (scroll).ScalanumberUp;}
 return result
}

    override def getActionClass():_root_.fr.irisa.triskell.kermeta.language.structure.Class = {
var result : _root_.fr.irisa.triskell.kermeta.language.structure.Class = null.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Class]; 


{
result = scalaUtil.Util.getMetaClass("_root_.kermeta.ki.malai.action.Zoom");}
 return result
}

    override def isConditionRespected():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
var scroll : _root_.kermeta.ki.malai.interaction.KeysScroll = (Scalainteraction).asInstanceOf[_root_.kermeta.ki.malai.interaction.KeysScroll];
result = (((((scroll).Scalakeys).isEmpty()).not())).and((kermeta.standard.RichFactory.isVoid(((scroll).ScalanumberUp))).not());}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.instrument.Scroll2Zoom"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

