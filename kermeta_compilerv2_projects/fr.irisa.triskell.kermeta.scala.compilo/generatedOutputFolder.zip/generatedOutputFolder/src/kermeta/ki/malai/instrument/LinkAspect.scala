package kermeta.ki.malai.instrument
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait LinkAspect  extends kermeta.ki.malai.interaction.InteractionHandlerAspect with kermeta.ki.malai.instrument.Link{
var execute : _root_.java.lang.Boolean= _
def KergetExecute() : _root_.java.lang.Boolean={this.execute}
def KersetExecute(arg:_root_.java.lang.Boolean)={ this.execute = arg}
def Scalaexecute : _root_.java.lang.Boolean={this.KergetExecute()}.asInstanceOf[_root_.java.lang.Boolean]
def Scalaexecute_=(value : _root_.java.lang.Boolean)={this.KersetExecute(value)}
var action : _root_.kermeta.ki.malai.action.Action= _
def KergetAction() : _root_.kermeta.ki.malai.action.Action={this.action}
def KersetAction(arg:_root_.kermeta.ki.malai.action.Action)={ this.action = arg}
def Scalaaction : _root_.kermeta.ki.malai.action.Action={this.KergetAction()}.asInstanceOf[_root_.kermeta.ki.malai.action.Action]
def Scalaaction_=(value : _root_.kermeta.ki.malai.action.Action)={this.KersetAction(value)}
var interaction : _root_.kermeta.ki.malai.interaction.Interaction= _
def KergetInteraction() : _root_.kermeta.ki.malai.interaction.Interaction={this.interaction}
def KersetInteraction(arg:_root_.kermeta.ki.malai.interaction.Interaction)={ this.interaction = arg}
def Scalainteraction : _root_.kermeta.ki.malai.interaction.Interaction={this.KergetInteraction()}.asInstanceOf[_root_.kermeta.ki.malai.interaction.Interaction]
def Scalainteraction_=(value : _root_.kermeta.ki.malai.interaction.Interaction)={this.KersetInteraction(value)}
var instrument : _root_.kermeta.ki.malai.instrument.Instrument= _
def KergetInstrument() : _root_.kermeta.ki.malai.instrument.Instrument={this.instrument}
def KersetInstrument(arg:_root_.kermeta.ki.malai.instrument.Instrument)={ this.instrument = arg}
def Scalainstrument : _root_.kermeta.ki.malai.instrument.Instrument={this.KergetInstrument()}.asInstanceOf[_root_.kermeta.ki.malai.instrument.Instrument]
def Scalainstrument_=(value : _root_.kermeta.ki.malai.instrument.Instrument)={this.KersetInstrument(value)}

    def isRunnable():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = true;
((Scalainstrument).Scalalinks).exists({(link)=>

{
if (((link) != (this)).andThen({(b)=>

{
((link).isRunning()).andThen({(b)=>

{
(((link).getActionClass()) == (getActionClass()))}
})}
}))

{
result = false;}

result}
})}
 return result
}

    override def interactionStarts(inter : _root_.kermeta.ki.malai.interaction.Interaction):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if (((((((isRunnable())).and(kermeta.standard.RichFactory.isVoid((Scalaaction))))).and(((inter) == (Scalainteraction))))).and((Scalainstrument).Scalaactivated))

{
createAction()
interimFeedback()}
}
 return result
}

    def isRunning():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = (Scalainteraction).isRunning();}
 return result
}

    def updateAction():Unit

    def initialise(instrument : _root_.kermeta.ki.malai.instrument.Instrument, eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager, execute : java.lang.Boolean):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).Scalainstrument = instrument;
(this).Scalaexecute = execute;
Scalainteraction = createInteraction();
(Scalainteraction).initialise(eventManager)
((Scalainteraction).Scalahandlers).addUnique(this)}
 return result
}

    override def interactionStops(inter : _root_.kermeta.ki.malai.interaction.Interaction):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if ((((kermeta.standard.RichFactory.isVoid((Scalaaction))).not())).and(((Scalainteraction) == (inter))))

{
if (isConditionRespected())

{
if ((Scalaexecute).not())

{
updateAction()}

if ((Scalaaction).doIt())

{
(Scalaaction).`setDoneEMF_renameAs`()}

if ((Scalaaction).hadEffect())

{
if ((Scalaaction).isRegisterable())

{
((Scalainstrument).ScalaactionRegistry).addAction(Scalaaction)}
else 


{
((Scalainstrument).ScalaactionRegistry).cancelActions(Scalaaction)}
}

Scalaaction = null.asInstanceOf[_root_.kermeta.ki.malai.action.Action];}
else 


{
(Scalaaction).abort()
Scalaaction = null.asInstanceOf[_root_.kermeta.ki.malai.action.Action];}

(Scalainstrument).interimFeedback()}
}
 return result
}

    override def interactionUpdates(inter : _root_.kermeta.ki.malai.interaction.Interaction):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if ((((kermeta.standard.RichFactory.isVoid((Scalaaction))).not())).and(((inter) == (Scalainteraction))))

{
if (isConditionRespected())

{
updateAction()
if (((Scalaexecute)).and((Scalaaction).canDo()))

{
(Scalaaction).doIt()}

interimFeedback()}
}
}
 return result
}

    def setPickerToInteraction(picker : _root_.kermeta.ki.malai.picking.Picker):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if ((kermeta.standard.RichFactory.isVoid((Scalainteraction))).not())

{
(Scalainteraction).Scalapicker = picker;}
}
 return result
}

    def getActionClass():_root_.fr.irisa.triskell.kermeta.language.structure.Class

    def isConditionRespected():java.lang.Boolean

    def createAction():Unit

    def setPickableToInteraction(pickable : _root_.kermeta.ki.malai.picking.Pickable):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if ((kermeta.standard.RichFactory.isVoid((Scalainteraction))).not())

{
(Scalainteraction).Scalapickable = pickable;}
}
 return result
}

    def createInteraction():_root_.kermeta.ki.malai.interaction.Interaction

    def setActivated(activated : java.lang.Boolean):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(Scalainteraction).setActivated(activated)}
 return result
}

    override def interactionAborts(inter : _root_.kermeta.ki.malai.interaction.Interaction):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if ((((kermeta.standard.RichFactory.isVoid((Scalaaction))).not())).and(((inter) == (Scalainteraction))))

{
(Scalaaction).abort()
if (Scalaexecute)

{
if ((Scalaaction).isInstanceOf[_root_.kermeta.ki.malai.undo.Undoable])

{
((Scalaaction).asInstanceOf[_root_.kermeta.ki.malai.undo.Undoable]).undo()}
else 


{
var ex : _root_.kermeta.exceptions.Exception = kermeta.exceptions.RichFactory.createException;
(ex).Scalamessage = ("MustAbortStateMachineException: ").plus(((Scalaaction)+""));
throw ex}
}

Scalaaction = null.asInstanceOf[_root_.kermeta.ki.malai.action.Action];
(Scalainstrument).interimFeedback()}
}
 return result
}

    def interimFeedback():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.instrument.Link"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

