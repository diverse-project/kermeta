package kermeta.ki.malai.undo
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait UndoCollectorAspect  extends ScalaAspect.fr.irisa.triskell.kermeta.language.structure.ObjectAspect with kermeta.ki.malai.undo.UndoCollector{
var max : Int= _
def KergetMax() : Int={this.max}
def KersetMax(arg:Int)={ this.max = arg}
def Scalamax : Int={this.KergetMax()}.asInstanceOf[Int]
def Scalamax_=(value : Int)={this.KersetMax(value)}
var redoStack : _root_. java.util.Stack[_root_.kermeta.ki.malai.undo.Undoable]= _
def KergetRedoStack() : _root_. java.util.Stack[_root_.kermeta.ki.malai.undo.Undoable]={this.redoStack}
def KersetRedoStack(arg:_root_. java.util.Stack[_root_.kermeta.ki.malai.undo.Undoable])={ this.redoStack = arg}
def ScalaredoStack : _root_. java.util.Stack[_root_.kermeta.ki.malai.undo.Undoable]={this.KergetRedoStack()}.asInstanceOf[_root_. java.util.Stack[_root_.kermeta.ki.malai.undo.Undoable]]
def ScalaredoStack_=(value : _root_. java.util.Stack[_root_.kermeta.ki.malai.undo.Undoable])={this.KersetRedoStack(value)}
var undoStack : _root_. java.util.Stack[_root_.kermeta.ki.malai.undo.Undoable]= _
def KergetUndoStack() : _root_. java.util.Stack[_root_.kermeta.ki.malai.undo.Undoable]={this.undoStack}
def KersetUndoStack(arg:_root_. java.util.Stack[_root_.kermeta.ki.malai.undo.Undoable])={ this.undoStack = arg}
def ScalaundoStack : _root_. java.util.Stack[_root_.kermeta.ki.malai.undo.Undoable]={this.KergetUndoStack()}.asInstanceOf[_root_. java.util.Stack[_root_.kermeta.ki.malai.undo.Undoable]]
def ScalaundoStack_=(value : _root_. java.util.Stack[_root_.kermeta.ki.malai.undo.Undoable])={this.KersetUndoStack(value)}
var handlers : java.util.List[_root_.kermeta.ki.malai.undo.UndoHandler] = new java.util.ArrayList[_root_.kermeta.ki.malai.undo.UndoHandler]
def KergetHandlers() : java.util.List[_root_.kermeta.ki.malai.undo.UndoHandler]={this.handlers}
def KersetHandlers(arg:java.util.List[_root_.kermeta.ki.malai.undo.UndoHandler])={ this.handlers = arg}
def Scalahandlers : java.util.List[_root_.kermeta.ki.malai.undo.UndoHandler]={this.KergetHandlers()}.asInstanceOf[java.util.List[_root_.kermeta.ki.malai.undo.UndoHandler]]
def Scalahandlers_=(value : java.util.List[_root_.kermeta.ki.malai.undo.UndoHandler])={this.KergetHandlers().clear
this.KergetHandlers().addAll(value)
}

    def getLastUndo():_root_.kermeta.ki.malai.undo.Undoable = {
var result : _root_.kermeta.ki.malai.undo.Undoable = null.asInstanceOf[_root_.kermeta.ki.malai.undo.Undoable]; 


{
result = if (((ScalaundoStack).isEmpty()).not())

{
(ScalaundoStack).peek()}
;}
 return result
}

    def clear():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(ScalaundoStack).clear()
(ScalaredoStack).clear()
notifyHandlers()}
 return result
}

    def getLastRedo():_root_.kermeta.ki.malai.undo.Undoable = {
var result : _root_.kermeta.ki.malai.undo.Undoable = null.asInstanceOf[_root_.kermeta.ki.malai.undo.Undoable]; 


{
result = if (((ScalaredoStack).isEmpty()).not())

{
(ScalaredoStack).peek()}
;}
 return result
}

    def getLastUndoMessage():_root_.java.lang.String = {
var result : _root_.java.lang.String = null.asInstanceOf[_root_.java.lang.String]; 


{
result = if (((ScalaundoStack).isEmpty()).not())

{
((ScalaundoStack).peek()).getUndoName()}
;}
 return result
}

    def undo():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if (((ScalaundoStack).isEmpty()).not())

{
var action : _root_.kermeta.ki.malai.undo.Undoable = (ScalaundoStack).pop();
(action).undo()
(ScalaredoStack).push(action)
notifyHandlers()}
}
 return result
}

    def notifyHandlers():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(Scalahandlers).each({(handler)=>

{
(handler).updateUndo()}
})}
 return result
}

    def redo():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if (((ScalaredoStack).isEmpty()).not())

{
var action : _root_.kermeta.ki.malai.undo.Undoable = (ScalaredoStack).pop();
(action).redo()
(ScalaundoStack).push(action)
notifyHandlers()}
}
 return result
}

    def initialise():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
Scalamax = 50;
ScalaundoStack = kermeta.utils.RichFactory.createStack[_root_.kermeta.ki.malai.undo.Undoable];
ScalaredoStack = kermeta.utils.RichFactory.createStack[_root_.kermeta.ki.malai.undo.Undoable];}
 return result
}

    def getLastRedoMessage():_root_.java.lang.String = {
var result : _root_.java.lang.String = null.asInstanceOf[_root_.java.lang.String]; 


{
result = if (((ScalaredoStack).isEmpty()).not())

{
((ScalaredoStack).peek()).getUndoName()}
;}
 return result
}

    def add(elt : _root_.kermeta.ki.malai.undo.Undoable):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if ((((elt) != (null))).and((Scalamax).isGreater(0)))

{
if ((((ScalaundoStack).size()) == (Scalamax)))

{
(ScalaundoStack).removeAt(0)}

(ScalaundoStack).push(elt)
(ScalaredoStack).clear()
notifyHandlers()}
}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.undo.UndoCollector"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

