package kermeta.ki.malai.interaction
trait AbortingState extends kermeta.ki.malai.interaction.State{

    override def onIngoing() : Unit}

