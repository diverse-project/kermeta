package kermeta.ki.malai.interaction
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait CtrlMultiPressPressureTransitionAspect  extends kermeta.ki.malai.interaction.PressureTransitionAspect with kermeta.ki.malai.interaction.CtrlMultiPressPressureTransition{
var ctrlPress : _root_.kermeta.ki.malai.interaction.CtrlMultiPress= _
def KergetCtrlPress() : _root_.kermeta.ki.malai.interaction.CtrlMultiPress={this.ctrlPress}
def KersetCtrlPress(arg:_root_.kermeta.ki.malai.interaction.CtrlMultiPress)={ this.ctrlPress = arg}
def ScalactrlPress : _root_.kermeta.ki.malai.interaction.CtrlMultiPress={this.KergetCtrlPress()}.asInstanceOf[_root_.kermeta.ki.malai.interaction.CtrlMultiPress]
def ScalactrlPress_=(value : _root_.kermeta.ki.malai.interaction.CtrlMultiPress)={this.KersetCtrlPress(value)}

    override def action():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
((ScalactrlPress).Scalapxs).add((scalaUtil.Util.getMetaClass("_root_.java.lang.Double")).clone(Scalapx))
((ScalactrlPress).Scalapys).add((scalaUtil.Util.getMetaClass("_root_.java.lang.Double")).clone(Scalapy))
((ScalactrlPress).Scalaobjects).addUnique((ScalactrlPress).getPickableAt(Scalapx, Scalapy))}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.interaction.CtrlMultiPressPressureTransition"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

