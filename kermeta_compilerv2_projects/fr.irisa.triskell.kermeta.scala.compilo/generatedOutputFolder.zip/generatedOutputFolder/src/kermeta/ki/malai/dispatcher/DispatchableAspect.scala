package kermeta.ki.malai.dispatcher
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait DispatchableAspect  extends ScalaAspect.fr.irisa.triskell.kermeta.language.structure.ObjectAspect with kermeta.ki.malai.dispatcher.Dispatchable{
var dispatcher : _root_.kermeta.ki.malai.dispatcher.AbstractDispatcher= _
def KergetDispatcher() : _root_.kermeta.ki.malai.dispatcher.AbstractDispatcher={this.dispatcher}
def KersetDispatcher(arg:_root_.kermeta.ki.malai.dispatcher.AbstractDispatcher)={ this.dispatcher = arg}
def Scaladispatcher : _root_.kermeta.ki.malai.dispatcher.AbstractDispatcher={this.KergetDispatcher()}.asInstanceOf[_root_.kermeta.ki.malai.dispatcher.AbstractDispatcher]
def Scaladispatcher_=(value : _root_.kermeta.ki.malai.dispatcher.AbstractDispatcher)={this.KersetDispatcher(value)}

    def run():Unit

    def isWaiting():java.lang.Boolean
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.malai.dispatcher.Dispatchable"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

