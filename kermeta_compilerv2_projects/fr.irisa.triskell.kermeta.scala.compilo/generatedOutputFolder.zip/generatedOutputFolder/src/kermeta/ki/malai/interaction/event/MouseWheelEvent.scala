package kermeta.ki.malai.interaction.event
trait MouseWheelEvent extends kermeta.ki.malai.interaction.event.MouseEvent{

    def getScrollAmount() : java.lang.Integer
    def getUnitsToScroll() : java.lang.Integer
    def getScrollType() : java.lang.Integer
    def getWheelRotation() : java.lang.Integer}

