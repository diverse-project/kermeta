package kermeta.ki.visual
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
object RichFactory{
 def createHierarcher : kermeta.ki.visual.Hierarcher = { new kermeta.ki.visual.RichHierarcher }
 def createPress2GetHierarchy : kermeta.ki.visual.Press2GetHierarchy = { new kermeta.ki.visual.RichPress2GetHierarchy }
 def createHand : kermeta.ki.visual.Hand = { new kermeta.ki.visual.RichHand }
 def createFlat : kermeta.ki.visual.Flat = { new kermeta.ki.visual.RichFlat }
 def createPruneHierarchy : kermeta.ki.visual.PruneHierarchy = { new kermeta.ki.visual.RichPruneHierarchy }
 def createModifyPrunerViewPolicy : kermeta.ki.visual.ModifyPrunerViewPolicy = { new kermeta.ki.visual.RichModifyPrunerViewPolicy }
 def createInstrumentsSelector : kermeta.ki.visual.InstrumentsSelector = { new kermeta.ki.visual.RichInstrumentsSelector }
 def createButtonPressed2ActivateIns : kermeta.ki.visual.ButtonPressed2ActivateIns = { new kermeta.ki.visual.RichButtonPressed2ActivateIns }
 def createInstrumentsCustomiser : kermeta.ki.visual.InstrumentsCustomiser = { new kermeta.ki.visual.RichInstrumentsCustomiser }
 def createButtonPress2ModifyViewPolicy : kermeta.ki.visual.ButtonPress2ModifyViewPolicy = { new kermeta.ki.visual.RichButtonPress2ModifyViewPolicy }
 def createPruner : kermeta.ki.visual.Pruner = { new kermeta.ki.visual.RichPruner }
 def createMultiPress2Prune : kermeta.ki.visual.MultiPress2Prune = { new kermeta.ki.visual.RichMultiPress2Prune }
 def createPress2Reinit : kermeta.ki.visual.Press2Reinit = { new kermeta.ki.visual.RichPress2Reinit }
 def createPress2Prune : kermeta.ki.visual.Press2Prune = { new kermeta.ki.visual.RichPress2Prune }
 def createClassFlattener : kermeta.ki.visual.ClassFlattener = { new kermeta.ki.visual.RichClassFlattener }
 def createOperationBackup : kermeta.ki.visual.OperationBackup = { new kermeta.ki.visual.RichOperationBackup }
 def createPropertyBackup : kermeta.ki.visual.PropertyBackup = { new kermeta.ki.visual.RichPropertyBackup }
 def createInheritanceBackup : kermeta.ki.visual.InheritanceBackup = { new kermeta.ki.visual.RichInheritanceBackup }
 def createFlattener : kermeta.ki.visual.Flattener = { new kermeta.ki.visual.RichFlattener }
 def createPress2Flat : kermeta.ki.visual.Press2Flat = { new kermeta.ki.visual.RichPress2Flat }
 def createRequiredProperty : kermeta.ki.visual.RequiredProperty = { new kermeta.ki.visual.RichRequiredProperty }
 def createRequiredClass : kermeta.ki.visual.RequiredClass = { new kermeta.ki.visual.RichRequiredClass }
 def createRequiredEnumeration : kermeta.ki.visual.RequiredEnumeration = { new kermeta.ki.visual.RichRequiredEnumeration }
 def createMetamodelPruner : kermeta.ki.visual.MetamodelPruner = { new kermeta.ki.visual.RichMetamodelPruner }
 def createVisual : kermeta.ki.visual.Visual = { new kermeta.ki.visual.RichVisual }
 def createMetamodelCanvas : kermeta.ki.visual.MetamodelCanvas = { new kermeta.ki.visual.RichMetamodelCanvas }
 def createMetamodel2ViewVisitor : kermeta.ki.visual.Metamodel2ViewVisitor = { new kermeta.ki.visual.RichMetamodel2ViewVisitor }
 def createActionReinitView : kermeta.ki.visual.ActionReinitView = { new kermeta.ki.visual.RichActionReinitView }
 def createActionPrune : kermeta.ki.visual.ActionPrune = { new kermeta.ki.visual.RichActionPrune }
}

