package kermeta.ki.visual
trait InstrumentsSelector extends kermeta.ki.malai.instrument.Instrument{

    override def initialiseLinks(eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager) : Unit
    def initialiseInstruments(pruner : _root_.kermeta.ki.visual.Pruner, flattener : _root_.kermeta.ki.visual.Flattener, hierarcher : _root_.kermeta.ki.visual.Hierarcher, hand : _root_.kermeta.ki.visual.Hand, eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager) : Unit
    override def interimFeedback() : Unit}

