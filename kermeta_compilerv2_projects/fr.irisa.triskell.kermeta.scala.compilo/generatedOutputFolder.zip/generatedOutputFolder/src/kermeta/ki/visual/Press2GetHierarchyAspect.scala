package kermeta.ki.visual
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait Press2GetHierarchyAspect  extends kermeta.ki.malai.instrument.PressLinkAspect with kermeta.ki.visual.Press2GetHierarchy{

    override def createAction():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var prune : _root_.kermeta.ki.visual.PruneHierarchy = kermeta.ki.visual.RichFactory.createPruneHierarchy;
var hierarcher : _root_.kermeta.ki.visual.Hierarcher = (Scalainstrument).asInstanceOf[_root_.kermeta.ki.visual.Hierarcher];
(prune).initialise((Scalainstrument).ScalaactionRegistry)
(prune).Scalametamodel = (hierarcher).Scalametamodel;
(prune).ScalaviewPolicy = (kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy).hide;
Scalaaction = prune;}
 return result
}

    override def updateAction():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if ((kermeta.standard.RichFactory.isVoid((Scalaaction))).not())

{
var press : _root_.kermeta.ki.malai.interaction.Press = (Scalainteraction).asInstanceOf[_root_.kermeta.ki.malai.interaction.Press];
var prune : _root_.kermeta.ki.visual.PruneHierarchy = (Scalaaction).asInstanceOf[_root_.kermeta.ki.visual.PruneHierarchy];
if (((press).Scalatarget).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition])

{
((prune).Scalaselection).addUnique(((press).Scalatarget).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition])}
}
}
 return result
}

    override def getActionClass():_root_.fr.irisa.triskell.kermeta.language.structure.Class = {
var result : _root_.fr.irisa.triskell.kermeta.language.structure.Class = null.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Class]; 


{
result = scalaUtil.Util.getMetaClass("_root_.kermeta.ki.visual.PruneHierarchy");}
 return result
}

    override def isConditionRespected():Boolean = {
var result : Boolean = null.asInstanceOf[Boolean]; 


{
var press : _root_.kermeta.ki.malai.interaction.Press = (Scalainteraction).asInstanceOf[_root_.kermeta.ki.malai.interaction.Press];
result = (((kermeta.standard.RichFactory.isVoid(((press).Scalatarget))).not())).and(((press).Scalatarget).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]);}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.visual.Press2GetHierarchy"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

