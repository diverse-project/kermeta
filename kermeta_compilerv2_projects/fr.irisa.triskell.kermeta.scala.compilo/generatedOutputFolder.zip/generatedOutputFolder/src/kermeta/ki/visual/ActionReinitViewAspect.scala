package kermeta.ki.visual
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait ActionReinitViewAspect  extends kermeta.ki.malai.action.ActionAspect with kermeta.ki.malai.undo.UndoableAspect with kermeta.ki.visual.ActionReinitView{
var metamodel : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit= _
def KergetMetamodel() : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit={this.metamodel}
def KersetMetamodel(arg:_root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit)={ this.metamodel = arg}
def Scalametamodel : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit={this.KergetMetamodel()}.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit]
def Scalametamodel_=(value : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit)={this.KersetMetamodel(value)}
var viewPolicy : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy= _
def KergetViewPolicy() : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy={this.viewPolicy}
def KersetViewPolicy(arg:kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy)={ this.viewPolicy = arg}
def ScalaviewPolicy : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy={this.KergetViewPolicy()}.asInstanceOf[kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy]
def ScalaviewPolicy_=(value : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy)={this.KersetViewPolicy(value)}
var arePruned : _root_.java.util.List[_root_.java.lang.Boolean]= _
def KergetArePruned() : _root_.java.util.List[_root_.java.lang.Boolean]={this.arePruned}
def KersetArePruned(arg:_root_.java.util.List[_root_.java.lang.Boolean])={ this.arePruned = arg}
def ScalaarePruned : _root_.java.util.List[_root_.java.lang.Boolean]={this.KergetArePruned()}.asInstanceOf[_root_.java.util.List[_root_.java.lang.Boolean]]
def ScalaarePruned_=(value : _root_.java.util.List[_root_.java.lang.Boolean])={this.KersetArePruned(value)}

    override def canDo():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = (kermeta.standard.RichFactory.isVoid((Scalametamodel))).not();}
 return result
}

    override def hadEffect():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = isDone();}
 return result
}

    override def isRegisterable():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = true;}
 return result
}

    override def cancelledBy(action : _root_.fr.irisa.triskell.kermeta.language.structure.Class):java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = false;}
 return result
}

    override def undo():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var i : Int = 0;
((Scalametamodel).Scalapackages).each({(pkg)=>

{
((pkg).ScalaallNestedClassDefinitions).each({(cd)=>

{
if ((ScalaarePruned).at(i))

{
(cd).prune(ScalaviewPolicy)}

i = (i).plus(1);}
})}
})}
 return result
}

    override def redo():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(Scalametamodel).reinitView()}
 return result
}

    override def doActionBody():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var i : Int = 0;
var pruned : _root_.java.lang.Boolean = null.asInstanceOf[_root_.java.lang.Boolean];
ScalaarePruned = kermeta.standard.RichFactory.createSequence[_root_.java.lang.Boolean];
((Scalametamodel).Scalapackages).each({(pkg)=>

{
((pkg).ScalaallNestedClassDefinitions).each({(cd)=>

{
pruned = (cd).isPruned();
(ScalaarePruned).add(pruned)
if (((kermeta.standard.RichFactory.isVoid((ScalaviewPolicy)))).and(pruned))

{
ScalaviewPolicy = if ((cd).isVisible())

{
(kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy).hide}
else 


{
(kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy).gray}
;}

i = (i).plus(1);}
})}
})
(Scalametamodel).reinitView()
Scaladone}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.visual.ActionReinitView"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

