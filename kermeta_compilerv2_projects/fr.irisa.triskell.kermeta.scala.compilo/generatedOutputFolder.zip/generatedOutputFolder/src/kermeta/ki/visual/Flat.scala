package kermeta.ki.visual
trait Flat extends kermeta.ki.malai.action.Action with kermeta.ki.malai.undo.Undoable{

    override def canDo() : Boolean
    override def hadEffect() : Boolean
    override def undo() : Unit
    override def cancelledBy(action : _root_.fr.irisa.triskell.kermeta.language.structure.Class) : Boolean
    override def isRegisterable() : Boolean
    override def redo() : Unit
    override def doActionBody() : Unit}

