package kermeta.ki.visual
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait ButtonPress2ModifyViewPolicyAspect  extends kermeta.ki.malai.instrument.ButtonPressLinkAspect with kermeta.ki.visual.ButtonPress2ModifyViewPolicy{

    override def createAction():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var button : _root_.kermeta.ki.malai.widget.Button = ((Scalainteraction).asInstanceOf[_root_.kermeta.ki.malai.interaction.ButtonPressed]).Scalabutton;
var custom : _root_.kermeta.ki.visual.InstrumentsCustomiser = (Scalainstrument).asInstanceOf[_root_.kermeta.ki.visual.InstrumentsCustomiser];
var modifAction : _root_.kermeta.ki.visual.ModifyPrunerViewPolicy = kermeta.ki.visual.RichFactory.createModifyPrunerViewPolicy;
(modifAction).initialise((Scalainstrument).ScalaactionRegistry)
(modifAction).Scalapruner = (custom).Scalapruner;
if (((button) == (((custom).Scalapruner).ScalahideButton)))

{
(modifAction).ScalanewViewPolicy = (kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy).hide;}
else 


{
if (((button) == (((custom).Scalapruner).ScalagrayedButton)))

{
(modifAction).ScalanewViewPolicy = (kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy).gray;}
}

Scalaaction = modifAction;}
 return result
}

    override def updateAction():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
}
 return result
}

    override def getActionClass():_root_.fr.irisa.triskell.kermeta.language.structure.Class = {
var result : _root_.fr.irisa.triskell.kermeta.language.structure.Class = null.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Class]; 


{
result = scalaUtil.Util.getMetaClass("_root_.kermeta.ki.visual.ModifyPrunerViewPolicy");}
 return result
}

    override def isConditionRespected():Boolean = {
var result : Boolean = null.asInstanceOf[Boolean]; 


{
var bp : _root_.kermeta.ki.malai.interaction.ButtonPressed = (Scalainteraction).asInstanceOf[_root_.kermeta.ki.malai.interaction.ButtonPressed];
var custom : _root_.kermeta.ki.visual.InstrumentsCustomiser = (Scalainstrument).asInstanceOf[_root_.kermeta.ki.visual.InstrumentsCustomiser];
result = (((((custom).Scalapruner).ScalahideButton) == ((bp).Scalabutton))).or(((((custom).Scalapruner).ScalagrayedButton) == ((bp).Scalabutton)));}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.visual.ButtonPress2ModifyViewPolicy"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

