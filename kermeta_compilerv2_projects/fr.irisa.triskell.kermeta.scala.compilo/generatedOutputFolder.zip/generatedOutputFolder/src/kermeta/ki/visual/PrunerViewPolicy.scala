package kermeta.ki.visual
import kermeta.io._
import kermeta.standard._
import kermeta.standard.JavaConversions._
object PrunerViewPolicy extends Enumeration {
type PrunerViewPolicy = Value
val hide,gray = Value
}
