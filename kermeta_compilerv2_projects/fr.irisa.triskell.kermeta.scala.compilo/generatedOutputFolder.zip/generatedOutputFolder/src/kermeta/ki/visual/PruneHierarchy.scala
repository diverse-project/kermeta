package kermeta.ki.visual
trait PruneHierarchy extends kermeta.ki.visual.ActionPrune{

    override def setPruningParameters(pruningOperation : _root_.kermeta.ki.visual.MetamodelPruner) : Unit}

