package kermeta.ki.visual
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait MetamodelPrunerAspect  extends ScalaAspect.fr.irisa.triskell.kermeta.language.structure.ObjectAspect with kermeta.ki.visual.MetamodelPruner{
var numberOfPasses : Int= _
def KergetNumberOfPasses() : Int={this.numberOfPasses}
def KersetNumberOfPasses(arg:Int)={ this.numberOfPasses = arg}
def ScalanumberOfPasses : Int={this.KergetNumberOfPasses()}.asInstanceOf[Int]
def ScalanumberOfPasses_=(value : Int)={this.KersetNumberOfPasses(value)}
var considerCard0 : _root_.java.lang.Boolean= _
def KergetConsiderCard0() : _root_.java.lang.Boolean={this.considerCard0}
def KersetConsiderCard0(arg:_root_.java.lang.Boolean)={ this.considerCard0 = arg}
def ScalaconsiderCard0 : _root_.java.lang.Boolean={this.KergetConsiderCard0()}.asInstanceOf[_root_.java.lang.Boolean]
def ScalaconsiderCard0_=(value : _root_.java.lang.Boolean)={this.KersetConsiderCard0(value)}
var viewPolicy : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy= _
def KergetViewPolicy() : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy={this.viewPolicy}
def KersetViewPolicy(arg:kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy)={ this.viewPolicy = arg}
def ScalaviewPolicy : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy={this.KergetViewPolicy()}.asInstanceOf[kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy]
def ScalaviewPolicy_=(value : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy)={this.KersetViewPolicy(value)}
var removedKermetaMetaEnumerations : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration] = new java.util.ArrayList[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration]
def KergetRemovedKermetaMetaEnumerations() : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration]={this.removedKermetaMetaEnumerations}
def KersetRemovedKermetaMetaEnumerations(arg:java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration])={ this.removedKermetaMetaEnumerations = arg}
def ScalaremovedKermetaMetaEnumerations : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration]={this.KergetRemovedKermetaMetaEnumerations()}.asInstanceOf[java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration]]
def ScalaremovedKermetaMetaEnumerations_=(value : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration])={this.KergetRemovedKermetaMetaEnumerations().clear
this.KergetRemovedKermetaMetaEnumerations().addAll(value)
}
var requiredMetaEnumerations : java.util.List[_root_.kermeta.ki.visual.RequiredEnumeration] = new java.util.ArrayList[_root_.kermeta.ki.visual.RequiredEnumeration]
def KergetRequiredMetaEnumerations() : java.util.List[_root_.kermeta.ki.visual.RequiredEnumeration]={this.requiredMetaEnumerations}
def KersetRequiredMetaEnumerations(arg:java.util.List[_root_.kermeta.ki.visual.RequiredEnumeration])={ this.requiredMetaEnumerations = arg}
def ScalarequiredMetaEnumerations : java.util.List[_root_.kermeta.ki.visual.RequiredEnumeration]={this.KergetRequiredMetaEnumerations()}.asInstanceOf[java.util.List[_root_.kermeta.ki.visual.RequiredEnumeration]]
def ScalarequiredMetaEnumerations_=(value : java.util.List[_root_.kermeta.ki.visual.RequiredEnumeration])={this.KergetRequiredMetaEnumerations().clear
this.KergetRequiredMetaEnumerations().addAll(value)
}
var requiredKermetaMetaProperties : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Property] = new java.util.ArrayList[_root_.fr.irisa.triskell.kermeta.language.structure.Property]
def KergetRequiredKermetaMetaProperties() : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Property]={this.requiredKermetaMetaProperties}
def KersetRequiredKermetaMetaProperties(arg:java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Property])={ this.requiredKermetaMetaProperties = arg}
def ScalarequiredKermetaMetaProperties : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Property]={this.KergetRequiredKermetaMetaProperties()}.asInstanceOf[java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Property]]
def ScalarequiredKermetaMetaProperties_=(value : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Property])={this.KergetRequiredKermetaMetaProperties().clear
this.KergetRequiredKermetaMetaProperties().addAll(value)
}
var requiredKermetaMetaEnumerations : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration] = new java.util.ArrayList[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration]
def KergetRequiredKermetaMetaEnumerations() : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration]={this.requiredKermetaMetaEnumerations}
def KersetRequiredKermetaMetaEnumerations(arg:java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration])={ this.requiredKermetaMetaEnumerations = arg}
def ScalarequiredKermetaMetaEnumerations : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration]={this.KergetRequiredKermetaMetaEnumerations()}.asInstanceOf[java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration]]
def ScalarequiredKermetaMetaEnumerations_=(value : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration])={this.KergetRequiredKermetaMetaEnumerations().clear
this.KergetRequiredKermetaMetaEnumerations().addAll(value)
}
var requiredKermetaMetaPrimitiveTypes : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.PrimitiveType] = new java.util.ArrayList[_root_.fr.irisa.triskell.kermeta.language.structure.PrimitiveType]
def KergetRequiredKermetaMetaPrimitiveTypes() : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.PrimitiveType]={this.requiredKermetaMetaPrimitiveTypes}
def KersetRequiredKermetaMetaPrimitiveTypes(arg:java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.PrimitiveType])={ this.requiredKermetaMetaPrimitiveTypes = arg}
def ScalarequiredKermetaMetaPrimitiveTypes : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.PrimitiveType]={this.KergetRequiredKermetaMetaPrimitiveTypes()}.asInstanceOf[java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.PrimitiveType]]
def ScalarequiredKermetaMetaPrimitiveTypes_=(value : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.PrimitiveType])={this.KergetRequiredKermetaMetaPrimitiveTypes().clear
this.KergetRequiredKermetaMetaPrimitiveTypes().addAll(value)
}
var isHierarchicalPruning : _root_.java.lang.Boolean= _
def KergetIsHierarchicalPruning() : _root_.java.lang.Boolean={this.isHierarchicalPruning}
def KersetIsHierarchicalPruning(arg:_root_.java.lang.Boolean)={ this.isHierarchicalPruning = arg}
def ScalaisHierarchicalPruning : _root_.java.lang.Boolean={this.KergetIsHierarchicalPruning()}.asInstanceOf[_root_.java.lang.Boolean]
def ScalaisHierarchicalPruning_=(value : _root_.java.lang.Boolean)={this.KersetIsHierarchicalPruning(value)}
var requiredKermetaMetaClasses : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition] = new java.util.ArrayList[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]
def KergetRequiredKermetaMetaClasses() : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]={this.requiredKermetaMetaClasses}
def KersetRequiredKermetaMetaClasses(arg:java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition])={ this.requiredKermetaMetaClasses = arg}
def ScalarequiredKermetaMetaClasses : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]={this.KergetRequiredKermetaMetaClasses()}.asInstanceOf[java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]]
def ScalarequiredKermetaMetaClasses_=(value : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition])={this.KergetRequiredKermetaMetaClasses().clear
this.KergetRequiredKermetaMetaClasses().addAll(value)
}
var removedKermetaMetaClasses : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition] = new java.util.ArrayList[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]
def KergetRemovedKermetaMetaClasses() : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]={this.removedKermetaMetaClasses}
def KersetRemovedKermetaMetaClasses(arg:java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition])={ this.removedKermetaMetaClasses = arg}
def ScalaremovedKermetaMetaClasses : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]={this.KergetRemovedKermetaMetaClasses()}.asInstanceOf[java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]]
def ScalaremovedKermetaMetaClasses_=(value : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition])={this.KergetRemovedKermetaMetaClasses().clear
this.KergetRemovedKermetaMetaClasses().addAll(value)
}
var inputKermetaObjects : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Object] = new java.util.ArrayList[_root_.fr.irisa.triskell.kermeta.language.structure.Object]
def KergetInputKermetaObjects() : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Object]={this.inputKermetaObjects}
def KersetInputKermetaObjects(arg:java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Object])={ this.inputKermetaObjects = arg}
def ScalainputKermetaObjects : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Object]={this.KergetInputKermetaObjects()}.asInstanceOf[java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Object]]
def ScalainputKermetaObjects_=(value : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Object])={this.KergetInputKermetaObjects().clear
this.KergetInputKermetaObjects().addAll(value)
}
var emptyPackages : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Package] = new java.util.ArrayList[_root_.fr.irisa.triskell.kermeta.language.structure.Package]
def KergetEmptyPackages() : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Package]={this.emptyPackages}
def KersetEmptyPackages(arg:java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Package])={ this.emptyPackages = arg}
def ScalaemptyPackages : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Package]={this.KergetEmptyPackages()}.asInstanceOf[java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Package]]
def ScalaemptyPackages_=(value : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Package])={this.KergetEmptyPackages().clear
this.KergetEmptyPackages().addAll(value)
}
var requiredMetaClasses : java.util.List[_root_.kermeta.ki.visual.RequiredClass] = new java.util.ArrayList[_root_.kermeta.ki.visual.RequiredClass]
def KergetRequiredMetaClasses() : java.util.List[_root_.kermeta.ki.visual.RequiredClass]={this.requiredMetaClasses}
def KersetRequiredMetaClasses(arg:java.util.List[_root_.kermeta.ki.visual.RequiredClass])={ this.requiredMetaClasses = arg}
def ScalarequiredMetaClasses : java.util.List[_root_.kermeta.ki.visual.RequiredClass]={this.KergetRequiredMetaClasses()}.asInstanceOf[java.util.List[_root_.kermeta.ki.visual.RequiredClass]]
def ScalarequiredMetaClasses_=(value : java.util.List[_root_.kermeta.ki.visual.RequiredClass])={this.KergetRequiredMetaClasses().clear
this.KergetRequiredMetaClasses().addAll(value)
}
var inputKermetaMetamodel : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit= _
def KergetInputKermetaMetamodel() : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit={this.inputKermetaMetamodel}
def KersetInputKermetaMetamodel(arg:_root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit)={ this.inputKermetaMetamodel = arg}
def ScalainputKermetaMetamodel : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit={this.KergetInputKermetaMetamodel()}.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit]
def ScalainputKermetaMetamodel_=(value : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit)={this.KersetInputKermetaMetamodel(value)}
var radius : Int= _
def KergetRadius() : Int={this.radius}
def KersetRadius(arg:Int)={ this.radius = arg}
def Scalaradius : Int={this.KergetRadius()}.asInstanceOf[Int]
def Scalaradius_=(value : Int)={this.KersetRadius(value)}
var requiredMetaProperties : java.util.List[_root_.kermeta.ki.visual.RequiredProperty] = new java.util.ArrayList[_root_.kermeta.ki.visual.RequiredProperty]
def KergetRequiredMetaProperties() : java.util.List[_root_.kermeta.ki.visual.RequiredProperty]={this.requiredMetaProperties}
def KersetRequiredMetaProperties(arg:java.util.List[_root_.kermeta.ki.visual.RequiredProperty])={ this.requiredMetaProperties = arg}
def ScalarequiredMetaProperties : java.util.List[_root_.kermeta.ki.visual.RequiredProperty]={this.KergetRequiredMetaProperties()}.asInstanceOf[java.util.List[_root_.kermeta.ki.visual.RequiredProperty]]
def ScalarequiredMetaProperties_=(value : java.util.List[_root_.kermeta.ki.visual.RequiredProperty])={this.KergetRequiredMetaProperties().clear
this.KergetRequiredMetaProperties().addAll(value)
}
var kermetaObjects : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Object] = new java.util.ArrayList[_root_.fr.irisa.triskell.kermeta.language.structure.Object]
def KergetKermetaObjects() : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Object]={this.kermetaObjects}
def KersetKermetaObjects(arg:java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Object])={ this.kermetaObjects = arg}
def ScalakermetaObjects : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Object]={this.KergetKermetaObjects()}.asInstanceOf[java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Object]]
def ScalakermetaObjects_=(value : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Object])={this.KergetKermetaObjects().clear
this.KergetKermetaObjects().addAll(value)
}

    def includeAllMultiLevelSuperClasses(classes : org.eclipse.emf.common.util.EList[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var cd : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition = null.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition];
(classes).each({(c)=>

{
((c).ScalasuperType).each({(t)=>

{
if ((t).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Class])

{
cd = ((t).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Class]).ScalaclassDefinition;
if (isClassInMM(cd))

{
(ScalarequiredKermetaMetaClasses).addUnique(cd)}
}
}
})}
})}
 return result
}

    def getPackageObjects(aPackage : _root_.fr.irisa.triskell.kermeta.language.structure.Package, objects : _root_.java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Object]):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var pkg : _root_.fr.irisa.triskell.kermeta.language.structure.TypeDefinitionContainer = (aPackage).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.TypeDefinitionContainer];
var cd : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition = null.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition];
if ((((pkg).ScalaownedTypeDefinition).isEmpty()).not())

{
((pkg).ScalaownedTypeDefinition).each({(`object`)=>

{
if ((`object`).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Package])

{
(objects).addUnique(`object`)}
else 


{
if ((`object`).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition])

{
cd = (`object`).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition];
(objects).addUnique(`object`)
((cd).ScalaownedAttribute).each({(prop)=>

{
(objects).addUnique(prop)}
})
((cd).Scalainv).each({(constraint)=>

{
(objects).addUnique(constraint)}
})}
else 


{
if ((`object`).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.PrimitiveType])

{
(objects).addUnique(`object`)}
else 


{
if ((`object`).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration])

{
(objects).addUnique(`object`)}
}
}
}
}
})}

if ((((aPackage).ScalanestedPackage).isEmpty()).not())

{
((aPackage).ScalanestedPackage).each({(p)=>

{
getPackageObjects(p, objects)}
})}
}
 return result
}

    def EnumerationRemovalInPackage(aPackage : _root_.fr.irisa.triskell.kermeta.language.structure.Package):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var removeEnum : _root_.java.lang.Boolean = null.asInstanceOf[_root_.java.lang.Boolean];
if ((kermeta.standard.RichFactory.isVoid((aPackage))).not())

{
(((aPackage).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.TypeDefinitionContainer]).ScalaownedTypeDefinition).each({(`object`)=>

{
if ((`object`).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration])

{
removeEnum = ((ScalarequiredKermetaMetaEnumerations).exists({(e)=>

{
((e) == ((`object`).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration]))}
})).not();
if (removeEnum)

{
org.kermeta.ki.visual.view.ComponentView.onPruning(((ScalaviewPolicy) == ((kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy).hide)),`object`)}
}
}
})}

if ((((aPackage).ScalanestedPackage).isEmpty()).not())

{
((aPackage).ScalanestedPackage).each({(p)=>

{
EnumerationRemovalInPackage(p)}
})}
}
 return result
}

    def TagRemovalInPackage(aPackage : _root_.fr.irisa.triskell.kermeta.language.structure.Package):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if ((kermeta.standard.RichFactory.isVoid((aPackage))).not())

{
((aPackage).Scalatag).each({(t)=>

{
org.kermeta.ki.visual.view.ComponentView.onPruning(((ScalaviewPolicy) == ((kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy).hide)),t)}
})
(((aPackage).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.TypeDefinitionContainer]).ScalaownedTags).each({(`object`)=>

{
org.kermeta.ki.visual.view.ComponentView.onPruning(((ScalaviewPolicy) == ((kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy).hide)),`object`)}
})}

if ((((aPackage).ScalanestedPackage).isEmpty()).not())

{
((aPackage).ScalanestedPackage).each({(p)=>

{
TagRemovalInPackage(p)}
})}
}
 return result
}

    def isClassInMM(c : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition):java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = ((ScalainputKermetaMetamodel).Scalapackages).exists({(p)=>

{
isClassInPackage(c, p)}
});}
 return result
}

    def isInRequriedSetOfMetaClasses(tempClass : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition):java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = (ScalarequiredKermetaMetaClasses).exists({(c)=>

{
((c) == (tempClass))}
});}
 return result
}

    def includePropertiesInPackage(aPackage : _root_.fr.irisa.triskell.kermeta.language.structure.Package, props : _root_.java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Property]):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if ((kermeta.standard.RichFactory.isVoid((aPackage))).not())

{
((aPackage).ScalaownedTypeDefinition).each({(`object`)=>

{
if ((`object`).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition])

{
(((`object`).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]).ScalaownedAttribute).each({(prop)=>

{
(ScalarequiredMetaProperties).each({(rprop)=>

{
if ((((rprop).Scalaname) == ((prop).Scalaname)))

{
(props).addUnique((prop).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Property])}
}
})}
})}
}
})}

if ((((aPackage).ScalanestedPackage).isEmpty()).not())

{
((aPackage).ScalanestedPackage).each({(p)=>

{
includePropertiesInPackage(p, props)}
})}
}
 return result
}

    def isPackageEmpty(aPackage : _root_.fr.irisa.triskell.kermeta.language.structure.Package):java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
var ownedTypeDefEmpty : _root_.java.lang.Boolean = (((aPackage).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.TypeDefinitionContainer]).ScalaownedTypeDefinition).isEmpty();
result = false;
if (((aPackage).ScalanestedPackage).isEmpty())

{
if (ownedTypeDefEmpty)

{
org.kermeta.ki.visual.view.ComponentView.onPruning(((ScalaviewPolicy) == ((kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy).hide)),aPackage)
org.kermeta.ki.visual.view.MetamodelView.refresh(ScalainputKermetaMetamodel)}
}
else 


{
((aPackage).ScalanestedPackage).each({(p)=>

{
result = ((result)).and(isPackageEmpty(p));}
})
if (((ownedTypeDefEmpty)).and(result))

{
org.kermeta.ki.visual.view.ComponentView.onPruning(((ScalaviewPolicy) == ((kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy).hide)),aPackage)}
}
}
 return result
}

    def PrimitiveTypeRemoval():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
((ScalainputKermetaMetamodel).Scalapackages).each({(p)=>

{
PrimitiveTypeRemovalInPackage(p)}
})}
 return result
}

    def transform():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
getRequiredConcepts()
PropertyRemoval()
ClassRemoval()}
 return result
}

    def packageContainsPropertyOfType(c : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition, aPackage : _root_.fr.irisa.triskell.kermeta.language.structure.Package):java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
if (kermeta.standard.RichFactory.isVoid((aPackage)))

{
result = false;}
else 


{
result = (((aPackage).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.TypeDefinitionContainer]).ScalaownedTypeDefinition).exists({(`object`)=>

{
if ((`object`).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition])

{
var aClass : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition = (`object`).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition];
((aClass).ScalaownedAttribute).exists({(oA)=>

{
if (((oA).Scalatype).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Class])

{
if ((((((oA).Scalatype).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Class]).ScalaclassDefinition) == (c)))

{
result = true;}
}

result}
})}

result}
});}

if ((((((aPackage).ScalanestedPackage).isEmpty()).not())).and((result).not()))

{
result = ((aPackage).ScalanestedPackage).exists({(p)=>

{
packageContainsPropertyOfType(c, p)}
});}
}
 return result
}

    def includeAllObligatoryPropertiesAndTheirTypes():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var propLower0 : _root_.java.lang.Boolean = null.asInstanceOf[_root_.java.lang.Boolean];
var propClass : _root_.java.lang.Boolean = null.asInstanceOf[_root_.java.lang.Boolean];
var propEnum : _root_.java.lang.Boolean = null.asInstanceOf[_root_.java.lang.Boolean];
var propPrim : _root_.java.lang.Boolean = null.asInstanceOf[_root_.java.lang.Boolean];
var oppVoid : _root_.java.lang.Boolean = null.asInstanceOf[_root_.java.lang.Boolean];
var propCD : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition = null.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition];
var oppPropCD : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition = null.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition];
var enum : _root_.fr.irisa.triskell.kermeta.language.structure.Enumeration = null.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration];
var primTyp : _root_.fr.irisa.triskell.kermeta.language.structure.PrimitiveType = null.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.PrimitiveType];
(ScalarequiredKermetaMetaClasses).each({(c)=>

{
((c).ScalaownedAttribute).each({(prop)=>

{
propLower0 = (((prop).Scalalower) == (0));
propClass = ((prop).Scalatype).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Class];
propEnum = ((prop).Scalatype).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration];
propPrim = ((prop).Scalatype).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.PrimitiveType];
oppVoid = kermeta.standard.RichFactory.isVoid(((prop).Scalaopposite));
propCD = if (propClass)

{
(((prop).Scalatype).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Class]).ScalaclassDefinition}
else 


{
null}
;
oppPropCD = if ((((oppVoid).not())).and(propClass))

{
((((prop).Scalaopposite).Scalatype).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Class]).ScalaclassDefinition}
else 


{
null}
;
enum = if (propEnum)

{
((prop).Scalatype).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration]}
else 


{
null}
;
primTyp = if (propPrim)

{
((prop).Scalatype).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.PrimitiveType]}
else 


{
null}
;
if (((propLower0)).and(propClass))

{
if ((ScalaconsiderCard0).orElse({(b)=>

{
(ScalarequiredKermetaMetaClasses).contains(propCD)}
}))

{
(ScalarequiredKermetaMetaProperties).addUnique(prop)
(ScalarequiredKermetaMetaClasses).addUnique(propCD)
(ScalarequiredKermetaMetaClasses).addUnique((prop).ScalaowningClass)
if ((oppVoid).not())

{
(ScalarequiredKermetaMetaProperties).addUnique((prop).Scalaopposite)
(ScalarequiredKermetaMetaClasses).addUnique(oppPropCD)
(ScalarequiredKermetaMetaClasses).addUnique(((prop).Scalaopposite).ScalaowningClass)}
}
}

if (((propLower0)).and(propEnum))

{
if ((ScalaconsiderCard0).orElse({(b)=>

{
(ScalarequiredKermetaMetaEnumerations).contains(enum)}
}))

{
(ScalarequiredKermetaMetaProperties).addUnique(prop)
(ScalarequiredKermetaMetaEnumerations).addUnique(enum)}
}

if (propPrim)

{
(ScalarequiredKermetaMetaProperties).addUnique(prop)
(ScalarequiredKermetaMetaPrimitiveTypes).addUnique(primTyp)
(ScalarequiredKermetaMetaClasses).addUnique((prop).ScalaowningClass)}

if ((oppVoid).not())

{
if (((prop).Scalaopposite).ScalaisComposite)

{
(ScalarequiredKermetaMetaProperties).addUnique(prop)
(ScalarequiredKermetaMetaClasses).addUnique(propCD)
(ScalarequiredKermetaMetaClasses).addUnique((prop).ScalaowningClass)
(ScalarequiredKermetaMetaProperties).addUnique((prop).Scalaopposite)
(ScalarequiredKermetaMetaClasses).addUnique(oppPropCD)
(ScalarequiredKermetaMetaClasses).addUnique(((prop).Scalaopposite).ScalaowningClass)}
}

if ((((propLower0).not())).and(propClass))

{
(ScalarequiredKermetaMetaProperties).addUnique(prop)
(ScalarequiredKermetaMetaClasses).addUnique(propCD)
(ScalarequiredKermetaMetaClasses).addUnique((prop).ScalaowningClass)
if ((oppVoid).not())

{
(ScalarequiredKermetaMetaProperties).addUnique((prop).Scalaopposite)
(ScalarequiredKermetaMetaClasses).addUnique(oppPropCD)
(ScalarequiredKermetaMetaClasses).addUnique(((prop).Scalaopposite).ScalaowningClass)}
}

if ((((propLower0).not())).and(propEnum))

{
(ScalarequiredKermetaMetaProperties).addUnique(prop)
(ScalarequiredKermetaMetaEnumerations).addUnique(enum)}

(ScalarequiredMetaProperties).each({(p)=>

{
if ((((((p).Scalaname) == ((prop).Scalaname)))).and((((p).ScalaowningClassName) == (((prop).ScalaowningClass).Scalaname))))

{
if (propEnum)

{
(ScalarequiredKermetaMetaProperties).addUnique(prop)
(ScalarequiredKermetaMetaClasses).addUnique((prop).ScalaowningClass)
(ScalarequiredKermetaMetaEnumerations).addUnique(enum)}
else 


{
if (propClass)

{
(ScalarequiredKermetaMetaProperties).addUnique(prop)
(ScalarequiredKermetaMetaClasses).addUnique(propCD)
(ScalarequiredKermetaMetaClasses).addUnique((prop).ScalaowningClass)
if ((oppVoid).not())

{
(ScalarequiredKermetaMetaProperties).addUnique((prop).Scalaopposite)
(ScalarequiredKermetaMetaClasses).addUnique(oppPropCD)
(ScalarequiredKermetaMetaClasses).addUnique(((prop).Scalaopposite).ScalaowningClass)}
}
else 


{
if (propPrim)

{
(ScalarequiredKermetaMetaProperties).addUnique(prop)
(ScalarequiredKermetaMetaPrimitiveTypes).addUnique(primTyp)
(ScalarequiredKermetaMetaClasses).addUnique((prop).ScalaowningClass)}
}
}
}
}
})
if ((((((prop).ScalaisComposite)).and(propClass))).and((propLower0).not()))

{
if (isInRequriedSetOfMetaClasses(propCD))

{
(ScalarequiredKermetaMetaProperties).addUnique(prop)
(ScalarequiredKermetaMetaClasses).addUnique(propCD)
(ScalarequiredKermetaMetaClasses).addUnique((prop).ScalaowningClass)
if ((oppVoid).not())

{
(ScalarequiredKermetaMetaProperties).addUnique((prop).Scalaopposite)
(ScalarequiredKermetaMetaClasses).addUnique(oppPropCD)
(ScalarequiredKermetaMetaClasses).addUnique(((prop).Scalaopposite).ScalaowningClass)}
}
}

if ((((((prop).ScalaisComposite)).and(propEnum))).and((propLower0).not()))

{
if (isInRequriedSetOfMetaEnumerations(enum))

{
(ScalarequiredKermetaMetaEnumerations).addUnique(enum)
(ScalarequiredKermetaMetaProperties).addUnique(prop)}
}

if (propClass)

{
if (isInRequriedSetOfMetaClasses(propCD))

{
(ScalarequiredKermetaMetaProperties).addUnique(prop)
(ScalarequiredKermetaMetaClasses).addUnique((prop).ScalaowningClass)
if ((oppVoid).not())

{
(ScalarequiredKermetaMetaProperties).addUnique((prop).Scalaopposite)
(ScalarequiredKermetaMetaClasses).addUnique(oppPropCD)
(ScalarequiredKermetaMetaClasses).addUnique(((prop).Scalaopposite).ScalaowningClass)}
}
}

if (propEnum)

{
if (isInRequriedSetOfMetaEnumerations(enum))

{
(ScalarequiredKermetaMetaEnumerations).addUnique(enum)
(ScalarequiredKermetaMetaProperties).addUnique(prop)}
}
}
})}
})
(ScalarequiredKermetaMetaProperties).each({(prop)=>

{
(ScalarequiredKermetaMetaClasses).addUnique((prop).ScalaowningClass)}
})}
 return result
}

    def EnumerationRemoval():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(((this).ScalainputKermetaMetamodel).Scalapackages).each({(p)=>

{
EnumerationRemovalInPackage(p)}
})}
 return result
}

    def ClassRemovalInPackage(aPackage : _root_.fr.irisa.triskell.kermeta.language.structure.Package):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if ((kermeta.standard.RichFactory.isVoid((aPackage))).not())

{
(((aPackage).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.TypeDefinitionContainer]).ScalaownedTypeDefinition).each({(`object`)=>

{
if ((`object`).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition])

{
if (((ScalarequiredKermetaMetaClasses).contains((`object`).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition])).not())

{
org.kermeta.ki.visual.view.ComponentView.onPruning(((ScalaviewPolicy) == ((kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy).hide)),`object`)}
}
}
})}

if ((((aPackage).ScalanestedPackage).isEmpty()).not())

{
((aPackage).ScalanestedPackage).each({(p)=>

{
ClassRemovalInPackage(p)}
})}
}
 return result
}

    def ClassRemoval():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
((ScalainputKermetaMetamodel).Scalapackages).each({(p)=>

{
ClassRemovalInPackage(p)}
})}
 return result
}

    def includeEnumsInPackage(aPackage : _root_.fr.irisa.triskell.kermeta.language.structure.Package, enums : _root_.java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration]):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var en : _root_.fr.irisa.triskell.kermeta.language.structure.Enumeration = null.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration];
if ((kermeta.standard.RichFactory.isVoid((aPackage))).not())

{
((aPackage).ScalaownedTypeDefinition).each({(`object`)=>

{
if ((`object`).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration])

{
en = (`object`).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration];
(ScalarequiredMetaEnumerations).each({(c)=>

{
if ((((c).Scalaname) == ((en).Scalaname)))

{
(enums).addUnique(en)}
}
})}
}
})
if ((((aPackage).ScalanestedPackage).isEmpty()).not())

{
((aPackage).ScalanestedPackage).each({(p)=>

{
includeEnumsInPackage(p, enums)}
})}
}
}
 return result
}

    def includeClassesInPackage(aPackage : _root_.fr.irisa.triskell.kermeta.language.structure.Package, classes : _root_.java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var cd : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition = null.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition];
if ((kermeta.standard.RichFactory.isVoid((aPackage))).not())

{
((aPackage).ScalaownedTypeDefinition).each({(`object`)=>

{
if ((`object`).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition])

{
cd = (`object`).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition];
(ScalarequiredMetaClasses).each({(c)=>

{
if ((((c).Scalaname) == ((cd).Scalaname)))

{
(classes).addUnique(cd)}
}
})}
}
})
if ((((aPackage).ScalanestedPackage).isEmpty()).not())

{
((aPackage).ScalanestedPackage).each({(p)=>

{
includeClassesInPackage(p, classes)}
})}
}
}
 return result
}

    def `getKermetaObjectsEMF_renameAs`():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
((ScalainputKermetaMetamodel).Scalapackages).each({(p)=>

{
getPackageObjects(p, ScalakermetaObjects)}
})}
 return result
}

    def initialize(requiredClasses : org.eclipse.emf.common.util.EList[_root_.kermeta.ki.visual.RequiredClass], requiredProperties : org.eclipse.emf.common.util.EList[_root_.kermeta.ki.visual.RequiredProperty], requiredEnumerations : org.eclipse.emf.common.util.EList[_root_.kermeta.ki.visual.RequiredEnumeration], numberOfPasses : java.lang.Integer, viewPolicy : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(ScalarequiredMetaClasses).addAllUnique(requiredClasses)
(ScalarequiredMetaProperties).addAllUnique(requiredProperties)
(ScalarequiredMetaEnumerations).addAllUnique(requiredEnumerations)
(ScalarequiredMetaProperties).addAllUnique(requiredProperties)
(ScalarequiredMetaEnumerations).addAllUnique(requiredEnumerations)
(this).ScalanumberOfPasses = numberOfPasses;
(this).ScalaviewPolicy = viewPolicy;}
 return result
}

    def getRequiredConcepts():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
ScalaconsiderCard0 = true;
if (ScalaisHierarchicalPruning)

{
((ScalainputKermetaMetamodel).Scalapackages).each({(p)=>

{
includeClassesInPackage(p, ScalarequiredKermetaMetaClasses)}
})
var size2 : Int = (1).uminus();


{var size : Int = 0;
while (!(((size) == (size2))))


{
size = (ScalarequiredKermetaMetaClasses).size();
includeAllMultiLevelSuperClasses(ScalarequiredKermetaMetaClasses)
size2 = (ScalarequiredKermetaMetaClasses).size();}
}
(ScalarequiredKermetaMetaClasses).each({(clazz)=>

{
(stdio).writeln((clazz).Scalaname)
((clazz).ScalaownedAttribute).each({(attr)=>

{
if ((((attr).Scalatype).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.PrimitiveType]).not())

{
org.kermeta.ki.visual.view.ComponentView.onPruning(((ScalaviewPolicy) == ((kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy).hide)),attr)}
}
})}
})}
else 


{
((ScalainputKermetaMetamodel).Scalapackages).each({(p)=>

{
includeClassesInPackage(p, ScalarequiredKermetaMetaClasses)}
})
Scalaradius = 0;
if ((Scalaradius).isLowerOrEqual(0))

{
includeAllMultiLevelSuperClasses(ScalarequiredKermetaMetaClasses)
includeAllObligatoryPropertiesAndTheirTypes()
includeAllMultiLevelSuperClasses(ScalarequiredKermetaMetaClasses)
includeAllObligatoryPropertiesAndTheirTypes()
includeAllMultiLevelSuperClasses(ScalarequiredKermetaMetaClasses)}
else 


{
var formerClasses : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition] = kermeta.standard.RichFactory.createSet[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition];


{var cpt : Int = 0;
while (!((cpt).isGreaterOrEqual(Scalaradius)))


{
(ScalarequiredKermetaMetaClasses).each({(mc)=>

{
(formerClasses).addUnique(mc)}
})
includeAllObligatoryPropertiesAndTheirTypes()
includeAllMultiLevelSuperClasses(formerClasses)
cpt = (cpt).plus(1);
(formerClasses).clear()}
}
(ScalarequiredKermetaMetaClasses).each({(c)=>

{
if ((kermeta.standard.RichFactory.isVoid((c))).not())

{
((c).ScalaownedAttribute).each({(prop)=>

{
if (((prop).Scalatype).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.PrimitiveType])

{
(ScalarequiredKermetaMetaProperties).addUnique(prop)}
}
})}
}
})}
}
}
 return result
}

    def PrimitiveTypeRemovalInPackage(aPackage : _root_.fr.irisa.triskell.kermeta.language.structure.Package):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if ((kermeta.standard.RichFactory.isVoid((aPackage))).not())

{
(((aPackage).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.TypeDefinitionContainer]).ScalaownedTypeDefinition).each({(`object`)=>

{
if ((`object`).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.PrimitiveType])

{
if (((ScalarequiredKermetaMetaPrimitiveTypes).contains((`object`).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.PrimitiveType])).not())

{
org.kermeta.ki.visual.view.ComponentView.onPruning(((ScalaviewPolicy) == ((kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy).hide)),`object`)}
}
}
})}

if ((((aPackage).ScalanestedPackage).isEmpty()).not())

{
((aPackage).ScalanestedPackage).each({(p)=>

{
PrimitiveTypeRemovalInPackage(p)}
})}
}
 return result
}

    def TagRemoval():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
((ScalainputKermetaMetamodel).ScalaownedTags).each({(tag)=>

{
org.kermeta.ki.visual.view.ComponentView.onPruning(((ScalaviewPolicy) == ((kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy).hide)),tag)}
})
((ScalainputKermetaMetamodel).Scalapackages).each({(p)=>

{
TagRemovalInPackage(p)}
})}
 return result
}

    def isClassInPackage(c : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition, aPackage : _root_.fr.irisa.triskell.kermeta.language.structure.Package):java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = false;
if ((kermeta.standard.RichFactory.isVoid((aPackage))).not())

{
(((aPackage).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.TypeDefinitionContainer]).ScalaownedTypeDefinition).each({(`object`)=>

{
if ((`object`).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition])

{
if (((c) == ((`object`).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition])))

{
result = true;}
}
}
})
if ((((aPackage).ScalanestedPackage).isEmpty()).not())

{
((aPackage).ScalanestedPackage).each({(p)=>

{
if ((result).not())

{
result = isClassInPackage(c, p);}
}
})}
}
}
 return result
}

    def EmptyPackageRemoval():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(((this).ScalainputKermetaMetamodel).Scalapackages).each({(p)=>

{
if ((this).isPackageEmpty(p))

{
org.kermeta.ki.visual.view.ComponentView.onPruning(((ScalaviewPolicy) == ((kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy).hide)),p)}
}
})}
 return result
}

    def PropertyRemovalInPackage(aPackage : _root_.fr.irisa.triskell.kermeta.language.structure.Package):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var removeProperty : _root_.java.lang.Boolean = null.asInstanceOf[_root_.java.lang.Boolean];
if ((kermeta.standard.RichFactory.isVoid((aPackage))).not())

{
(((aPackage).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.TypeDefinitionContainer]).ScalaownedTypeDefinition).each({(`object`)=>

{
if ((`object`).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition])

{
(((`object`).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]).ScalaownedAttribute).each({(prop)=>

{
removeProperty = ((ScalarequiredKermetaMetaProperties).exists({(reqProp)=>

{
((reqProp) == (prop))}
})).not();
if (removeProperty)

{
org.kermeta.ki.visual.view.ComponentView.onPruning(((ScalaviewPolicy) == ((kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy).hide)),prop)
if ((kermeta.standard.RichFactory.isVoid(((prop).Scalaopposite))).not())

{
if ((kermeta.standard.RichFactory.isVoid((((prop).Scalaopposite).ScalaowningClass))).not())

{
org.kermeta.ki.visual.view.ComponentView.onPruning(((ScalaviewPolicy) == ((kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy).hide)),(prop).Scalaopposite)}
}
}
}
})}
}
})}

if ((((aPackage).ScalanestedPackage).isEmpty()).not())

{
((aPackage).ScalanestedPackage).each({(p)=>

{
PropertyRemovalInPackage(p)}
})}
}
 return result
}

    def isInRequriedSetOfMetaEnumerations(tempEnum : _root_.fr.irisa.triskell.kermeta.language.structure.Enumeration):java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = (ScalarequiredKermetaMetaEnumerations).exists({(e)=>

{
((e) == (tempEnum))}
});}
 return result
}

    def isUseLess(c : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition):java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
var isUsed : _root_.java.lang.Boolean = ((ScalainputKermetaMetamodel).Scalapackages).exists({(p)=>

{
packageContainsPropertyOfType(c, p)}
});
result = (((((c).ScalaisAbstract)).and(((c).ScalaownedAttribute).empty()))).and((isUsed).not());}
 return result
}

    def preprocess():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
getKermetaObjects()
var isExisting : _root_.java.lang.Boolean = null.asInstanceOf[_root_.java.lang.Boolean];
result = ((ScalarequiredMetaClasses).exists({(c)=>

{
isExisting = false;
(ScalakermetaObjects).each({(o)=>

{
if ((o).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition])

{
if (((((o).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.TypeDefinition]).Scalaname) == ((c).Scalaname)))

{
isExisting = true;
(ScalarequiredKermetaMetaClasses).addUnique((o).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition])}
}

isExisting}
})
(isExisting).not()}
})).not();
if (result)

{
result = ((ScalarequiredMetaEnumerations).exists({(e)=>

{
isExisting = false;
(ScalakermetaObjects).exists({(o)=>

{
if ((o).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration])

{
if (((((o).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration]).Scalaname) == ((e).Scalaname)))

{
isExisting = true;
(ScalarequiredKermetaMetaEnumerations).addUnique((o).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration])}
}

isExisting}
})
(isExisting).not()}
})).not();}

if (result)

{
result = ((ScalarequiredMetaProperties).exists({(p)=>

{
isExisting = false;
(ScalakermetaObjects).exists({(o)=>

{
if ((o).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition])

{
(((o).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]).ScalaownedAttribute).each({(a)=>

{
if ((((((a).Scalaname) == ((p).Scalaname)))).and(((((a).ScalaowningClass).Scalaname) == ((p).ScalaowningClassName))))

{
isExisting = true;
(ScalarequiredKermetaMetaProperties).addUnique((a).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Property])}
}
})}

isExisting}
})
(isExisting).not()}
})).not();}
}
 return result
}

    def PropertyRemoval():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
((ScalainputKermetaMetamodel).Scalapackages).each({(p)=>

{
PropertyRemovalInPackage(p)}
})}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.visual.MetamodelPruner"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

