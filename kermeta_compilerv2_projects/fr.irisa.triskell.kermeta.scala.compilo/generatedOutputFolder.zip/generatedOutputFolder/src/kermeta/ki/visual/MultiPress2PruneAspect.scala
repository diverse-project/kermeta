package kermeta.ki.visual
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait MultiPress2PruneAspect  extends kermeta.ki.malai.instrument.LinkAspect with kermeta.ki.visual.MultiPress2Prune{

    override def createAction():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var as : _root_.kermeta.ki.visual.ActionPrune = kermeta.ki.visual.RichFactory.createActionPrune;
var pruner : _root_.kermeta.ki.visual.Pruner = (Scalainstrument).asInstanceOf[_root_.kermeta.ki.visual.Pruner];
(as).initialise((Scalainstrument).ScalaactionRegistry)
(as).ScalaviewPolicy = (pruner).ScalaviewPolicy;
(as).Scalametamodel = (pruner).Scalametamodel;
Scalaaction = as;}
 return result
}

    override def createInteraction():_root_.kermeta.ki.malai.interaction.Interaction = {
var result : _root_.kermeta.ki.malai.interaction.Interaction = null.asInstanceOf[_root_.kermeta.ki.malai.interaction.Interaction]; 


{
result = kermeta.ki.malai.interaction.RichFactory.createCtrlMultiPress;}
 return result
}

    override def updateAction():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if ((kermeta.standard.RichFactory.isVoid((Scalaaction))).not())

{
var press : _root_.kermeta.ki.malai.interaction.CtrlMultiPress = (Scalainteraction).asInstanceOf[_root_.kermeta.ki.malai.interaction.CtrlMultiPress];
var as : _root_.kermeta.ki.visual.ActionPrune = (Scalaaction).asInstanceOf[_root_.kermeta.ki.visual.ActionPrune];
((press).Scalaobjects).each({(o)=>

{
if (((kermeta.standard.RichFactory.isVoid((o))).not()).andThen({(b)=>

{
(o).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]}
}))

{
((as).Scalaselection).addUnique((o).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition])}
}
})}
}
 return result
}

    override def getActionClass():_root_.fr.irisa.triskell.kermeta.language.structure.Class = {
var result : _root_.fr.irisa.triskell.kermeta.language.structure.Class = null.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Class]; 


{
result = scalaUtil.Util.getMetaClass("_root_.kermeta.ki.visual.ActionPrune");}
 return result
}

    override def isConditionRespected():Boolean = {
var result : Boolean = null.asInstanceOf[Boolean]; 


{
result = true;}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.visual.MultiPress2Prune"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

