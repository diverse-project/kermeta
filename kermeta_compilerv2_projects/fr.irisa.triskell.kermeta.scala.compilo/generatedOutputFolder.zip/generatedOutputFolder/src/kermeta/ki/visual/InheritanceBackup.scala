package kermeta.ki.visual
trait InheritanceBackup extends fr.irisa.triskell.kermeta.language.structure.Object{
}

