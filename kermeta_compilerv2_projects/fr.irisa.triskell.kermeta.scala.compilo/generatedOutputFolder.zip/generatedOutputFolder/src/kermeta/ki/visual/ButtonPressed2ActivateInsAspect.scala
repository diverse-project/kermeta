package kermeta.ki.visual
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait ButtonPressed2ActivateInsAspect  extends kermeta.ki.malai.instrument.ButtonPressLinkAspect with kermeta.ki.visual.ButtonPressed2ActivateIns{

    override def createAction():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var button : _root_.kermeta.ki.malai.widget.Button = ((Scalainteraction).asInstanceOf[_root_.kermeta.ki.malai.interaction.ButtonPressed]).Scalabutton;
var selector : _root_.kermeta.ki.visual.InstrumentsSelector = (Scalainstrument).asInstanceOf[_root_.kermeta.ki.visual.InstrumentsSelector];
var activeAction : _root_.kermeta.ki.malai.action.ActivateDesactivateInstruments = kermeta.ki.malai.action.RichFactory.createActivateDesactivateInstruments;
if (((button) == ((selector).ScalaprunerButton)))

{
((activeAction).ScalainstrumentsActivate).addUnique((selector).Scalapruner)
((activeAction).ScalainstrumentsDesactivate).addUnique((selector).Scalaflattener)
((activeAction).ScalainstrumentsDesactivate).addUnique((selector).Scalahierarcher)
((activeAction).ScalainstrumentsDesactivate).addUnique((selector).Scalahand)}
else 


{
if (((button) == ((selector).ScalahierarcherButton)))

{
((activeAction).ScalainstrumentsActivate).addUnique((selector).Scalahierarcher)
((activeAction).ScalainstrumentsDesactivate).addUnique((selector).Scalaflattener)
((activeAction).ScalainstrumentsDesactivate).addUnique((selector).Scalapruner)
((activeAction).ScalainstrumentsDesactivate).addUnique((selector).Scalahand)}
else 


{
if (((button) == ((selector).ScalahandButton)))

{
((activeAction).ScalainstrumentsActivate).addUnique((selector).Scalahand)
((activeAction).ScalainstrumentsDesactivate).addUnique((selector).Scalapruner)
((activeAction).ScalainstrumentsDesactivate).addUnique((selector).Scalahierarcher)
((activeAction).ScalainstrumentsDesactivate).addUnique((selector).Scalaflattener)}
else 


{
((activeAction).ScalainstrumentsActivate).addUnique((selector).Scalaflattener)
((activeAction).ScalainstrumentsDesactivate).addUnique((selector).Scalapruner)
((activeAction).ScalainstrumentsDesactivate).addUnique((selector).Scalahierarcher)
((activeAction).ScalainstrumentsDesactivate).addUnique((selector).Scalahand)}
}
}

Scalaaction = activeAction;
(Scalaaction).initialise((Scalainstrument).ScalaactionRegistry)}
 return result
}

    override def updateAction():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
}
 return result
}

    override def getActionClass():_root_.fr.irisa.triskell.kermeta.language.structure.Class = {
var result : _root_.fr.irisa.triskell.kermeta.language.structure.Class = null.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Class]; 


{
result = scalaUtil.Util.getMetaClass("_root_.kermeta.ki.malai.action.ActivateDesactivateInstruments");}
 return result
}

    override def isConditionRespected():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
var bp : _root_.kermeta.ki.malai.interaction.ButtonPressed = (Scalainteraction).asInstanceOf[_root_.kermeta.ki.malai.interaction.ButtonPressed];
var selector : _root_.kermeta.ki.visual.InstrumentsSelector = (Scalainstrument).asInstanceOf[_root_.kermeta.ki.visual.InstrumentsSelector];
result = ((((((selector).ScalaprunerButton) == ((bp).Scalabutton))).or((((selector).ScalaflattenerButton) == ((bp).Scalabutton)))).or((((selector).ScalahierarcherButton) == ((bp).Scalabutton)))).or((((selector).ScalahandButton) == ((bp).Scalabutton)));}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.visual.ButtonPressed2ActivateIns"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

