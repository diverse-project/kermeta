package kermeta.ki.visual
trait MetamodelCanvas extends kermeta.ki.malai.action.ActionHandler with kermeta.ki.malai.undo.UndoHandler{

    override def onActionAborted(action : _root_.kermeta.ki.malai.action.Action) : Unit
    def initialiseUI() : Unit
    override def updateUndo() : Unit
    def loadMetamodel(muURI : _root_.java.lang.String) : Unit
    def initialise(eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager) : Unit
    def setVisible(visible : java.lang.Boolean) : Unit
    def refreshView() : Unit
    override def onActionCancelled(action : _root_.kermeta.ki.malai.action.Action) : Unit
    override def onActionAdded(action : _root_.kermeta.ki.malai.action.Action) : Unit
    override def onActionExecuted(action : _root_.kermeta.ki.malai.action.Action) : Unit}

