package kermeta.ki.visual
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait ClassFlattenerAspect  extends ScalaAspect.fr.irisa.triskell.kermeta.language.structure.ObjectAspect with kermeta.ki.visual.ClassFlattener{
var addedOperations : java.util.List[_root_.kermeta.ki.visual.OperationBackup] = new java.util.ArrayList[_root_.kermeta.ki.visual.OperationBackup]
def KergetAddedOperations() : java.util.List[_root_.kermeta.ki.visual.OperationBackup]={this.addedOperations}
def KersetAddedOperations(arg:java.util.List[_root_.kermeta.ki.visual.OperationBackup])={ this.addedOperations = arg}
def ScalaaddedOperations : java.util.List[_root_.kermeta.ki.visual.OperationBackup]={this.KergetAddedOperations()}.asInstanceOf[java.util.List[_root_.kermeta.ki.visual.OperationBackup]]
def ScalaaddedOperations_=(value : java.util.List[_root_.kermeta.ki.visual.OperationBackup])={this.KergetAddedOperations().clear
this.KergetAddedOperations().addAll(value)
}
var removedClasses : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition] = new java.util.ArrayList[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]
def KergetRemovedClasses() : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]={this.removedClasses}
def KersetRemovedClasses(arg:java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition])={ this.removedClasses = arg}
def ScalaremovedClasses : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]={this.KergetRemovedClasses()}.asInstanceOf[java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]]
def ScalaremovedClasses_=(value : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition])={this.KergetRemovedClasses().clear
this.KergetRemovedClasses().addAll(value)
}
var metamodel : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit= _
def KergetMetamodel() : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit={this.metamodel}
def KersetMetamodel(arg:_root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit)={ this.metamodel = arg}
def Scalametamodel : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit={this.KergetMetamodel()}.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit]
def Scalametamodel_=(value : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit)={this.KersetMetamodel(value)}
var addedInheritances : java.util.List[_root_.kermeta.ki.visual.InheritanceBackup] = new java.util.ArrayList[_root_.kermeta.ki.visual.InheritanceBackup]
def KergetAddedInheritances() : java.util.List[_root_.kermeta.ki.visual.InheritanceBackup]={this.addedInheritances}
def KersetAddedInheritances(arg:java.util.List[_root_.kermeta.ki.visual.InheritanceBackup])={ this.addedInheritances = arg}
def ScalaaddedInheritances : java.util.List[_root_.kermeta.ki.visual.InheritanceBackup]={this.KergetAddedInheritances()}.asInstanceOf[java.util.List[_root_.kermeta.ki.visual.InheritanceBackup]]
def ScalaaddedInheritances_=(value : java.util.List[_root_.kermeta.ki.visual.InheritanceBackup])={this.KergetAddedInheritances().clear
this.KergetAddedInheritances().addAll(value)
}
var addedProperties : java.util.List[_root_.kermeta.ki.visual.PropertyBackup] = new java.util.ArrayList[_root_.kermeta.ki.visual.PropertyBackup]
def KergetAddedProperties() : java.util.List[_root_.kermeta.ki.visual.PropertyBackup]={this.addedProperties}
def KersetAddedProperties(arg:java.util.List[_root_.kermeta.ki.visual.PropertyBackup])={ this.addedProperties = arg}
def ScalaaddedProperties : java.util.List[_root_.kermeta.ki.visual.PropertyBackup]={this.KergetAddedProperties()}.asInstanceOf[java.util.List[_root_.kermeta.ki.visual.PropertyBackup]]
def ScalaaddedProperties_=(value : java.util.List[_root_.kermeta.ki.visual.PropertyBackup])={this.KergetAddedProperties().clear
this.KergetAddedProperties().addAll(value)
}
var classToFlat : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition= _
def KergetClassToFlat() : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition={this.classToFlat}
def KersetClassToFlat(arg:_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition)={ this.classToFlat = arg}
def ScalaclassToFlat : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition={this.KergetClassToFlat()}.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]
def ScalaclassToFlat_=(value : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition)={this.KersetClassToFlat(value)}
var removedProperties : java.util.List[_root_.kermeta.ki.visual.PropertyBackup] = new java.util.ArrayList[_root_.kermeta.ki.visual.PropertyBackup]
def KergetRemovedProperties() : java.util.List[_root_.kermeta.ki.visual.PropertyBackup]={this.removedProperties}
def KersetRemovedProperties(arg:java.util.List[_root_.kermeta.ki.visual.PropertyBackup])={ this.removedProperties = arg}
def ScalaremovedProperties : java.util.List[_root_.kermeta.ki.visual.PropertyBackup]={this.KergetRemovedProperties()}.asInstanceOf[java.util.List[_root_.kermeta.ki.visual.PropertyBackup]]
def ScalaremovedProperties_=(value : java.util.List[_root_.kermeta.ki.visual.PropertyBackup])={this.KergetRemovedProperties().clear
this.KergetRemovedProperties().addAll(value)
}
var removedInheritances : java.util.List[_root_.kermeta.ki.visual.InheritanceBackup] = new java.util.ArrayList[_root_.kermeta.ki.visual.InheritanceBackup]
def KergetRemovedInheritances() : java.util.List[_root_.kermeta.ki.visual.InheritanceBackup]={this.removedInheritances}
def KersetRemovedInheritances(arg:java.util.List[_root_.kermeta.ki.visual.InheritanceBackup])={ this.removedInheritances = arg}
def ScalaremovedInheritances : java.util.List[_root_.kermeta.ki.visual.InheritanceBackup]={this.KergetRemovedInheritances()}.asInstanceOf[java.util.List[_root_.kermeta.ki.visual.InheritanceBackup]]
def ScalaremovedInheritances_=(value : java.util.List[_root_.kermeta.ki.visual.InheritanceBackup])={this.KergetRemovedInheritances().clear
this.KergetRemovedInheritances().addAll(value)
}

    def flatClass(currentClass : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition, upperClass : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if ((((currentClass).Scalaname) != ("Object")).or((((currentClass).ScalasuperType).empty()).not()))

{
var propBackUp : _root_.kermeta.ki.visual.PropertyBackup = null.asInstanceOf[_root_.kermeta.ki.visual.PropertyBackup];
var opBackUp : _root_.kermeta.ki.visual.OperationBackup = null.asInstanceOf[_root_.kermeta.ki.visual.OperationBackup];
var inBackup : _root_.kermeta.ki.visual.InheritanceBackup = null.asInstanceOf[_root_.kermeta.ki.visual.InheritanceBackup];
((currentClass).ScalaownedAttribute).each({(prop)=>

{
if ((prop).isVisible())

{
(currentClass).movePropertyTo(prop, ScalaclassToFlat, Scalametamodel)
propBackUp = kermeta.ki.visual.RichFactory.createPropertyBackup;
(propBackUp).Scalaprop = prop;
(propBackUp).ScalaowningClass = currentClass;
(ScalaaddedProperties).addUnique(propBackUp)}
}
})
((currentClass).ScalaownedOperation).each({(op)=>

{
if ((op).isVisible())

{
opBackUp = kermeta.ki.visual.RichFactory.createOperationBackup;
(opBackUp).Scalaop = op;
(opBackUp).ScalaowningClass = currentClass;
(currentClass).moveOperationTo(op, ScalaclassToFlat)
(ScalaaddedOperations).addUnique(opBackUp)}
}
})
var subTypes : _root_.java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition] = (currentClass).getSubTypes();
var inheritance : _root_.kermeta.ki.visual.InheritanceBackup = null.asInstanceOf[_root_.kermeta.ki.visual.InheritanceBackup];
(subTypes).each({(st)=>

{
inBackup = kermeta.ki.visual.RichFactory.createInheritanceBackup;
(inBackup).Scalasource = st;
(inBackup).Scalatarget = currentClass;
(inBackup).ScalasourceType = ((st).ScalasuperType).detect({(st2)=>

{
((st2).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ParameterizedType]).andThen({(b)=>

{
((((st2).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ParameterizedType]).ScalatypeDefinition) == (currentClass))}
})}
});
(ScalaremovedInheritances).addUnique(inBackup)
if ((kermeta.standard.RichFactory.isVoid(((inBackup).ScalasourceType))).not())

{
((st).ScalasuperType).remove((inBackup).ScalasourceType)}

org.kermeta.ki.visual.view.MetamodelView.onInheritanceRemoved(Scalametamodel,st,currentClass)
if ((((st) != (ScalaclassToFlat))).and((st) != (upperClass)))

{
inBackup = kermeta.ki.visual.RichFactory.createInheritanceBackup;
(inBackup).Scalasource = st;
(inBackup).Scalatarget = ScalaclassToFlat;
(ScalaaddedInheritances).addUnique(inBackup)
org.kermeta.ki.visual.view.MetamodelView.onInheritanceAdded(Scalametamodel,st,ScalaclassToFlat,(1).uminus())}

((st).ScalasuperType).detect({(`type`)=>

{
if ((`type`).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ParameterizedType])

{
if (((((`type`).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ParameterizedType]).ScalatypeDefinition) == (currentClass)))

{
inheritance = kermeta.ki.visual.RichFactory.createInheritanceBackup;
(inheritance).Scalasource = st;
(inheritance).ScalasourceType = `type`;
(inheritance).Scalatarget = currentClass;
(ScalaremovedInheritances).addUnique(inheritance)
((st).ScalasuperType).remove(`type`)
true}
else 


{
false}
}
else 


{
false}
}
})}
})
((currentClass).ScalasuperType).each({(st)=>

{
if ((st).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Class])

{
flatClass(((st).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Class]).ScalaclassDefinition, currentClass)}
}
})
(ScalaremovedClasses).addUnique(currentClass)
org.kermeta.ki.visual.view.MetamodelView.onEntityRemoved(Scalametamodel,currentClass)}
}
 return result
}

    def flat(classToFlat : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var superType : _root_.fr.irisa.triskell.kermeta.language.structure.Type = null.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Type];
var inheritance : _root_.kermeta.ki.visual.InheritanceBackup = null.asInstanceOf[_root_.kermeta.ki.visual.InheritanceBackup];
var prop : _root_.kermeta.ki.visual.PropertyBackup = null.asInstanceOf[_root_.kermeta.ki.visual.PropertyBackup];
var cd : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition = null.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition];
var cd2 : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition = null.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition];
(this).ScalaclassToFlat = classToFlat;


{true
while (!(((classToFlat).ScalasuperType).empty()))


{
superType = ((classToFlat).ScalasuperType).one();
if ((superType).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Class])

{
cd = ((superType).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Class]).ScalaclassDefinition;
inheritance = kermeta.ki.visual.RichFactory.createInheritanceBackup;
(inheritance).Scalasource = classToFlat;
(inheritance).ScalasourceType = superType;
(inheritance).Scalatarget = cd;
(ScalaremovedInheritances).addUnique(inheritance)
((classToFlat).ScalasuperType).remove(superType)
org.kermeta.ki.visual.view.MetamodelView.onInheritanceRemoved(Scalametamodel,classToFlat,cd)
flatClass(cd, classToFlat)}
}
}
((Scalametamodel).Scalapackages).each({(p)=>

{
((p).ScalaownedTypeDefinition).each({(td)=>

{
if ((((this) != (td))).and((td).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]))

{
cd = (td).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition];
((cd).ScalaownedAttribute).each({(attr)=>

{
if (((attr).Scalatype).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ParameterizedType])

{
cd2 = ((((attr).Scalatype).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ParameterizedType]).ScalatypeDefinition).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition];
(ScalaremovedClasses).each({(cl)=>

{
if (((cl) == (cd2)))

{
prop = kermeta.ki.visual.RichFactory.createPropertyBackup;
(prop).Scalaprop = attr;
(prop).ScalaowningClass = cd;
(ScalaremovedProperties).addUnique(prop)
((cd).ScalaownedAttribute).remove(attr)
org.kermeta.ki.visual.view.MetamodelView.onLinkRemoved(Scalametamodel,attr)}
}
})}
}
})}
}
})}
})}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.visual.ClassFlattener"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

