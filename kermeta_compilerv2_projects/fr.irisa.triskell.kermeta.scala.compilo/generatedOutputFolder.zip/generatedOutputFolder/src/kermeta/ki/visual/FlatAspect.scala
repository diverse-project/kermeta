package kermeta.ki.visual
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait FlatAspect  extends kermeta.ki.malai.action.ActionAspect with kermeta.ki.malai.undo.UndoableAspect with kermeta.ki.visual.Flat{
var metamodel : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit= _
def KergetMetamodel() : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit={this.metamodel}
def KersetMetamodel(arg:_root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit)={ this.metamodel = arg}
def Scalametamodel : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit={this.KergetMetamodel()}.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit]
def Scalametamodel_=(value : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit)={this.KersetMetamodel(value)}
var flatteningOperation : _root_.kermeta.ki.visual.ClassFlattener= _
def KergetFlatteningOperation() : _root_.kermeta.ki.visual.ClassFlattener={this.flatteningOperation}
def KersetFlatteningOperation(arg:_root_.kermeta.ki.visual.ClassFlattener)={ this.flatteningOperation = arg}
def ScalaflatteningOperation : _root_.kermeta.ki.visual.ClassFlattener={this.KergetFlatteningOperation()}.asInstanceOf[_root_.kermeta.ki.visual.ClassFlattener]
def ScalaflatteningOperation_=(value : _root_.kermeta.ki.visual.ClassFlattener)={this.KersetFlatteningOperation(value)}
var classToFlat : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition= _
def KergetClassToFlat() : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition={this.classToFlat}
def KersetClassToFlat(arg:_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition)={ this.classToFlat = arg}
def ScalaclassToFlat : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition={this.KergetClassToFlat()}.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]
def ScalaclassToFlat_=(value : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition)={this.KersetClassToFlat(value)}

    override def canDo():Boolean = {
var result : Boolean = null.asInstanceOf[Boolean]; 


{
result = (((kermeta.standard.RichFactory.isVoid((Scalametamodel))).not())).and((kermeta.standard.RichFactory.isVoid((ScalaclassToFlat))).not());}
 return result
}

    override def hadEffect():Boolean = {
var result : Boolean = null.asInstanceOf[Boolean]; 


{
result = isDone();}
 return result
}

    override def undo():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
((ScalaflatteningOperation).ScalaremovedClasses).each({(clazz)=>

{
var obj : _root_.fr.irisa.triskell.kermeta.language.structure.Object = (clazz).container();
if ((obj).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Package])

{
(((obj).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Package]).ScalaownedTypeDefinition).addUnique(clazz)
org.kermeta.ki.visual.view.MetamodelView.onEntityAdded(Scalametamodel,clazz,(clazz).ScalaisAspect,(1).uminus(),(clazz).Scalaname)}
}
})
((ScalaflatteningOperation).ScalaremovedProperties).each({(prop)=>

{
(((prop).ScalaowningClass).ScalaownedAttribute).addUnique((prop).Scalaprop)
((prop).Scalaprop).ScalaowningClass = (prop).ScalaowningClass;
org.kermeta.ki.visual.view.MetamodelView.onLinkAdded(Scalametamodel,(prop).Scalaprop,((prop).Scalaprop).ScalaisComposite,((prop).Scalaprop).ScalaowningClass,(prop).ScalaowningClass,((prop).Scalaprop).Scalaname,((prop).Scalaprop).getCardinalityString(),if ((kermeta.standard.RichFactory.isVoid((((prop).Scalaprop).Scalaopposite))).not())

{
(((prop).Scalaprop).Scalaopposite).Scalaname}
,if ((kermeta.standard.RichFactory.isVoid((((prop).Scalaprop).Scalaopposite))).not())

{
(((prop).Scalaprop).Scalaopposite).getCardinalityString()}
,(1).uminus())}
})
((ScalaflatteningOperation).ScalaaddedOperations).each({(op)=>

{
(ScalaclassToFlat).moveOperationTo((op).Scalaop, (op).ScalaowningClass)}
})
((ScalaflatteningOperation).ScalaaddedProperties).each({(prop)=>

{
(ScalaclassToFlat).movePropertyTo((prop).Scalaprop, (prop).ScalaowningClass, Scalametamodel)}
})
((ScalaflatteningOperation).ScalaremovedInheritances).each({(in)=>

{
if (kermeta.standard.RichFactory.isVoid(((in).ScalasourceType)))

{
var clazz : _root_.fr.irisa.triskell.kermeta.language.structure.Class = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass;
(clazz).ScalatypeDefinition = (in).Scalatarget;
(in).ScalasourceType = clazz;}

(((in).Scalasource).ScalasuperType).addUnique((in).ScalasourceType)
org.kermeta.ki.visual.view.MetamodelView.onInheritanceAdded(Scalametamodel,(in).Scalasource,(in).Scalatarget,(1).uminus())}
})
((ScalaflatteningOperation).ScalaaddedInheritances).each({(in)=>

{
(((in).Scalasource).ScalasuperType).each({(st)=>

{
if ((st).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ParameterizedType])

{
if ((((in).Scalatarget) == (((st).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ParameterizedType]).ScalatypeDefinition)))

{
(((in).Scalasource).ScalasuperType).remove(st)}
}
}
})
org.kermeta.ki.visual.view.MetamodelView.onInheritanceRemoved(Scalametamodel,(in).Scalasource,(in).Scalatarget)}
})
org.kermeta.ki.visual.view.MetamodelView.update(Scalametamodel)}
 return result
}

    override def cancelledBy(action : _root_.fr.irisa.triskell.kermeta.language.structure.Class):Boolean = {
var result : Boolean = null.asInstanceOf[Boolean]; 


{
result = false;}
 return result
}

    override def isRegisterable():Boolean = {
var result : Boolean = null.asInstanceOf[Boolean]; 


{
result = true;}
 return result
}

    override def redo():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
doActionBody()}
 return result
}

    override def doActionBody():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
ScalaflatteningOperation = kermeta.ki.visual.RichFactory.createClassFlattener;
(ScalaflatteningOperation).Scalametamodel = Scalametamodel;
(ScalaflatteningOperation).flat(ScalaclassToFlat)
org.kermeta.ki.visual.view.MetamodelView.update(Scalametamodel)
Scaladone}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.visual.Flat"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

