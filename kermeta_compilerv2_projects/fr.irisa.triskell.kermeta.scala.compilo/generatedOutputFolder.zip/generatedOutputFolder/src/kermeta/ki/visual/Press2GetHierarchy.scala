package kermeta.ki.visual
trait Press2GetHierarchy extends kermeta.ki.malai.instrument.PressLink{

    override def createAction() : Unit
    override def updateAction() : Unit
    override def getActionClass() : _root_.fr.irisa.triskell.kermeta.language.structure.Class
    override def isConditionRespected() : Boolean}

