package kermeta.ki.visual
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait Metamodel2ViewVisitorAspect  extends ScalaAspect.fr.irisa.triskell.kermeta.KermetaVisitorAspect with kermeta.ki.visual.Metamodel2ViewVisitor{
var classes : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition] = new java.util.ArrayList[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]
def KergetClasses() : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]={this.classes}
def KersetClasses(arg:java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition])={ this.classes = arg}
def Scalaclasses : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]={this.KergetClasses()}.asInstanceOf[java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]]
def Scalaclasses_=(value : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition])={this.KergetClasses().clear
this.KergetClasses().addAll(value)
}
var modelingUnit : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit= _
def KergetModelingUnit() : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit={this.modelingUnit}
def KersetModelingUnit(arg:_root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit)={ this.modelingUnit = arg}
def ScalamodelingUnit : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit={this.KergetModelingUnit()}.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit]
def ScalamodelingUnit_=(value : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit)={this.KersetModelingUnit(value)}
var firstPass : _root_.java.lang.Boolean= _
def KergetFirstPass() : _root_.java.lang.Boolean={this.firstPass}
def KersetFirstPass(arg:_root_.java.lang.Boolean)={ this.firstPass = arg}
def ScalafirstPass : _root_.java.lang.Boolean={this.KergetFirstPass()}.asInstanceOf[_root_.java.lang.Boolean]
def ScalafirstPass_=(value : _root_.java.lang.Boolean)={this.KersetFirstPass(value)}
var links : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Property] = new java.util.ArrayList[_root_.fr.irisa.triskell.kermeta.language.structure.Property]
def KergetLinks() : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Property]={this.links}
def KersetLinks(arg:java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Property])={ this.links = arg}
def Scalalinks : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Property]={this.KergetLinks()}.asInstanceOf[java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Property]]
def Scalalinks_=(value : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Property])={this.KergetLinks().clear
this.KergetLinks().addAll(value)
}

    override def visitProperty(p : _root_.fr.irisa.triskell.kermeta.language.structure.Property):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if (((p).Scalatype).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Class])

{
var cd : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition = (((p).Scalatype).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Class]).ScalaclassDefinition;
if (((((((cd).Scalaname) == ("String"))).or((((cd).Scalaname) == ("Boolean")))).or((((cd).Scalaname) == ("Real")))).or((((cd).Scalaname) == ("Integer"))))

{
org.kermeta.ki.visual.view.EntityView.onAttributeAdded((p).ScalaowningClass,p,(p).Scalaname,(cd).Scalaname)}
else 


{
if ((Scalaclasses).contains(cd))

{
org.kermeta.ki.visual.view.MetamodelView.onLinkAdded(ScalamodelingUnit,p,(p).ScalaisComposite,(p).ScalaowningClass,cd,(p).Scalaname,(p).getCardinalityString(),if ((kermeta.standard.RichFactory.isVoid(((p).Scalaopposite))).not())

{
((p).Scalaopposite).Scalaname}
,if ((kermeta.standard.RichFactory.isVoid(((p).Scalaopposite))).not())

{
((p).Scalaopposite).getCardinalityString()}
,(1).uminus())}
}

(Scalalinks).addUnique(p)}
else 


{
if (((p).Scalatype).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.PrimitiveType])

{
var pt : _root_.fr.irisa.triskell.kermeta.language.structure.PrimitiveType = ((p).Scalatype).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.PrimitiveType];
org.kermeta.ki.visual.view.EntityView.onAttributeAdded((p).ScalaowningClass,p,(p).Scalaname,(pt).Scalaname)}
else 


{
if (((p).Scalatype).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration])

{
var enum : _root_.fr.irisa.triskell.kermeta.language.structure.Enumeration = ((p).Scalatype).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration];
org.kermeta.ki.visual.view.EntityView.onAttributeAdded((p).ScalaowningClass,p,(p).Scalaname,(enum).Scalaname)}
}
}
}
 return result
}

    override def visitPackage(p : _root_.fr.irisa.triskell.kermeta.language.structure.Package):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
((p).ScalanestedPackage).each({(p)=>

{
(p).accept(this)}
})
((p).ScalaownedTypeDefinition).each({(td)=>

{
(td).accept(this)}
})}
 return result
}

    override def visitModelingUnit(mu : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
ScalafirstPass = true;
((mu).Scalapackages).each({(p)=>

{
(p).accept(this)}
})
ScalafirstPass = false;
((mu).Scalapackages).each({(p)=>

{
(p).accept(this)}
})}
 return result
}

    override def visitOperation(o : _root_.fr.irisa.triskell.kermeta.language.structure.Operation):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var typeName : _root_.java.lang.String = if (((o).Scalatype).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.NamedElement])

{
(((o).Scalatype).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.NamedElement]).Scalaname}
else 


{
""}
;
var paramTypeName : _root_.java.lang.String = null.asInstanceOf[_root_.java.lang.String];
org.kermeta.ki.visual.view.EntityView.onOperationAdded((o).ScalaowningClass,o,(o).Scalaname,typeName,(o).ScalaisAbstract)
((o).ScalaownedParameter).each({(param)=>

{
paramTypeName = if (((param).Scalatype).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.NamedElement])

{
(((param).Scalatype).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.NamedElement]).Scalaname}
else 


{
null}
;
if ((kermeta.standard.RichFactory.isVoid((paramTypeName))).not())

{
org.kermeta.ki.visual.view.OperationView.onParameterAdded(o,(param).Scalaname,paramTypeName)}
}
})}
 return result
}

    override def visitClassDefinition(c : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if (ScalafirstPass)

{
(Scalaclasses).addUnique(c)
org.kermeta.ki.visual.view.MetamodelView.onEntityAdded(ScalamodelingUnit,c,(c).ScalaisAspect,(1).uminus(),(c).Scalaname)
(c).entity2ViewMapping()}
else 


{
((c).ScalaownedAttribute).each({(p)=>

{
(p).accept(this)}
})
((c).ScalaownedOperation).each({(o)=>

{
(o).accept(this)}
})
((c).ScalasuperType).each({(t)=>

{
if ((t).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Class])

{
var cd : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition = ((t).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Class]).ScalaclassDefinition;
if ((Scalaclasses).contains(cd))

{
org.kermeta.ki.visual.view.MetamodelView.onInheritanceAdded(ScalamodelingUnit,c,cd,(1).uminus())}
}
}
})}
}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.visual.Metamodel2ViewVisitor"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

