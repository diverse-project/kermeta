package kermeta.ki.visual
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait InstrumentsSelectorAspect  extends kermeta.ki.malai.instrument.InstrumentAspect with kermeta.ki.visual.InstrumentsSelector{
var hand : _root_.kermeta.ki.visual.Hand= _
def KergetHand() : _root_.kermeta.ki.visual.Hand={this.hand}
def KersetHand(arg:_root_.kermeta.ki.visual.Hand)={ this.hand = arg}
def Scalahand : _root_.kermeta.ki.visual.Hand={this.KergetHand()}.asInstanceOf[_root_.kermeta.ki.visual.Hand]
def Scalahand_=(value : _root_.kermeta.ki.visual.Hand)={this.KersetHand(value)}
var prunerButton : _root_.kermeta.ki.malai.widget.ToggleButton= _
def KergetPrunerButton() : _root_.kermeta.ki.malai.widget.ToggleButton={this.prunerButton}
def KersetPrunerButton(arg:_root_.kermeta.ki.malai.widget.ToggleButton)={ this.prunerButton = arg}
def ScalaprunerButton : _root_.kermeta.ki.malai.widget.ToggleButton={this.KergetPrunerButton()}.asInstanceOf[_root_.kermeta.ki.malai.widget.ToggleButton]
def ScalaprunerButton_=(value : _root_.kermeta.ki.malai.widget.ToggleButton)={this.KersetPrunerButton(value)}
var flattener : _root_.kermeta.ki.visual.Flattener= _
def KergetFlattener() : _root_.kermeta.ki.visual.Flattener={this.flattener}
def KersetFlattener(arg:_root_.kermeta.ki.visual.Flattener)={ this.flattener = arg}
def Scalaflattener : _root_.kermeta.ki.visual.Flattener={this.KergetFlattener()}.asInstanceOf[_root_.kermeta.ki.visual.Flattener]
def Scalaflattener_=(value : _root_.kermeta.ki.visual.Flattener)={this.KersetFlattener(value)}
var handButton : _root_.kermeta.ki.malai.widget.ToggleButton= _
def KergetHandButton() : _root_.kermeta.ki.malai.widget.ToggleButton={this.handButton}
def KersetHandButton(arg:_root_.kermeta.ki.malai.widget.ToggleButton)={ this.handButton = arg}
def ScalahandButton : _root_.kermeta.ki.malai.widget.ToggleButton={this.KergetHandButton()}.asInstanceOf[_root_.kermeta.ki.malai.widget.ToggleButton]
def ScalahandButton_=(value : _root_.kermeta.ki.malai.widget.ToggleButton)={this.KersetHandButton(value)}
var picker : _root_.kermeta.ki.malai.picking.Picker= _
def KergetPicker() : _root_.kermeta.ki.malai.picking.Picker={this.picker}
def KersetPicker(arg:_root_.kermeta.ki.malai.picking.Picker)={ this.picker = arg}
def Scalapicker : _root_.kermeta.ki.malai.picking.Picker={this.KergetPicker()}.asInstanceOf[_root_.kermeta.ki.malai.picking.Picker]
def Scalapicker_=(value : _root_.kermeta.ki.malai.picking.Picker)={this.KersetPicker(value)}
var flattenerButton : _root_.kermeta.ki.malai.widget.ToggleButton= _
def KergetFlattenerButton() : _root_.kermeta.ki.malai.widget.ToggleButton={this.flattenerButton}
def KersetFlattenerButton(arg:_root_.kermeta.ki.malai.widget.ToggleButton)={ this.flattenerButton = arg}
def ScalaflattenerButton : _root_.kermeta.ki.malai.widget.ToggleButton={this.KergetFlattenerButton()}.asInstanceOf[_root_.kermeta.ki.malai.widget.ToggleButton]
def ScalaflattenerButton_=(value : _root_.kermeta.ki.malai.widget.ToggleButton)={this.KersetFlattenerButton(value)}
var hierarcherButton : _root_.kermeta.ki.malai.widget.ToggleButton= _
def KergetHierarcherButton() : _root_.kermeta.ki.malai.widget.ToggleButton={this.hierarcherButton}
def KersetHierarcherButton(arg:_root_.kermeta.ki.malai.widget.ToggleButton)={ this.hierarcherButton = arg}
def ScalahierarcherButton : _root_.kermeta.ki.malai.widget.ToggleButton={this.KergetHierarcherButton()}.asInstanceOf[_root_.kermeta.ki.malai.widget.ToggleButton]
def ScalahierarcherButton_=(value : _root_.kermeta.ki.malai.widget.ToggleButton)={this.KersetHierarcherButton(value)}
var hierarcher : _root_.kermeta.ki.visual.Hierarcher= _
def KergetHierarcher() : _root_.kermeta.ki.visual.Hierarcher={this.hierarcher}
def KersetHierarcher(arg:_root_.kermeta.ki.visual.Hierarcher)={ this.hierarcher = arg}
def Scalahierarcher : _root_.kermeta.ki.visual.Hierarcher={this.KergetHierarcher()}.asInstanceOf[_root_.kermeta.ki.visual.Hierarcher]
def Scalahierarcher_=(value : _root_.kermeta.ki.visual.Hierarcher)={this.KersetHierarcher(value)}
var pruner : _root_.kermeta.ki.visual.Pruner= _
def KergetPruner() : _root_.kermeta.ki.visual.Pruner={this.pruner}
def KersetPruner(arg:_root_.kermeta.ki.visual.Pruner)={ this.pruner = arg}
def Scalapruner : _root_.kermeta.ki.visual.Pruner={this.KergetPruner()}.asInstanceOf[_root_.kermeta.ki.visual.Pruner]
def Scalapruner_=(value : _root_.kermeta.ki.visual.Pruner)={this.KersetPruner(value)}

    override def initialiseLinks(eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
addLink(kermeta.ki.visual.RichFactory.createButtonPressed2ActivateIns, Scalapicker, null, eventManager, false)}
 return result
}

    def initialiseInstruments(pruner : _root_.kermeta.ki.visual.Pruner, flattener : _root_.kermeta.ki.visual.Flattener, hierarcher : _root_.kermeta.ki.visual.Hierarcher, hand : _root_.kermeta.ki.visual.Hand, eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).Scalapruner = pruner;
(this).Scalaflattener = flattener;
(this).Scalahierarcher = hierarcher;
(this).Scalahand = hand;
(pruner).setActivated(false)
(flattener).setActivated(false)
(hierarcher).setActivated(false)
(hand).setActivated(true)
ScalaprunerButton = kermeta.ki.malai.widget.RichFactory.createToggleButton;
ScalaflattenerButton = kermeta.ki.malai.widget.RichFactory.createToggleButton;
ScalahierarcherButton = kermeta.ki.malai.widget.RichFactory.createToggleButton;
ScalahandButton = kermeta.ki.malai.widget.RichFactory.createToggleButton;
(ScalaprunerButton).initialiseWithIcon("/res/prune.png", eventManager)
(ScalaflattenerButton).initialiseWithIcon("/res/flat.png", eventManager)
(ScalahierarcherButton).initialiseWithIcon("/res/hierar.png", eventManager)
(ScalahandButton).initialiseWithIcon("/res/hand.png", eventManager)
interimFeedback()}
 return result
}

    override def interimFeedback():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(ScalaprunerButton).setSelected((Scalapruner).Scalaactivated)
(ScalaflattenerButton).setSelected((Scalaflattener).Scalaactivated)
(ScalahierarcherButton).setSelected((Scalahierarcher).Scalaactivated)
(ScalahandButton).setSelected((Scalahand).Scalaactivated)}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.visual.InstrumentsSelector"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

