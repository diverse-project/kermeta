package kermeta.ki.visual
trait MetamodelPruner extends fr.irisa.triskell.kermeta.language.structure.Object{

    def includeAllMultiLevelSuperClasses(classes : org.eclipse.emf.common.util.EList[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]) : Unit
    def getPackageObjects(aPackage : _root_.fr.irisa.triskell.kermeta.language.structure.Package, objects : _root_.java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Object]) : Unit
    def EnumerationRemovalInPackage(aPackage : _root_.fr.irisa.triskell.kermeta.language.structure.Package) : Unit
    def TagRemovalInPackage(aPackage : _root_.fr.irisa.triskell.kermeta.language.structure.Package) : Unit
    def isClassInMM(c : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition) : java.lang.Boolean
    def isInRequriedSetOfMetaClasses(tempClass : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition) : java.lang.Boolean
    def includePropertiesInPackage(aPackage : _root_.fr.irisa.triskell.kermeta.language.structure.Package, props : _root_.java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Property]) : Unit
    def isPackageEmpty(aPackage : _root_.fr.irisa.triskell.kermeta.language.structure.Package) : java.lang.Boolean
    def PrimitiveTypeRemoval() : Unit
    def transform() : Unit
    def packageContainsPropertyOfType(c : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition, aPackage : _root_.fr.irisa.triskell.kermeta.language.structure.Package) : java.lang.Boolean
    def includeAllObligatoryPropertiesAndTheirTypes() : Unit
    def EnumerationRemoval() : Unit
    def ClassRemovalInPackage(aPackage : _root_.fr.irisa.triskell.kermeta.language.structure.Package) : Unit
    def ClassRemoval() : Unit
    def includeEnumsInPackage(aPackage : _root_.fr.irisa.triskell.kermeta.language.structure.Package, enums : _root_.java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Enumeration]) : Unit
    def includeClassesInPackage(aPackage : _root_.fr.irisa.triskell.kermeta.language.structure.Package, classes : _root_.java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]) : Unit
    def `getKermetaObjectsEMF_renameAs`() : Unit
    def initialize(requiredClasses : org.eclipse.emf.common.util.EList[_root_.kermeta.ki.visual.RequiredClass], requiredProperties : org.eclipse.emf.common.util.EList[_root_.kermeta.ki.visual.RequiredProperty], requiredEnumerations : org.eclipse.emf.common.util.EList[_root_.kermeta.ki.visual.RequiredEnumeration], numberOfPasses : java.lang.Integer, viewPolicy : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy) : Unit
    def getRequiredConcepts() : Unit
    def PrimitiveTypeRemovalInPackage(aPackage : _root_.fr.irisa.triskell.kermeta.language.structure.Package) : Unit
    def TagRemoval() : Unit
    def isClassInPackage(c : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition, aPackage : _root_.fr.irisa.triskell.kermeta.language.structure.Package) : java.lang.Boolean
    def EmptyPackageRemoval() : Unit
    def PropertyRemovalInPackage(aPackage : _root_.fr.irisa.triskell.kermeta.language.structure.Package) : Unit
    def isInRequriedSetOfMetaEnumerations(tempEnum : _root_.fr.irisa.triskell.kermeta.language.structure.Enumeration) : java.lang.Boolean
    def isUseLess(c : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition) : java.lang.Boolean
    def preprocess() : java.lang.Boolean
    def PropertyRemoval() : Unit}

