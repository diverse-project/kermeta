package kermeta.ki.visual
trait OperationBackup extends fr.irisa.triskell.kermeta.language.structure.Object{
}

