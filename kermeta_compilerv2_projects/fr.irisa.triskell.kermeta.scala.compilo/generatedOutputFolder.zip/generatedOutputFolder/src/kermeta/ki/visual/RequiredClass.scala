package kermeta.ki.visual
trait RequiredClass extends fr.irisa.triskell.kermeta.language.structure.Object{
}

