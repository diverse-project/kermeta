package kermeta.ki.visual
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait MetamodelCanvasAspect  extends kermeta.ki.malai.action.ActionHandlerAspect with kermeta.ki.malai.undo.UndoHandlerAspect with kermeta.ki.visual.MetamodelCanvas{
var undoCollector : _root_.kermeta.ki.malai.undo.UndoCollector= _
def KergetUndoCollector() : _root_.kermeta.ki.malai.undo.UndoCollector={this.undoCollector}
def KersetUndoCollector(arg:_root_.kermeta.ki.malai.undo.UndoCollector)={ this.undoCollector = arg}
def ScalaundoCollector : _root_.kermeta.ki.malai.undo.UndoCollector={this.KergetUndoCollector()}.asInstanceOf[_root_.kermeta.ki.malai.undo.UndoCollector]
def ScalaundoCollector_=(value : _root_.kermeta.ki.malai.undo.UndoCollector)={this.KersetUndoCollector(value)}
var selector : _root_.kermeta.ki.visual.InstrumentsSelector= _
def KergetSelector() : _root_.kermeta.ki.visual.InstrumentsSelector={this.selector}
def KersetSelector(arg:_root_.kermeta.ki.visual.InstrumentsSelector)={ this.selector = arg}
def Scalaselector : _root_.kermeta.ki.visual.InstrumentsSelector={this.KergetSelector()}.asInstanceOf[_root_.kermeta.ki.visual.InstrumentsSelector]
def Scalaselector_=(value : _root_.kermeta.ki.visual.InstrumentsSelector)={this.KersetSelector(value)}
var metamodel : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit= _
def KergetMetamodel() : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit={this.metamodel}
def KersetMetamodel(arg:_root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit)={ this.metamodel = arg}
def Scalametamodel : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit={this.KergetMetamodel()}.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit]
def Scalametamodel_=(value : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit)={this.KersetMetamodel(value)}
var actionRegistry : _root_.kermeta.ki.malai.action.ActionRegistry= _
def KergetActionRegistry() : _root_.kermeta.ki.malai.action.ActionRegistry={this.actionRegistry}
def KersetActionRegistry(arg:_root_.kermeta.ki.malai.action.ActionRegistry)={ this.actionRegistry = arg}
def ScalaactionRegistry : _root_.kermeta.ki.malai.action.ActionRegistry={this.KergetActionRegistry()}.asInstanceOf[_root_.kermeta.ki.malai.action.ActionRegistry]
def ScalaactionRegistry_=(value : _root_.kermeta.ki.malai.action.ActionRegistry)={this.KersetActionRegistry(value)}
var toolbar : _root_.kermeta.ki.malai.widget.Panel= _
def KergetToolbar() : _root_.kermeta.ki.malai.widget.Panel={this.toolbar}
def KersetToolbar(arg:_root_.kermeta.ki.malai.widget.Panel)={ this.toolbar = arg}
def Scalatoolbar : _root_.kermeta.ki.malai.widget.Panel={this.KergetToolbar()}.asInstanceOf[_root_.kermeta.ki.malai.widget.Panel]
def Scalatoolbar_=(value : _root_.kermeta.ki.malai.widget.Panel)={this.KersetToolbar(value)}
var flattener : _root_.kermeta.ki.visual.Flattener= _
def KergetFlattener() : _root_.kermeta.ki.visual.Flattener={this.flattener}
def KersetFlattener(arg:_root_.kermeta.ki.visual.Flattener)={ this.flattener = arg}
def Scalaflattener : _root_.kermeta.ki.visual.Flattener={this.KergetFlattener()}.asInstanceOf[_root_.kermeta.ki.visual.Flattener]
def Scalaflattener_=(value : _root_.kermeta.ki.visual.Flattener)={this.KersetFlattener(value)}
var pruner : _root_.kermeta.ki.visual.Pruner= _
def KergetPruner() : _root_.kermeta.ki.visual.Pruner={this.pruner}
def KersetPruner(arg:_root_.kermeta.ki.visual.Pruner)={ this.pruner = arg}
def Scalapruner : _root_.kermeta.ki.visual.Pruner={this.KergetPruner()}.asInstanceOf[_root_.kermeta.ki.visual.Pruner]
def Scalapruner_=(value : _root_.kermeta.ki.visual.Pruner)={this.KersetPruner(value)}
var zoomer : _root_.kermeta.ki.malai.instrument.Zoomer= _
def KergetZoomer() : _root_.kermeta.ki.malai.instrument.Zoomer={this.zoomer}
def KersetZoomer(arg:_root_.kermeta.ki.malai.instrument.Zoomer)={ this.zoomer = arg}
def Scalazoomer : _root_.kermeta.ki.malai.instrument.Zoomer={this.KergetZoomer()}.asInstanceOf[_root_.kermeta.ki.malai.instrument.Zoomer]
def Scalazoomer_=(value : _root_.kermeta.ki.malai.instrument.Zoomer)={this.KersetZoomer(value)}
var hand : _root_.kermeta.ki.visual.Hand= _
def KergetHand() : _root_.kermeta.ki.visual.Hand={this.hand}
def KersetHand(arg:_root_.kermeta.ki.visual.Hand)={ this.hand = arg}
def Scalahand : _root_.kermeta.ki.visual.Hand={this.KergetHand()}.asInstanceOf[_root_.kermeta.ki.visual.Hand]
def Scalahand_=(value : _root_.kermeta.ki.visual.Hand)={this.KersetHand(value)}
var viewPanel : _root_.kermeta.ki.malai.widget.Panel= _
def KergetViewPanel() : _root_.kermeta.ki.malai.widget.Panel={this.viewPanel}
def KersetViewPanel(arg:_root_.kermeta.ki.malai.widget.Panel)={ this.viewPanel = arg}
def ScalaviewPanel : _root_.kermeta.ki.malai.widget.Panel={this.KergetViewPanel()}.asInstanceOf[_root_.kermeta.ki.malai.widget.Panel]
def ScalaviewPanel_=(value : _root_.kermeta.ki.malai.widget.Panel)={this.KersetViewPanel(value)}
var eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager= _
def KergetEventManager() : _root_.kermeta.ki.malai.interaction.event.EventManager={this.eventManager}
def KersetEventManager(arg:_root_.kermeta.ki.malai.interaction.event.EventManager)={ this.eventManager = arg}
def ScalaeventManager : _root_.kermeta.ki.malai.interaction.event.EventManager={this.KergetEventManager()}.asInstanceOf[_root_.kermeta.ki.malai.interaction.event.EventManager]
def ScalaeventManager_=(value : _root_.kermeta.ki.malai.interaction.event.EventManager)={this.KersetEventManager(value)}
var scroller : _root_.kermeta.ki.malai.instrument.Scroller= _
def KergetScroller() : _root_.kermeta.ki.malai.instrument.Scroller={this.scroller}
def KersetScroller(arg:_root_.kermeta.ki.malai.instrument.Scroller)={ this.scroller = arg}
def Scalascroller : _root_.kermeta.ki.malai.instrument.Scroller={this.KergetScroller()}.asInstanceOf[_root_.kermeta.ki.malai.instrument.Scroller]
def Scalascroller_=(value : _root_.kermeta.ki.malai.instrument.Scroller)={this.KersetScroller(value)}
var customiser : _root_.kermeta.ki.visual.InstrumentsCustomiser= _
def KergetCustomiser() : _root_.kermeta.ki.visual.InstrumentsCustomiser={this.customiser}
def KersetCustomiser(arg:_root_.kermeta.ki.visual.InstrumentsCustomiser)={ this.customiser = arg}
def Scalacustomiser : _root_.kermeta.ki.visual.InstrumentsCustomiser={this.KergetCustomiser()}.asInstanceOf[_root_.kermeta.ki.visual.InstrumentsCustomiser]
def Scalacustomiser_=(value : _root_.kermeta.ki.visual.InstrumentsCustomiser)={this.KersetCustomiser(value)}
var undoManager : _root_.kermeta.ki.malai.instrument.UndoRedoManager= _
def KergetUndoManager() : _root_.kermeta.ki.malai.instrument.UndoRedoManager={this.undoManager}
def KersetUndoManager(arg:_root_.kermeta.ki.malai.instrument.UndoRedoManager)={ this.undoManager = arg}
def ScalaundoManager : _root_.kermeta.ki.malai.instrument.UndoRedoManager={this.KergetUndoManager()}.asInstanceOf[_root_.kermeta.ki.malai.instrument.UndoRedoManager]
def ScalaundoManager_=(value : _root_.kermeta.ki.malai.instrument.UndoRedoManager)={this.KersetUndoManager(value)}
var hierarcher : _root_.kermeta.ki.visual.Hierarcher= _
def KergetHierarcher() : _root_.kermeta.ki.visual.Hierarcher={this.hierarcher}
def KersetHierarcher(arg:_root_.kermeta.ki.visual.Hierarcher)={ this.hierarcher = arg}
def Scalahierarcher : _root_.kermeta.ki.visual.Hierarcher={this.KergetHierarcher()}.asInstanceOf[_root_.kermeta.ki.visual.Hierarcher]
def Scalahierarcher_=(value : _root_.kermeta.ki.visual.Hierarcher)={this.KersetHierarcher(value)}

    override def onActionAborted(action : _root_.kermeta.ki.malai.action.Action):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
refreshView()}
 return result
}

    def initialiseUI():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
Scalatoolbar = kermeta.ki.malai.widget.RichFactory.createPanel;
ScalaviewPanel = kermeta.ki.malai.widget.RichFactory.createPanel;
(Scalatoolbar).initialise(ScalaeventManager)
org.kermeta.ki.visual.MetamodelVizuFrame.initialiseToolbar(Scalatoolbar,(ScalaundoManager).ScalaundoButton,(ScalaundoManager).ScalaredoButton,(Scalaselector).ScalaprunerButton,(Scalaselector).ScalaflattenerButton,(Scalaselector).ScalahierarcherButton,(Scalaselector).ScalahandButton,(Scalapruner).ScalagrayedButton,(Scalapruner).ScalahideButton)
((Scalatoolbar).Scalacomponents).addUnique((ScalaundoManager).ScalaundoButton)
((Scalatoolbar).Scalacomponents).addUnique((ScalaundoManager).ScalaredoButton)
((Scalatoolbar).Scalacomponents).addUnique((Scalapruner).ScalahideButton)
((Scalatoolbar).Scalacomponents).addUnique((Scalapruner).ScalagrayedButton)
((Scalatoolbar).Scalacomponents).addUnique((Scalaselector).ScalaprunerButton)
((Scalatoolbar).Scalacomponents).addUnique((Scalaselector).ScalahierarcherButton)
((Scalatoolbar).Scalacomponents).addUnique((Scalaselector).ScalaflattenerButton)
((Scalatoolbar).Scalacomponents).addUnique((Scalaselector).ScalahandButton)}
 return result
}

    override def updateUndo():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
refreshView()}
 return result
}

    def loadMetamodel(muURI : _root_.java.lang.String):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var rep : _root_.kermeta.persistence.EMFRepository = kermeta.persistence.RichFactory.createEMFRepository;
var res : _root_.kermeta.persistence.EMFResource = null.asInstanceOf[_root_.kermeta.persistence.EMFResource];
try{
res = (rep).getResource(muURI).asInstanceOf[_root_.kermeta.persistence.EMFResource];
}catch { case e:ClassCastException => {}}

try{
Scalametamodel = (res).one().asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit];
}catch { case e:ClassCastException => {}}
}
 return result
}

    def initialise(eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
loadMetamodel("/examples/UML.km")
(this).ScalaeventManager = eventManager;
ScalaundoCollector = kermeta.ki.malai.undo.RichFactory.createUndoCollector;
ScalaactionRegistry = kermeta.ki.malai.action.RichFactory.createActionRegistry;
(ScalaundoCollector).initialise()
((ScalaundoCollector).Scalahandlers).addUnique(this)
(ScalaactionRegistry).initialise(ScalaundoCollector)
((ScalaactionRegistry).Scalahandlers).addUnique(this)
Scalahand = kermeta.ki.visual.RichFactory.createHand;
Scalahierarcher = kermeta.ki.visual.RichFactory.createHierarcher;
Scalazoomer = kermeta.ki.malai.instrument.RichFactory.createZoomer;
Scalapruner = kermeta.ki.visual.RichFactory.createPruner;
Scalaflattener = kermeta.ki.visual.RichFactory.createFlattener;
ScalaundoManager = kermeta.ki.malai.instrument.RichFactory.createUndoRedoManager;
Scalaselector = kermeta.ki.visual.RichFactory.createInstrumentsSelector;
Scalacustomiser = kermeta.ki.visual.RichFactory.createInstrumentsCustomiser;
Scalascroller = kermeta.ki.malai.instrument.RichFactory.createScroller;
(Scalahand).initialise(ScalaactionRegistry)
(Scalahierarcher).initialise(ScalaactionRegistry)
(Scalazoomer).initialise(ScalaactionRegistry)
(Scalaflattener).initialise(ScalaactionRegistry)
(Scalascroller).initialise(ScalaactionRegistry)
(Scalacustomiser).Scalapruner = Scalapruner;
(Scalacustomiser).initialise(ScalaactionRegistry)
(Scalapruner).initialise(ScalaactionRegistry)
(Scalapruner).initialiseWidgets(eventManager)
(ScalaundoManager).initialise(ScalaactionRegistry)
(ScalaundoManager).initialiseWidgets(eventManager)
(Scalapruner).Scalametamodel = Scalametamodel;
(Scalapruner).initialiseLinks(eventManager)
(Scalaflattener).Scalametamodel = Scalametamodel;
(Scalaflattener).initialiseLinks(eventManager)
(Scalahand).Scalapicker = Scalametamodel;
(Scalahand).initialiseLinks(eventManager)
(Scalahierarcher).Scalametamodel = Scalametamodel;
(Scalahierarcher).initialiseLinks(eventManager)
(Scalaselector).initialise(ScalaactionRegistry)
(Scalaselector).initialiseInstruments(Scalapruner, Scalaflattener, Scalahierarcher, Scalahand, eventManager)
initialiseUI()
org.kermeta.ki.visual.MetamodelVizuFrame.initialise(this,Scalametamodel,Scalatoolbar,ScalaviewPanel,eventManager)
(Scalazoomer).Scalazoomable = Scalametamodel;
(Scalazoomer).Scalametamodel = Scalametamodel;
(Scalazoomer).initialiseLinks(eventManager)
(Scalazoomer).setActivated(true)
(Scalascroller).Scalapanel = ScalaviewPanel;
(Scalascroller).Scalapicker = Scalametamodel;
(Scalascroller).initialiseLinks(eventManager)
(Scalascroller).setActivated(true)
(Scalacustomiser).Scalapicker = Scalatoolbar;
(Scalacustomiser).initialiseLinks(eventManager)
(Scalacustomiser).setActivated(true)
(Scalaselector).Scalapicker = Scalatoolbar;
(Scalaselector).initialiseLinks(eventManager)
(Scalaselector).setActivated(true)
(Scalapruner).Scalametamodel = Scalametamodel;
(ScalaundoManager).ScalaundoCollector = ScalaundoCollector;
(ScalaundoManager).Scalapicker = Scalatoolbar;
((ScalaundoCollector).Scalahandlers).addUnique(ScalaundoManager)
(ScalaundoManager).initialiseLinks(eventManager)
(ScalaundoManager).`setActivatedEMF_renameAs`(true)
var model2view : _root_.kermeta.ki.visual.Metamodel2ViewVisitor = kermeta.ki.visual.RichFactory.createMetamodel2ViewVisitor;
(model2view).ScalamodelingUnit = Scalametamodel;
(Scalametamodel).accept(model2view)}
 return result
}

    def setVisible(visible : java.lang.Boolean):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
org.kermeta.ki.visual.MetamodelVizuFrame.setVisible(this,visible)}
 return result
}

    def refreshView():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
org.kermeta.ki.visual.MetamodelVizuFrame.refreshView(this)}
 return result
}

    override def onActionCancelled(action : _root_.kermeta.ki.malai.action.Action):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
refreshView()}
 return result
}

    override def onActionAdded(action : _root_.kermeta.ki.malai.action.Action):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
refreshView()}
 return result
}

    override def onActionExecuted(action : _root_.kermeta.ki.malai.action.Action):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
refreshView()}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.visual.MetamodelCanvas"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

