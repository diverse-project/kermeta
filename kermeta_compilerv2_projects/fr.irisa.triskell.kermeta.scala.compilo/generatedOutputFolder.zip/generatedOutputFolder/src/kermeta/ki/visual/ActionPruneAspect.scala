package kermeta.ki.visual
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait ActionPruneAspect  extends kermeta.ki.malai.action.ActionAspect with kermeta.ki.malai.undo.UndoableAspect with kermeta.ki.visual.ActionPrune{
var viewPolicy : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy= _
def KergetViewPolicy() : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy={this.viewPolicy}
def KersetViewPolicy(arg:kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy)={ this.viewPolicy = arg}
def ScalaviewPolicy : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy={this.KergetViewPolicy()}.asInstanceOf[kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy]
def ScalaviewPolicy_=(value : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy)={this.KersetViewPolicy(value)}
var metamodel : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit= _
def KergetMetamodel() : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit={this.metamodel}
def KersetMetamodel(arg:_root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit)={ this.metamodel = arg}
def Scalametamodel : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit={this.KergetMetamodel()}.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit]
def Scalametamodel_=(value : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit)={this.KersetMetamodel(value)}
var arePruned : _root_.java.util.List[_root_.java.lang.Boolean]= _
def KergetArePruned() : _root_.java.util.List[_root_.java.lang.Boolean]={this.arePruned}
def KersetArePruned(arg:_root_.java.util.List[_root_.java.lang.Boolean])={ this.arePruned = arg}
def ScalaarePruned : _root_.java.util.List[_root_.java.lang.Boolean]={this.KergetArePruned()}.asInstanceOf[_root_.java.util.List[_root_.java.lang.Boolean]]
def ScalaarePruned_=(value : _root_.java.util.List[_root_.java.lang.Boolean])={this.KersetArePruned(value)}
var selection : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition] = new java.util.ArrayList[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]
def KergetSelection() : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]={this.selection}
def KersetSelection(arg:java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition])={ this.selection = arg}
def Scalaselection : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]={this.KergetSelection()}.asInstanceOf[java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]]
def Scalaselection_=(value : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition])={this.KergetSelection().clear
this.KergetSelection().addAll(value)
}
var oldViewPolicy : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy= _
def KergetOldViewPolicy() : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy={this.oldViewPolicy}
def KersetOldViewPolicy(arg:kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy)={ this.oldViewPolicy = arg}
def ScalaoldViewPolicy : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy={this.KergetOldViewPolicy()}.asInstanceOf[kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy]
def ScalaoldViewPolicy_=(value : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy)={this.KersetOldViewPolicy(value)}

    override def canDo():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = (((((kermeta.standard.RichFactory.isVoid((Scalametamodel))).not())).and(((Scalaselection).size()).isGreater(0)))).and((kermeta.standard.RichFactory.isVoid((ScalaviewPolicy))).not());}
 return result
}

    override def hadEffect():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = isDone();}
 return result
}

    def changeVisibility(policy : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var arePruned2 : _root_.java.util.List[_root_.java.lang.Boolean] = kermeta.standard.RichFactory.createSequence[_root_.java.lang.Boolean];
var i : Int = 0;
((Scalametamodel).Scalapackages).each({(pkg)=>

{
((pkg).ScalaallNestedClassDefinitions).each({(cd)=>

{
(arePruned2).add((cd).isPruned())
if ((ScalaarePruned).at(i))

{
(cd).prune(policy)}
else 


{
(cd).unprune()}

i = (i).plus(1);}
})}
})
ScalaarePruned = arePruned2;
org.kermeta.ki.visual.view.MetamodelView.updateArrows(Scalametamodel)}
 return result
}

    override def cancelledBy(action : _root_.fr.irisa.triskell.kermeta.language.structure.Class):java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = false;}
 return result
}

    override def isRegisterable():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = true;}
 return result
}

    override def undo():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
changeVisibility(ScalaoldViewPolicy)}
 return result
}

    def setPruningParameters(pruningOperation : _root_.kermeta.ki.visual.MetamodelPruner):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(pruningOperation).ScalaisHierarchicalPruning = false;}
 return result
}

    override def redo():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
changeVisibility(ScalaviewPolicy)}
 return result
}

    override def doActionBody():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var i : Int = 0;
var pruned : _root_.java.lang.Boolean = null.asInstanceOf[_root_.java.lang.Boolean];
ScalaarePruned = kermeta.standard.RichFactory.createSequence[_root_.java.lang.Boolean];
((Scalametamodel).Scalapackages).each({(pkg)=>

{
((pkg).ScalaallNestedClassDefinitions).each({(cd)=>

{
pruned = (cd).isPruned();
(ScalaarePruned).add(pruned)
if (((kermeta.standard.RichFactory.isVoid((ScalaviewPolicy)))).and(pruned))

{
ScalaoldViewPolicy = if ((cd).isVisible())

{
(kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy).hide}
else 


{
(kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy).gray}
;}

i = (i).plus(1);}
})}
})
(Scalametamodel).reinitView()
var pruningOp : _root_.kermeta.ki.visual.MetamodelPruner = kermeta.ki.visual.RichFactory.createMetamodelPruner;
var reqClasses : _root_.java.util.List[_root_.kermeta.ki.visual.RequiredClass] = kermeta.standard.RichFactory.createBag[_root_.kermeta.ki.visual.RequiredClass];
var reqClass : _root_.kermeta.ki.visual.RequiredClass = null.asInstanceOf[_root_.kermeta.ki.visual.RequiredClass];
(Scalaselection).each({(cd)=>

{
reqClass = kermeta.ki.visual.RichFactory.createRequiredClass;
(reqClass).Scalaname = (cd).Scalaname;
(reqClasses).add(reqClass)}
})
(pruningOp).ScalainputKermetaMetamodel = Scalametamodel;
(pruningOp).initialize(reqClasses, kermeta.standard.RichFactory.createBag[_root_.kermeta.ki.visual.RequiredProperty], kermeta.standard.RichFactory.createBag[_root_.kermeta.ki.visual.RequiredEnumeration], 3, ScalaviewPolicy)
setPruningParameters(pruningOp)
if ((pruningOp).preprocess())

{
(pruningOp).transform()}

org.kermeta.ki.visual.view.MetamodelView.updateArrows(Scalametamodel)
Scaladone}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.visual.ActionPrune"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

