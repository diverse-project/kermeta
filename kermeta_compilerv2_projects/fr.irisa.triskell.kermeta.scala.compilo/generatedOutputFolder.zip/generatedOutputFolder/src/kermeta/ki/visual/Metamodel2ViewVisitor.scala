package kermeta.ki.visual
trait Metamodel2ViewVisitor extends ScalaAspect.fr.irisa.triskell.kermeta.KermetaVisitor{

    override def visitProperty(p : _root_.fr.irisa.triskell.kermeta.language.structure.Property) : Unit
    override def visitPackage(p : _root_.fr.irisa.triskell.kermeta.language.structure.Package) : Unit
    override def visitModelingUnit(mu : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit) : Unit
    override def visitOperation(o : _root_.fr.irisa.triskell.kermeta.language.structure.Operation) : Unit
    override def visitClassDefinition(c : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition) : Unit}

