package kermeta.ki.visual
trait ModifyPrunerViewPolicy extends kermeta.ki.malai.action.Action with kermeta.ki.malai.undo.Undoable{

    override def canDo() : java.lang.Boolean
    override def hadEffect() : java.lang.Boolean
    override def isRegisterable() : java.lang.Boolean
    override def undo() : Unit
    override def cancelledBy(action : _root_.fr.irisa.triskell.kermeta.language.structure.Class) : java.lang.Boolean
    override def redo() : Unit
    override def doActionBody() : Unit}

