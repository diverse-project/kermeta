package kermeta.ki.visual
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait Press2FlatAspect  extends kermeta.ki.malai.instrument.PressLinkAspect with kermeta.ki.visual.Press2Flat{

    override def createAction():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var flat : _root_.kermeta.ki.visual.Flat = kermeta.ki.visual.RichFactory.createFlat;
var flattener : _root_.kermeta.ki.visual.Flattener = (Scalainstrument).asInstanceOf[_root_.kermeta.ki.visual.Flattener];
(flat).initialise((Scalainstrument).ScalaactionRegistry)
(flat).Scalametamodel = (flattener).Scalametamodel;
Scalaaction = flat;}
 return result
}

    override def updateAction():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
if ((kermeta.standard.RichFactory.isVoid((Scalaaction))).not())

{
var press : _root_.kermeta.ki.malai.interaction.Press = (Scalainteraction).asInstanceOf[_root_.kermeta.ki.malai.interaction.Press];
var flat : _root_.kermeta.ki.visual.Flat = (Scalaaction).asInstanceOf[_root_.kermeta.ki.visual.Flat];
if (((press).Scalatarget).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition])

{
(flat).ScalaclassToFlat = ((press).Scalatarget).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition];}
}
}
 return result
}

    override def getActionClass():_root_.fr.irisa.triskell.kermeta.language.structure.Class = {
var result : _root_.fr.irisa.triskell.kermeta.language.structure.Class = null.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Class]; 


{
result = scalaUtil.Util.getMetaClass("_root_.kermeta.ki.visual.Flat");}
 return result
}

    override def isConditionRespected():Boolean = {
var result : Boolean = null.asInstanceOf[Boolean]; 


{
var press : _root_.kermeta.ki.malai.interaction.Press = (Scalainteraction).asInstanceOf[_root_.kermeta.ki.malai.interaction.Press];
result = (((kermeta.standard.RichFactory.isVoid(((press).Scalatarget))).not())).and(((press).Scalatarget).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]);}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.visual.Press2Flat"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

