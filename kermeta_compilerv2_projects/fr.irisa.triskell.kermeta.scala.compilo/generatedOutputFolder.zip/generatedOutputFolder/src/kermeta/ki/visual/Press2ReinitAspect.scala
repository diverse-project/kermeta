package kermeta.ki.visual
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait Press2ReinitAspect  extends kermeta.ki.malai.instrument.LinkAspect with kermeta.ki.visual.Press2Reinit{

    override def createAction():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
var as : _root_.kermeta.ki.visual.ActionReinitView = kermeta.ki.visual.RichFactory.createActionReinitView;
var pruner : _root_.kermeta.ki.visual.Pruner = (Scalainstrument).asInstanceOf[_root_.kermeta.ki.visual.Pruner];
(as).initialise((Scalainstrument).ScalaactionRegistry)
(as).Scalametamodel = (pruner).Scalametamodel;
Scalaaction = as;}
 return result
}

    override def createInteraction():_root_.kermeta.ki.malai.interaction.Interaction = {
var result : _root_.kermeta.ki.malai.interaction.Interaction = null.asInstanceOf[_root_.kermeta.ki.malai.interaction.Interaction]; 


{
result = kermeta.ki.malai.interaction.RichFactory.createPress;}
 return result
}

    override def updateAction():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
}
 return result
}

    override def getActionClass():_root_.fr.irisa.triskell.kermeta.language.structure.Class = {
var result : _root_.fr.irisa.triskell.kermeta.language.structure.Class = null.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Class]; 


{
result = scalaUtil.Util.getMetaClass("_root_.kermeta.ki.visual.ActionReinitView");}
 return result
}

    override def isConditionRespected():Boolean = {
var result : Boolean = null.asInstanceOf[Boolean]; 


{
var press : _root_.kermeta.ki.malai.interaction.Press = (Scalainteraction).asInstanceOf[_root_.kermeta.ki.malai.interaction.Press];
result = kermeta.standard.RichFactory.isVoid(((press).Scalatarget));}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.visual.Press2Reinit"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

