package kermeta.ki.visual
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait PrunerAspect  extends kermeta.ki.malai.instrument.InstrumentAspect with kermeta.ki.visual.Pruner{
var metamodel : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit= _
def KergetMetamodel() : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit={this.metamodel}
def KersetMetamodel(arg:_root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit)={ this.metamodel = arg}
def Scalametamodel : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit={this.KergetMetamodel()}.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit]
def Scalametamodel_=(value : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit)={this.KersetMetamodel(value)}
var viewPolicy : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy= _
def KergetViewPolicy() : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy={this.viewPolicy}
def KersetViewPolicy(arg:kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy)={ this.viewPolicy = arg}
def ScalaviewPolicy : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy={this.KergetViewPolicy()}.asInstanceOf[kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy]
def ScalaviewPolicy_=(value : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy)={this.KersetViewPolicy(value)}
var grayedButton : _root_.kermeta.ki.malai.widget.ToggleButton= _
def KergetGrayedButton() : _root_.kermeta.ki.malai.widget.ToggleButton={this.grayedButton}
def KersetGrayedButton(arg:_root_.kermeta.ki.malai.widget.ToggleButton)={ this.grayedButton = arg}
def ScalagrayedButton : _root_.kermeta.ki.malai.widget.ToggleButton={this.KergetGrayedButton()}.asInstanceOf[_root_.kermeta.ki.malai.widget.ToggleButton]
def ScalagrayedButton_=(value : _root_.kermeta.ki.malai.widget.ToggleButton)={this.KersetGrayedButton(value)}
var hideButton : _root_.kermeta.ki.malai.widget.ToggleButton= _
def KergetHideButton() : _root_.kermeta.ki.malai.widget.ToggleButton={this.hideButton}
def KersetHideButton(arg:_root_.kermeta.ki.malai.widget.ToggleButton)={ this.hideButton = arg}
def ScalahideButton : _root_.kermeta.ki.malai.widget.ToggleButton={this.KergetHideButton()}.asInstanceOf[_root_.kermeta.ki.malai.widget.ToggleButton]
def ScalahideButton_=(value : _root_.kermeta.ki.malai.widget.ToggleButton)={this.KersetHideButton(value)}

    override def initialise(actionRegistry : _root_.kermeta.ki.malai.action.ActionRegistry):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
super[InstrumentAspect].initialise(actionRegistry)
ScalaviewPolicy = (kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy).hide;}
 return result
}

    override def initialiseLinks(eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
addLink(kermeta.ki.visual.RichFactory.createMultiPress2Prune, Scalametamodel, null, eventManager, false)
addLink(kermeta.ki.visual.RichFactory.createPress2Prune, Scalametamodel, null, eventManager, false)
addLink(kermeta.ki.visual.RichFactory.createPress2Reinit, Scalametamodel, null, eventManager, false)}
 return result
}

    def initialiseWidgets(eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
ScalahideButton = kermeta.ki.malai.widget.RichFactory.createToggleButton;
ScalagrayedButton = kermeta.ki.malai.widget.RichFactory.createToggleButton;
(ScalahideButton).initialiseWithText("Hide", eventManager)
(ScalagrayedButton).initialiseWithText("Gray", eventManager)
interimFeedback()}
 return result
}

    override def interimFeedback():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(ScalahideButton).setSelected(((ScalaviewPolicy) == ((kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy).hide)))
(ScalagrayedButton).setSelected(((ScalaviewPolicy) == ((kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy).gray)))
(ScalahideButton).setVisible(Scalaactivated)
(ScalagrayedButton).setVisible(Scalaactivated)}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.visual.Pruner"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

