package kermeta.ki.visual
trait RequiredEnumeration extends fr.irisa.triskell.kermeta.language.structure.Object{
}

