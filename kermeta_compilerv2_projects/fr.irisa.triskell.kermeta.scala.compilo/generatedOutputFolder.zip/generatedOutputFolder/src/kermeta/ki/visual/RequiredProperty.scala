package kermeta.ki.visual
trait RequiredProperty extends fr.irisa.triskell.kermeta.language.structure.Object{
}

