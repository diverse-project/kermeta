package kermeta.ki.visual
trait Visual extends fr.irisa.triskell.kermeta.language.structure.Object{

    def main() : Unit}

