package kermeta.ki.visual
trait Hierarcher extends kermeta.ki.malai.instrument.Instrument{

    override def initialiseLinks(eventManager : _root_.kermeta.ki.malai.interaction.event.EventManager) : Unit}

