package kermeta.ki.visual
trait ClassFlattener extends fr.irisa.triskell.kermeta.language.structure.Object{

    def flatClass(currentClass : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition, upperClass : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition) : Unit
    def flat(classToFlat : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition) : Unit}

