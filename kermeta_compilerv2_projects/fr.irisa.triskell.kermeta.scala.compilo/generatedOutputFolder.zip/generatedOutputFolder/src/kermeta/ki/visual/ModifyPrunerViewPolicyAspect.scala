package kermeta.ki.visual
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait ModifyPrunerViewPolicyAspect  extends kermeta.ki.malai.action.ActionAspect with kermeta.ki.malai.undo.UndoableAspect with kermeta.ki.visual.ModifyPrunerViewPolicy{
var newViewPolicy : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy= _
def KergetNewViewPolicy() : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy={this.newViewPolicy}
def KersetNewViewPolicy(arg:kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy)={ this.newViewPolicy = arg}
def ScalanewViewPolicy : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy={this.KergetNewViewPolicy()}.asInstanceOf[kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy]
def ScalanewViewPolicy_=(value : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy)={this.KersetNewViewPolicy(value)}
var pruner : _root_.kermeta.ki.visual.Pruner= _
def KergetPruner() : _root_.kermeta.ki.visual.Pruner={this.pruner}
def KersetPruner(arg:_root_.kermeta.ki.visual.Pruner)={ this.pruner = arg}
def Scalapruner : _root_.kermeta.ki.visual.Pruner={this.KergetPruner()}.asInstanceOf[_root_.kermeta.ki.visual.Pruner]
def Scalapruner_=(value : _root_.kermeta.ki.visual.Pruner)={this.KersetPruner(value)}
var oldViewPolicy : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy= _
def KergetOldViewPolicy() : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy={this.oldViewPolicy}
def KersetOldViewPolicy(arg:kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy)={ this.oldViewPolicy = arg}
def ScalaoldViewPolicy : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy={this.KergetOldViewPolicy()}.asInstanceOf[kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy]
def ScalaoldViewPolicy_=(value : kermeta.ki.visual.PrunerViewPolicy.PrunerViewPolicy)={this.KersetOldViewPolicy(value)}

    override def canDo():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = (((kermeta.standard.RichFactory.isVoid((Scalapruner))).not())).and((kermeta.standard.RichFactory.isVoid((ScalanewViewPolicy))).not());}
 return result
}

    override def hadEffect():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = isDone();}
 return result
}

    override def isRegisterable():java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = true;}
 return result
}

    override def undo():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(Scalapruner).ScalaviewPolicy = ScalaoldViewPolicy;
(Scalapruner).interimFeedback()}
 return result
}

    override def cancelledBy(action : _root_.fr.irisa.triskell.kermeta.language.structure.Class):java.lang.Boolean = {
var result : java.lang.Boolean = null.asInstanceOf[java.lang.Boolean]; 


{
result = false;}
 return result
}

    override def redo():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(Scalapruner).ScalaviewPolicy = ScalanewViewPolicy;
(Scalapruner).interimFeedback()}
 return result
}

    override def doActionBody():Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
ScalaoldViewPolicy = (Scalapruner).ScalaviewPolicy;
redo()
Scaladone}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.ki.visual.ModifyPrunerViewPolicy"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

