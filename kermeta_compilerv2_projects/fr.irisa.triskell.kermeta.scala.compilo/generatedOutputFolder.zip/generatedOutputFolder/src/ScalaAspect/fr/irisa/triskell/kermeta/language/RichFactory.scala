package ScalaAspect.fr.irisa.triskell.kermeta.language
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
object RichFactory extends fr.irisa.triskell.kermeta.language.impl.LanguageFactoryImpl{
}

