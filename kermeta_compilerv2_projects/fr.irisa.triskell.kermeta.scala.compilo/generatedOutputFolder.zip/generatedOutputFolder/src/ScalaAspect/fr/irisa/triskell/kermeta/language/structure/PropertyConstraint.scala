package ScalaAspect.fr.irisa.triskell.kermeta.language.structure
trait PropertyConstraint extends fr.irisa.triskell.kermeta.language.structure.Constraint{
}

