package ScalaAspect.fr.irisa.triskell.kermeta.language
 abstract class RichDummyClass extends fr.irisa.triskell.kermeta.language.impl.DummyClassImpl with ScalaAspect.fr.irisa.triskell.kermeta.language.DummyClassAspect 

