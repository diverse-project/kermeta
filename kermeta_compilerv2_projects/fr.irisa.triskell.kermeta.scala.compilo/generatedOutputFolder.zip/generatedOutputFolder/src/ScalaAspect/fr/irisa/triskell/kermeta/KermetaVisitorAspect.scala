package ScalaAspect.fr.irisa.triskell.kermeta
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait KermetaVisitorAspect  extends ScalaAspect.fr.irisa.triskell.kermeta.language.structure.ObjectAspect with ScalaAspect.fr.irisa.triskell.kermeta.KermetaVisitor{

    def visitVoidLiteral(arg : _root_.fr.irisa.triskell.kermeta.language.behavior.VoidLiteral):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitVirtualType(arg : _root_.fr.irisa.triskell.kermeta.language.structure.VirtualType):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitModelingUnit(arg : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitEnumeration(arg : _root_.fr.irisa.triskell.kermeta.language.structure.Enumeration):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitCallValue(arg : _root_.fr.irisa.triskell.kermeta.language.behavior.CallValue):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitMultiplicityElement(arg : _root_.fr.irisa.triskell.kermeta.language.structure.MultiplicityElement):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitParameter(arg : _root_.fr.irisa.triskell.kermeta.language.structure.Parameter):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitTypeDefinition(arg : _root_.fr.irisa.triskell.kermeta.language.structure.TypeDefinition):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitEmptyExpression(arg : _root_.fr.irisa.triskell.kermeta.language.behavior.EmptyExpression):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitProperty(arg : _root_.fr.irisa.triskell.kermeta.language.structure.Property):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitCallFeature(arg : _root_.fr.irisa.triskell.kermeta.language.behavior.CallFeature):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitVoidType(arg : _root_.fr.irisa.triskell.kermeta.language.structure.VoidType):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitBlock(arg : _root_.fr.irisa.triskell.kermeta.language.behavior.Block):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitTypeVariableBinding(arg : _root_.fr.irisa.triskell.kermeta.language.structure.TypeVariableBinding):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitJavaStaticCall(arg : _root_.fr.irisa.triskell.kermeta.language.behavior.JavaStaticCall):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitProductType(arg : _root_.fr.irisa.triskell.kermeta.language.structure.ProductType):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitCallSuperOperation(arg : _root_.fr.irisa.triskell.kermeta.language.behavior.CallSuperOperation):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitTypeReference(arg : _root_.fr.irisa.triskell.kermeta.language.behavior.TypeReference):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitPrimitiveType(arg : _root_.fr.irisa.triskell.kermeta.language.structure.PrimitiveType):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitLambdaParameter(arg : _root_.fr.irisa.triskell.kermeta.language.behavior.LambdaParameter):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitClassDefinition(arg : _root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitRaise(arg : _root_.fr.irisa.triskell.kermeta.language.behavior.Raise):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitFunctionType(arg : _root_.fr.irisa.triskell.kermeta.language.structure.FunctionType):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitType(arg : _root_.fr.irisa.triskell.kermeta.language.structure.Type):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitBooleanLiteral(arg : _root_.fr.irisa.triskell.kermeta.language.behavior.BooleanLiteral):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitModelTypeVariable(arg : _root_.fr.irisa.triskell.kermeta.language.structure.ModelTypeVariable):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitOperation(arg : _root_.fr.irisa.triskell.kermeta.language.structure.Operation):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitTag(arg : _root_.fr.irisa.triskell.kermeta.language.structure.Tag):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitObject(arg : _root_.fr.irisa.triskell.kermeta.language.structure.Object):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
}
 return result
}

    def visitRescue(arg : _root_.fr.irisa.triskell.kermeta.language.behavior.Rescue):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitRequire(arg : _root_.fr.irisa.triskell.kermeta.language.structure.Require):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitModelType(arg : _root_.fr.irisa.triskell.kermeta.language.structure.ModelType):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitConditional(arg : _root_.fr.irisa.triskell.kermeta.language.behavior.Conditional):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitUsing(arg : _root_.fr.irisa.triskell.kermeta.language.structure.Using):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitModel(arg : _root_.fr.irisa.triskell.kermeta.language.structure.Model):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitVariableDecl(arg : _root_.fr.irisa.triskell.kermeta.language.behavior.VariableDecl):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitIntegerLiteral(arg : _root_.fr.irisa.triskell.kermeta.language.behavior.IntegerLiteral):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitConstraint(arg : _root_.fr.irisa.triskell.kermeta.language.structure.Constraint):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitFilter(arg : _root_.fr.irisa.triskell.kermeta.language.structure.Filter):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitAssignment(arg : _root_.fr.irisa.triskell.kermeta.language.behavior.Assignment):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitPackage(arg : _root_.fr.irisa.triskell.kermeta.language.structure.Package):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitLambdaExpression(arg : _root_.fr.irisa.triskell.kermeta.language.behavior.LambdaExpression):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitTypeLiteral(arg : _root_.fr.irisa.triskell.kermeta.language.behavior.TypeLiteral):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitLoop(arg : _root_.fr.irisa.triskell.kermeta.language.behavior.Loop):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitStringLiteral(arg : _root_.fr.irisa.triskell.kermeta.language.behavior.StringLiteral):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitObjectTypeVariable(arg : _root_.fr.irisa.triskell.kermeta.language.structure.ObjectTypeVariable):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitEnumerationLiteral(arg : _root_.fr.irisa.triskell.kermeta.language.structure.EnumerationLiteral):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitCallResult(arg : _root_.fr.irisa.triskell.kermeta.language.behavior.CallResult):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitCallVariable(arg : _root_.fr.irisa.triskell.kermeta.language.behavior.CallVariable):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitClass(arg : _root_.fr.irisa.triskell.kermeta.language.structure.Class):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}

    def visitSelfExpression(arg : _root_.fr.irisa.triskell.kermeta.language.behavior.SelfExpression):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(this).visitObject(arg)}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.KermetaVisitor"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

