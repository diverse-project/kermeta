package ScalaAspect.fr.irisa.triskell.kermeta.language.structure
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait ObjectAspect extends fr.irisa.triskell.kermeta.language.structureScalaAspect.aspect.ObjectAspect with fr.irisa.triskell.kermeta.language.structure.Object{
def Scalatag : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Tag]={this.getTag()}.asInstanceOf[java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Tag]]
def Scalatag_=(value : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Tag])={this.getTag().clear
this.getTag().addAll(value)
}
def ScalaownedTags : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Tag]={this.getOwnedTags()}.asInstanceOf[java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Tag]]
def ScalaownedTags_=(value : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Tag])={this.getOwnedTags().clear
this.getOwnedTags().addAll(value)
}

    def isKindOf(cl : _root_.fr.irisa.triskell.kermeta.language.structure.Class):Boolean = {
var result : Boolean = null.asInstanceOf[Boolean]; 


{
result = (((this).getMetaClass()) == (cl));}
 return result
}

    def accept(v : _root_.ScalaAspect.fr.irisa.triskell.kermeta.KermetaVisitor):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(v).visitObject(this)}
 return result
}

    def isVisible():Boolean = {
var result : Boolean = null.asInstanceOf[Boolean]; 


{
try{
result = org.kermeta.ki.visual.view.ComponentView.isVisible(this).asInstanceOf[_root_.java.lang.Boolean];
}catch { case e:ClassCastException => {}}
}
 return result
}

    def getModelingUnit():_root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit = {
var result : _root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit = null.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit]; 


{
var obj : _root_.fr.irisa.triskell.kermeta.language.structure.Object = container();
result = if ((obj).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit])

{
(obj).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ModelingUnit]}
else 


{
if ((obj).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Object])

{
((obj).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Object]).getModelingUnit()}
else 


{
null}
}
;}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.language.structure.Object"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

