package ScalaAspect.fr.irisa.triskell.kermeta.language.structure
import kermeta.io._
import kermeta.standard._
import  kermeta.standard.JavaConversions._
import kermeta.standard.PrimitiveConversion._
import kermeta.kunit.KunitConversions._
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
trait PackageAspect extends ScalaAspect.fr.irisa.triskell.kermeta.language.structure.NamedElementAspect with ScalaAspect.fr.irisa.triskell.kermeta.language.structure.TypeDefinitionContainerAspect with fr.irisa.triskell.kermeta.language.structureScalaAspect.aspect.ObjectAspect with fr.irisa.triskell.kermeta.language.structure.Package{
var allNestedAttributes : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Property] = new java.util.ArrayList[_root_.fr.irisa.triskell.kermeta.language.structure.Property]
def KergetAllNestedAttributes() : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Property]={this.allNestedAttributes}
def ScalaallNestedAttributes : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Property]={var result : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Property] = null.asInstanceOf[java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Property]]; 


{
result = kermeta.standard.RichFactory.createSet[_root_.fr.irisa.triskell.kermeta.language.structure.Property];
(ScalaallNestedClassDefinitions).each({(cd)=>

{
(result).addAllUnique((cd).ScalaownedAttribute)}
})}
() 
 return result
}.asInstanceOf[java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Property]]
var allNestedClassDefinitions : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition] = new java.util.ArrayList[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]
def KergetAllNestedClassDefinitions() : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]={this.allNestedClassDefinitions}
def ScalaallNestedClassDefinitions : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]={var result : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition] = null.asInstanceOf[java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]]; 


{
result = kermeta.standard.RichFactory.createSet[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition];
((ScalaownedTypeDefinition).select({(td)=>

{
(td).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]}
})).each({(cd)=>

{
(result).addUnique((cd).asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition])}
})
(ScalanestedPackage).each({(p)=>

{
(result).addAllUnique((p).ScalaallNestedClassDefinitions)}
})}
() 
 return result
}.asInstanceOf[java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]]
var allNestedPackages : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Package] = new java.util.ArrayList[_root_.fr.irisa.triskell.kermeta.language.structure.Package]
def KergetAllNestedPackages() : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Package]={this.allNestedPackages}
def ScalaallNestedPackages : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Package]={var result : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Package] = null.asInstanceOf[java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Package]]; 


{
result = kermeta.standard.RichFactory.createSet[_root_.fr.irisa.triskell.kermeta.language.structure.Package];
(result).addUnique(this)
(ScalanestedPackage).each({(p)=>

{
(result).addAllUnique((p).ScalaallNestedPackages)}
})}
() 
 return result
}.asInstanceOf[java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Package]]
def ScalanestingPackage : _root_.fr.irisa.triskell.kermeta.language.structure.Package={this.getNestingPackage()}.asInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.Package]
def ScalanestingPackage_=(value : _root_.fr.irisa.triskell.kermeta.language.structure.Package)={this.setNestingPackage(value)}
var numberOfClasses : Int= _
def KergetNumberOfClasses() : Int={this.numberOfClasses}
def ScalanumberOfClasses : Int={var result : Int = null.asInstanceOf[Int]; 


{
result = ((ScalaownedTypeDefinition).select({(td)=>

{
(td).isInstanceOf[_root_.fr.irisa.triskell.kermeta.language.structure.ClassDefinition]}
})).size();
(ScalanestedPackage).each({(p)=>

{
result = (result).plus((p).ScalanumberOfClasses);}
})}
() 
 return result
}.asInstanceOf[Int]
var numberOfPackages : Int= _
def KergetNumberOfPackages() : Int={this.numberOfPackages}
def ScalanumberOfPackages : Int={var result : Int = null.asInstanceOf[Int]; 


{
result = 1;
(ScalanestedPackage).each({(p)=>

{
result = (result).plus((p).ScalanumberOfPackages);}
})}
() 
 return result
}.asInstanceOf[Int]
def ScalanestedPackage : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Package]={this.getNestedPackage()}.asInstanceOf[java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Package]]
def ScalanestedPackage_=(value : java.util.List[_root_.fr.irisa.triskell.kermeta.language.structure.Package])={this.getNestedPackage().clear
this.getNestedPackage().addAll(value)
}
def Scalauri : java.lang.String={this.getUri()}.asInstanceOf[java.lang.String]
def Scalauri_=(value : java.lang.String)={this.setUri(value)}

    override def accept(v : _root_.ScalaAspect.fr.irisa.triskell.kermeta.KermetaVisitor):Unit = {
var result : Unit = null.asInstanceOf[Unit]; 


{
(v).visitPackage(this)}
 return result
}
override def getMetaClass():fr.irisa.triskell.kermeta.language.structure.Class={
 var cd : fr.irisa.triskell.kermeta.language.structure.ClassDefinition =   kermeta.utils.ReflexivityLoader.getMetaClass("kermeta.language.structure.Package"); 
         if (cd !=null){ 
 var cl = ScalaAspect.fr.irisa.triskell.kermeta.language.structure.RichFactory.createClass 
 cl.setTypeDefinition(cd) 
 return cl 
 }else 
 return null; 
 }
}

