package ScalaAspect.fr.irisa.triskell.kermeta
import ScalaImplicit.org.kermeta.org.kermeta.default.aspects.ImplicitConversion._
object RichFactory extends fr.irisa.triskell.kermeta.impl.KmFactoryImpl{
}

