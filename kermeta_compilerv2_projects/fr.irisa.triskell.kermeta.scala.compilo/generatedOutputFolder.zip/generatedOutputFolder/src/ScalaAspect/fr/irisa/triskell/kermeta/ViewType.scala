package ScalaAspect.fr.irisa.triskell.kermeta
 abstract class RichDummyClass extends fr.irisa.triskell.kermeta.impl.DummyClassImpl with ScalaAspect.fr.irisa.triskell.kermeta.DummyClassAspect 
 abstract class RichKermetaVisitor extends fr.irisa.triskell.kermeta.language.structure.impl.ObjectImpl with ScalaAspect.fr.irisa.triskell.kermeta.KermetaVisitor with ScalaAspect.fr.irisa.triskell.kermeta.KermetaVisitorAspect 

