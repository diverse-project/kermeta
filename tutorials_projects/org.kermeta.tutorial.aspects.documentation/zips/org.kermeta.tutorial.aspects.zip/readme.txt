Kermeta Aspect Programming Tutorial
Version bundled on 20-December-2007

This plugin contains the resources associated to the Kermeta tutorial on Aspect Programming.

You can find the tutorial in the Eclipse Help System:
Menu bar > Help Contents > Kermeta Aspect Programming Tutorial