package fsm.diagram.edit.helpers;

/**
 * @generated
 */
public class StateEditHelper extends FsmBaseEditHelper {
}
