package fsm.diagram.edit.helpers;

/**
 * @generated
 */
public class FSMEditHelper extends FsmBaseEditHelper {
}
