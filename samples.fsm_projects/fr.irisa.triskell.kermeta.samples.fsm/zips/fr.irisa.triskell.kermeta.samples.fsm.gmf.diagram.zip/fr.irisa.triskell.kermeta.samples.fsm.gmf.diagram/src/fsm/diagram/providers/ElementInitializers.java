package fsm.diagram.providers;

/**
 * @generated
 */
public class ElementInitializers {

}
