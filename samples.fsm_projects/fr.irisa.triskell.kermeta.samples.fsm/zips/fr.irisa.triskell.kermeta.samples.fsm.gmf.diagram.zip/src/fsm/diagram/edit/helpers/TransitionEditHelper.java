package fsm.diagram.edit.helpers;

/**
 * @generated
 */
public class TransitionEditHelper extends FsmBaseEditHelper {
}
