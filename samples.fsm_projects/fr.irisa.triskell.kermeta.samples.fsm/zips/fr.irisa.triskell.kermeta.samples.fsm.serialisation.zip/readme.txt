FSM demo
Authors: Cyril Faucher <cfaucher@irisa.fr>
		Didier Vojtisek <dvojtise@irisa.fr>
		Olivier Barais <barais@irisa.fr>
		Francois Tanguy <ftanguy@irisa.fr>
		Vincent Mahe <vmahe@irisa.fr>
		Marie Gouyette <Marie.Gouyette@irisa.fr>


This project contains the code for the part serialisation of the FSM tutorial.
You can find additional information and a tutorial about this sample on kermeta web site : http://www.kermeta.org/documents.
