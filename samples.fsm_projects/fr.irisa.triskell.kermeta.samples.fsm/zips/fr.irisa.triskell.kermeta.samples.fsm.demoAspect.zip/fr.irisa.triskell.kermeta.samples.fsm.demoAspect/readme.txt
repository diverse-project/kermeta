FSM demo
Authors: Cyril Faucher <cfaucher@irisa.fr>
		Didier Vojtisek <dvojtise@irisa.fr>
		Olivier Barais <barais@irisa.fr>
		Francois Tanguy <ftanguy@irisa.fr>
		Vincent Mahe <vmahe@irisa.fr>
Version bundled on 4-December-2007

This project contains the code and models to run the FSM demo.
You can find additional information and a tutorial about this sample on kermeta web site : http://www.kermeta.org/documents