FSM demo
Authors:
		Marie Gouyette <Marie.Gouyette@irisa.fr>


This project contains the code of an example of graphical editor create with GMF for the FSM example(.tests part).
It is only a little example to illustrate the FSM Demo. You can retrieve more informations on the GMF documentation.
For more information on Kermeta please refer to the kermeta web site : http://www.kermeta.org/documents.
