FSM demo
Version bundled on 21-December-2006

This project contains the code and models to run the FSM demo.
You can find additional information and a tutorial about this sample on kermeta web site : http://www.kermeta.org/documents