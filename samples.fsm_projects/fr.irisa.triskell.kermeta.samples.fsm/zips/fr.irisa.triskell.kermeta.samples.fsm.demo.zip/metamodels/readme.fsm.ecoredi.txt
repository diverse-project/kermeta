FSM demo
Authors: Cyril Faucher <cfaucher@irisa.fr>
Version bundled on @BUILD.DATE@

The files named "fsm.ecoredi" and "fsmHoriz.ecoredi" are the graphical views of the deployed FSM metamodel (generated EMF API dedicated to FSM in the "plugin" folder).
We use the nsuri of the FSM package (http://kermeta/samples/fsm.ecore) instead of the ecore file.
Thus, the FSM structure cannot be modified through these files.
You can get the FSM metamodel as file (*.ecore) in the plugin: fr.irisa.triskell.kermeta.samples.fsm/src/metamodels/fsm.ecore