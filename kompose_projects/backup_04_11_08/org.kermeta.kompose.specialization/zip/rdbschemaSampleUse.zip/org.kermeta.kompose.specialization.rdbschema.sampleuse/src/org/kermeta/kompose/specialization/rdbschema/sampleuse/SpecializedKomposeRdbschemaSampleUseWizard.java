package org.kermeta.kompose.specialization.rdbschema.sampleuse;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;


public class SpecializedKomposeRdbschemaSampleUseWizard
	extends AbstractExampleWizard {
	
	protected Collection getProjectDescriptors() {

		List projects = new ArrayList(1);
		projects.add(new ProjectDescriptor("org.kermeta.kompose.specialization.rdbschema.sampleuse", "zip/schemaSample.zip", "RbSchemaSample"));
		return projects;
	}
}