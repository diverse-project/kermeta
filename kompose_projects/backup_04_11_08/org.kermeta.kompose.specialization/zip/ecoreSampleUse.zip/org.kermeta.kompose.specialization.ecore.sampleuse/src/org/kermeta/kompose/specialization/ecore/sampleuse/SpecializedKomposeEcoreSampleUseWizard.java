package org.kermeta.kompose.specialization.ecore.sampleuse;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;


public class SpecializedKomposeEcoreSampleUseWizard
	extends AbstractExampleWizard {
	
	protected Collection getProjectDescriptors() {

		List projects = new ArrayList(1);
		projects.add(new ProjectDescriptor("org.kermeta.kompose.specialization.ecore.sampleuse", "zip/BankingSample.zip", "BankingSample"));
		return projects;
	}
}