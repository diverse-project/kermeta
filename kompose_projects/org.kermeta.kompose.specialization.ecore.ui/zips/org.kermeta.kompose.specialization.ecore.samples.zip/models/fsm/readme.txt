This example is part of a demo presented in workshops.
All compositions are bound so there is a specific order to merge models correctly :
1. Add composition -> creates a composed model in /adding_events
2. Add event concept -> creates a composed model in /adding_concurrency
3. Add concurrency -> creates a composed model in same level as this text file.