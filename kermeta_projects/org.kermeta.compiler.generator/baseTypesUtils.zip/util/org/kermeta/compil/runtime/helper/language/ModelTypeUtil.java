package org.kermeta.compil.runtime.helper.language;


/** Implementation in java of the extern methods of ModelType that can be called from Kermeta */
public class ModelTypeUtil {
	// Implementation of method newObject called as :
	// extern fr::irisa::triskell::kermeta::runtime::language::ModelType.newObject()
	public static kermeta.language.structure.Model newObject(kermeta.language.structure.ModelType self) {
		return null;
	}
	
	// Implementation of method newObject called as :
	// extern fr::irisa::triskell::kermeta::runtime::language::ModelType.isModelTypeOf()
	public static java.lang.Boolean isModelTypeOf(kermeta.language.structure.ModelType modelType, kermeta.language.structure.Model model) {
		return null;
	}
	
}
