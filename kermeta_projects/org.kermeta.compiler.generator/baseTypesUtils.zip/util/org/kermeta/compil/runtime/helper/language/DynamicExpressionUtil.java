
package org.kermeta.compil.runtime.helper.language;


public class DynamicExpressionUtil {
		
    // result ?= extern fr::irisa::triskell::kermeta::runtime::language::DynamicExpression.parse(self, expression)
	public static java.lang.Boolean parse(kermeta.interpreter.DynamicExpression self, java.lang.String expression) {
	    
		return null;
	}

	//result := extern fr::irisa::triskell::kermeta::runtime::language::DynamicExpression.execute(self, selfObj, actualParams)
	public static kermeta.language.structure.Object execute(kermeta.interpreter.DynamicExpression self, kermeta.language.structure.Object selfObj, kermeta.utils.Hashtable<java.lang.String, kermeta.language.structure.Object> actualParams) {
	    
	    return null;
	    
	}
	
}
