
package org.kermeta.compil.runtime.helper.language;

import kermeta.language.ReflectiveSequence;


public class ReflectiveSequenceUtil {

	/** Implementation of method addAt called as :
	 * extern fr::irisa::triskell::kermeta::runtime::language::ReflectiveSequence.addAt(index, element)
	 */
	public static <G> void addAt(ReflectiveSequence<G> self, java.lang.Integer param0, G element) {

	}

	/** Implementation of method removeAt called as :
	 * extern fr::irisa::triskell::kermeta::runtime::language::ReflectiveSequence.removeAt(index)
	 */
	public static <G> void removeAt(ReflectiveSequence<G> self, java.lang.Integer param0) {

	}
	
}
/* END OF FILE */
