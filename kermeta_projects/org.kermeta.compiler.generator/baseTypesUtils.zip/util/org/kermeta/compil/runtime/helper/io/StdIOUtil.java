/* $Id: StdIOUtil.java,v 1.1 2008/08/01 18:29:17 cfaucher Exp $
 * Project : Kermeta (First iteration)
 * File : Io.java
 * License : EPL
 * Copyright : IRISA / Universite de Rennes 1
 * ----------------------------------------------------------------------------
 * Creation date : Mar 4, 2005
 * Author : zdrey
 * Description : describe here file content
 * TODO : 
 * 	- write here your TODO actions
 *  - ...
 */
package org.kermeta.compil.runtime.helper.io;


/**
 * Implementation of input and output methods (see io.kmt)
 */
public class StdIOUtil {
    
	// Implementation of method write called as :
	// extern fr::irisa::triskell::kermeta::runtime::basetypes::Io.write(output)
	public static void write(String output) {
		//TODO
	}

	// Implementation of method writeln called as :
	// extern fr::irisa::triskell::kermeta::runtime::basetypes::Io.writeln(output)
	public static void writeln(java.lang.String output) {
		//TODO
	}
	
	// Implementation of method error called as :
	// extern fr::irisa::triskell::kermeta::runtime::basetypes::Io.error(output)
	public static void error(java.lang.String output) {
		//TODO
	}

	// Implementation of method errorln called as :
	// extern fr::irisa::triskell::kermeta::runtime::basetypes::Io.errorln(output)
	public static void errorln(java.lang.String output) {
		//TODO
	}
	
	// Implementation of method read called as :
	// extern fr::irisa::triskell::kermeta::runtime::basetypes::Io.read(prompt)
	public static java.lang.String read(java.lang.String prompt)
	{
		//TODO
		return null;
	}
	
}
