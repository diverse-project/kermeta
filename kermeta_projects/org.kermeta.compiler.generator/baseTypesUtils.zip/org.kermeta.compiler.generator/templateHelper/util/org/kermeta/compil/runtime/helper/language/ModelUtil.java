package org.kermeta.compil.runtime.helper.language;

public class ModelUtil {
	
	/** Implementation of method add called as :
	 * extern fr::irisa::triskell::kermeta::runtime::language::Model.add(self, element)
	*/
	public static void add(kermeta.language.structure.Model self, kermeta.language.structure.Object element) {
	}
	
	
	
	/** Implementation of method add called as :
	 * extern fr::irisa::triskell::kermeta::runtime::language::Model.addCompatible(self, Object)
	 * returns the object if is was added, void otherwise
	*/
	public static kermeta.language.structure.Object addCompatible(kermeta.language.structure.Model model, kermeta.language.structure.Object element) {
		
		return null;
	}
}
