/* $Id: MarkerHelper.java,v 1.6 2009-11-26 17:10:37 jfalcou Exp $
 * Project : Kermeta (First iteration)
 * File : MarkerHelper.java
 * License : EPL
 * Copyright : IRISA / Universite de Rennes 1
 * ----------------------------------------------------------------------------
 * Creation date : Mar 4, 2005
 * Author : jfalcou
 * Description : describe here file content
 * TODO : 
 * 	- write here your TODO actions
 *  - ...
 */ 

package org.kermeta.compil.runtime.helper.io;
public class MarkerHelper {

	public static void markFile(String uri, String message) {
		
		//System.out.println("Marking file " + uri + " with message " + message);
		
	}
	
	public static void cleanFile(String uri) {
		//System.out.println("Cleaning file " + uri);
	}
	
}
