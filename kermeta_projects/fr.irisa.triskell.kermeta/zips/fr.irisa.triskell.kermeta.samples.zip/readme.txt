Kermeta samples
Version bundled on 3-March-2008

- arabic2roman: convert Arabic number in Roman number
- class2RDBMS: convert a Class Model in a DB schema
- fileIO: this sample shows how to read and write text files in kermeta using the kermeta::io::FileIO class helper
- kmlogo: the Logo language for children reimplemented in kermeta
- kunit_sample: give an example of the uses of the Kermeta Unit test
- prettyprinter: a pretty printer of kermeta code using reflection methods

You can find additional information and tutorials about these samples on Kermeta web site : http://kermeta.org/examples