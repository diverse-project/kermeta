Kermeta samples
Version bundled on 22-December-2006

- arabic2roman : convert Arabic number in Roman number
- class2RDBMS : convert a Class Model in a DB schema
- helloworld : helloworld printer
- kmlogo : the Logo language for children reimplemented in kermeta
- persistence : an exemple of ecore meta-model with its Kermeta generated representation
(not usable. This sample was an introduction for the implementation of persistence in Kermeta language)
- prettyprinter : a pretty printer of kermeta code using reflection methods

You can find additional information and tutorials about these samples on Kermeta web site : http://kermeta.org/examples