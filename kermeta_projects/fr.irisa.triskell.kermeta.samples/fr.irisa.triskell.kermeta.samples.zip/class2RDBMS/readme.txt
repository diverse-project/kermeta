Kermeta samples # class2RDBMS
Version bundled on @BUILD.DATE@

Before to launch the transformation, the 2 metamodels: ClassMM.ecore and RDBMSMM.ecore must be registered.
To do it, right-click on the file ClassMM.ecore in the folder metamodels and
in "EPackages registration" category select "Register EPackages into repository"
or follow the instruction given at: http://kermeta.org/sintaks/RegisteringEPackagesMetamodel