/* $Id:$
 * Project: Kermeta (First iteration)
 * File: OpenKermetaPerspective.java
 * License: GPL
 * Copyright: IRISA / INRIA / Universite de Rennes 1
 * ----------------------------------------------------------------------------
 * Creation date: May 26, 2005
 * Authors: zdrey
 */
package fr.irisa.triskell.kermeta.runner.perspective;

import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.jface.action.Action;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.WorkbenchException;

import fr.irisa.triskell.kermeta.runner.RunnerPlugin;

/**
 *  
 * This class is inspired from 
 * 	- package org.eclipse.pde.internal.ui.OpenPDEPerspectiveAction
 * 
 * and was created according to the philosophy of PDE
 * The mechanism is the following : 
 */
public class OpenKermetaPerspective extends Action {

    /**
     * Useless yet!!
     */
    public OpenKermetaPerspective() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    /**
     * Picked from org.eclipse.pde.internal.ui.OpenPDEPerspectiveAction
     * This method shows the Kermeta perspective
     * */
	public void run() {
		IWorkbenchWindow window = RunnerPlugin.getActiveWorkbenchWindow();
		IWorkbenchPage page = window.getActivePage();
		IAdaptable input;
		if (page != null)
			input = page.getInput();
		else
			input = ResourcesPlugin.getWorkspace().getRoot();
		try {
			PlatformUI.getWorkbench().showPerspective(
				"kermetaPerspective", //$NON-NLS-1$
				window,
				input);
			notifyResult(true);
			
		} catch (WorkbenchException e) {
			RunnerPlugin.logException(e);
			notifyResult(false);
		}
	}
}
